"""Supported emulators: detection, where each keeps its hardcore setting, and RetroArch cores."""

import json
import os

DEFAULT_RETROARCH = (
    r"C:\Drive Contents\a_ALL_EMULATORS\Retroarch 1.22.2"
    r"\RetroArch\RetroArch-Win64\retroarch.exe"
)


# ---------------------------------------------------------------- emulators

EMULATORS = {
    "retroarch": {
        "label": "RetroArch",
        "extensions": [],                       # comes from the core's .info file
        "hardcore": None,                       # handled with --appendconfig
    },
    "duckstation": {
        "label": "DuckStation",
        "extensions": ["cue", "chd", "iso", "pbp", "m3u", "ecm", "mds", "img", "exe", "psexe"],
        "hardcore": ("Cheevos", "ChallengeMode", "true", "false"),
    },
    "pcsx2": {
        "label": "PCSX2",
        "extensions": ["iso", "chd", "cso", "zso", "gz", "bin", "mdf", "elf"],
        "hardcore": ("Achievements", "ChallengeMode", "true", "false"),
    },
    "dolphin": {
        "label": "Dolphin",
        "extensions": ["iso", "rvz", "gcz", "wbfs", "wia", "ciso", "gcm", "tgc", "wad", "dol", "elf"],
        "hardcore": ("Achievements", "HardcoreEnabled", "True", "False"),
    },
    "ppsspp": {
        "label": "PPSSPP",
        "extensions": ["iso", "cso", "chd", "pbp", "elf", "prx"],
        "hardcore": ("Achievements", "AchievementsChallengeMode", "True", "False"),
    },
    "rapplewin": {
        "label": "RAppleWin",
        "extensions": ["dsk", "do", "po", "nib", "woz", "2mg", "hdv"],
        # RetroAchievements toolkit preferences: a JSON file, not an INI section
        "hardcore": ("json", "Hardcore Active", True, False),
    },
}

# RetroAchievements' own standalone Windows emulators. Like RAppleWin they keep the hardcore
# setting in RACache\RAPrefs_<name>.cfg beside the .exe, and take the game path as an argument.
#   key: (label, prefs name, words that identify the .exe, extensions)
RA_STANDALONES = {
    "rap64": ("RAP64 (Nintendo 64)", "RAP64", ["rap64"], ["z64", "n64", "v64", "zip"]),
    "ravba": ("RAVBA (Game Boy / Color / Advance)", "RAVBA", ["ravba"], ["gb", "gbc", "gba", "zip"]),
    "rasnes9x": ("RASnes9x (SNES)", "RASnes9x", ["rasnes9x"], ["sfc", "smc", "zip"]),
    "ranes": ("RANes (NES)", "RANes", ["ranes"], ["nes", "zip"]),
    "rameka": ("RAMeka (Master System / Game Gear / SG-1000 / ColecoVision)", "RAMeka", ["rameka"],
               ["sms", "gg", "sg", "col", "zip"]),
    "raquasi88": ("RAQUASI88 (PC-8800)", "RAQUASI88", ["raquasi88", "quasi88"], ["d88", "t88", "cmt"]),
}
for _key, (_label, _prefs, _words, _exts) in RA_STANDALONES.items():
    EMULATORS[_key] = {"label": _label, "extensions": _exts,
                       "hardcore": ("json", "Hardcore Active", True, False)}
EMULATORS["other"] = {"label": "Other", "extensions": [], "hardcore": None}
TYPE_BY_LABEL = {v["label"]: k for k, v in EMULATORS.items()}


def detect_type(exe):
    name = os.path.basename(exe).lower()
    for key in ("retroarch", "duckstation", "pcsx2", "dolphin", "ppsspp"):
        if key in name:
            return key
    if "applewin" in name:
        return "rapplewin"
    for key, (_label, _prefs, words, _exts) in RA_STANDALONES.items():
        if any(w in name for w in words):
            return key
    return "other"


def config_candidates(emu_type, exe):
    """Likely locations of the settings file that holds the hardcore option."""
    d = os.path.dirname(exe)
    home = os.path.expanduser("~")
    docs = os.path.join(home, "Documents")
    local = os.environ.get("LOCALAPPDATA", os.path.join(home, "AppData", "Local"))
    roaming = os.environ.get("APPDATA", os.path.join(home, "AppData", "Roaming"))
    portable = any(os.path.exists(os.path.join(d, p)) for p in ("portable.txt", "portable.ini"))

    if emu_type == "duckstation":
        if portable:
            return [os.path.join(d, "settings.ini")]
        return [os.path.join(local, "DuckStation", "settings.ini"),
                os.path.join(docs, "DuckStation", "settings.ini"),
                os.path.join(d, "settings.ini")]
    if emu_type == "pcsx2":
        if portable:
            return [os.path.join(d, "inis", "PCSX2.ini")]
        return [os.path.join(docs, "PCSX2", "inis", "PCSX2.ini"),
                os.path.join(d, "inis", "PCSX2.ini")]
    if emu_type == "ppsspp":
        # Portable builds keep a "memstick" folder beside the exe; installed ones use Documents
        return [os.path.join(d, "memstick", "PSP", "SYSTEM", "ppsspp.ini"),
                os.path.join(docs, "PPSSPP", "PSP", "SYSTEM", "ppsspp.ini")]
    if emu_type == "rapplewin" or emu_type in RA_STANDALONES:
        cache = os.path.join(d, "RACache")
        prefs = "RAppleWin" if emu_type == "rapplewin" else RA_STANDALONES[emu_type][1]
        expected = os.path.join(cache, f"RAPrefs_{prefs}.cfg")
        if os.path.isfile(expected):
            return [expected]
        found = []
        if os.path.isdir(cache):
            found = sorted(os.path.join(cache, f) for f in os.listdir(cache)
                           if f.lower().startswith("raprefs") and f.lower().endswith(".cfg"))
        return found or [expected]
    if emu_type == "dolphin":
        if portable:
            return [os.path.join(d, "User", "Config", "RetroAchievements.ini")]
        return [os.path.join(roaming, "Dolphin Emulator", "Config", "RetroAchievements.ini"),
                os.path.join(docs, "Dolphin Emulator", "Config", "RetroAchievements.ini"),
                os.path.join(d, "User", "Config", "RetroAchievements.ini")]
    return []


def detect_config(emu_type, exe):
    candidates = config_candidates(emu_type, exe)
    for path in candidates:
        if os.path.isfile(path):
            return path
    # Dolphin only creates RetroAchievements.ini once achievements are set up,
    # so fall back to a candidate whose Config folder already exists.
    for path in candidates:
        if os.path.isdir(os.path.dirname(path)):
            return path
    return ""


def set_ini_value(path, section, key, value):
    """Set key=value inside [section] of an INI file, keeping everything else as it was."""
    lines = []
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            lines = f.read().splitlines(keepends=True)
    newline = "\r\n" if any(l.endswith("\r\n") for l in lines) else "\n"

    current = None
    section_found = False
    insert_at = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            if current is not None and current.lower() == section.lower() and insert_at is None:
                insert_at = i
            current = stripped[1:-1].strip()
            if current.lower() == section.lower():
                section_found = True
            continue
        if current is not None and current.lower() == section.lower():
            k, sep, _ = stripped.partition("=")
            if sep and k.strip().lower() == key.lower():
                lines[i] = f"{key} = {value}{newline}"
                break
    else:
        if section_found:
            if insert_at is None:
                insert_at = len(lines)
                if lines and not lines[-1].endswith(("\n", "\r")):
                    lines[-1] += newline
            # Insert before any blank lines that separate it from the next section
            while insert_at > 0 and not lines[insert_at - 1].strip():
                insert_at -= 1
            lines.insert(insert_at, f"{key} = {value}{newline}")
        else:
            if lines and not lines[-1].endswith(("\n", "\r")):
                lines[-1] += newline
            if lines:
                lines.append(newline)
            lines += [f"[{section}]{newline}", f"{key} = {value}{newline}"]

    with open(path, "w", encoding="utf-8", newline="") as f:
        f.writelines(lines)


def set_json_value(path, key, value):
    """Set one key in a JSON preferences file (RetroAchievements toolkit emulators), keeping the rest."""
    data = {}
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8-sig") as f:
            text = f.read().strip()
        if text:
            data = json.loads(text)
    data[key] = value
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def write_hardcore(emu_type, path, on):
    section, key, true_val, false_val = EMULATORS[emu_type]["hardcore"]
    if section == "json":
        set_json_value(path, key, true_val if on else false_val)
    else:
        set_ini_value(path, section, key, true_val if on else false_val)


# ---------------------------------------------------------------- RetroArch cores

def cores_dir(retroarch_exe):
    return os.path.join(os.path.dirname(retroarch_exe), "cores")


def list_cores(retroarch_exe):
    folder = cores_dir(retroarch_exe)
    if not os.path.isdir(folder):
        return []
    return sorted(f for f in os.listdir(folder) if f.lower().endswith((".dll", ".so", ".dylib")))


def info_dir(retroarch_exe):
    """Find RetroArch's core info folder (libretro_info_path in retroarch.cfg, else <exe dir>\\info)."""
    base = os.path.dirname(retroarch_exe)
    cfg = os.path.join(base, "retroarch.cfg")
    if os.path.isfile(cfg):
        try:
            with open(cfg, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    key, sep, value = line.partition("=")
                    if sep and key.strip() == "libretro_info_path":
                        value = value.strip().strip('"')
                        if value.startswith(":"):          # ":" means relative to RetroArch's folder
                            value = os.path.join(base, value[1:].lstrip("\\/"))
                        if value and value.lower() != "default" and os.path.isdir(value):
                            return value
                        break
        except OSError:
            pass
    return os.path.join(base, "info")


def read_core_info(retroarch_exe, core_filename):
    """Read the .info file that matches a core, e.g. snes9x_libretro.dll -> snes9x_libretro.info."""
    stem = os.path.splitext(core_filename)[0]
    path = os.path.join(info_dir(retroarch_exe), stem + ".info")
    info = {}
    if not os.path.isfile(path):
        return info
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                key, sep, value = line.partition("=")
                if sep:
                    info[key.strip()] = value.strip().strip('"')
    except OSError:
        pass
    return info


def core_extensions(info):
    raw = info.get("supported_extensions", "")
    return [e.strip().lower() for e in raw.split("|") if e.strip()]
