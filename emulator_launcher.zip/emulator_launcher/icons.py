"""System icons.

- Game lists: RetroAchievements' small (32×32) console icons, matched to each system
  automatically and downloaded once into metadata/images/systems.
- Cards: optional larger art from the KyleBing retro-game-console-icons pack (GPL-3.0),
  downloaded on request into metadata/images/card_art.
"""

import os
import re
import urllib.parse

from .emulators import read_core_info
from .metadata import http_get
from .paths import IMAGES_DIR

RA_ICON_URL = "https://static.retroachievements.org/assets/images/system/{}.png"
PACK_URL = ("https://raw.githubusercontent.com/KyleBing/retro-game-console-icons/main/"
            "series_trimui/300w@1x/{}.png")
ICON_DIR = os.path.join(IMAGES_DIR, "systems")
CARD_ART_DIR = os.path.join(IMAGES_DIR, "card_art")

# (RetroAchievements icon file, name, words in a system/console name, words in a core or emulator)
# Order matters: more specific systems come before ones whose names they contain.
RA_SYSTEMS = [
    ("3ds", "Nintendo 3DS", ["3ds", "nintendo 3ds"], ["citra"]),
    ("dsi", "Nintendo DSi", ["dsi"], []),
    ("ds", "Nintendo DS", ["nintendo ds", "nds", "ds"], ["desmume", "melonds"]),
    ("gba", "Game Boy Advance", ["game boy advance", "gameboy advance", "gba"], ["mgba", "vba", "gpsp", "meteor"]),
    ("gbc", "Game Boy Color", ["game boy color", "gameboy color", "gbc"], []),
    ("gb", "Game Boy", ["game boy", "gameboy", "gb"], ["gambatte", "sameboy", "gearboy", "tgbdual"]),
    ("vb", "Virtual Boy", ["virtual boy", "vb"], ["mednafen_vb", "beetle_vb"]),
    ("mini", "Pokémon Mini", ["pokemon mini", "pokémon mini", "pokemini"], ["pokemini"]),
    ("fds", "Famicom Disk System", ["famicom disk system", "fds"], []),
    ("snes", "SNES / Super Famicom", ["snes", "super nintendo", "super famicom", "sfc"], ["snes9x", "bsnes", "mesen-s", "mesen_s"]),
    ("nes", "NES / Famicom", ["nes", "famicom", "nintendo entertainment system"], ["nestopia", "fceumm", "mesen", "quicknes"]),
    ("n64", "Nintendo 64", ["nintendo 64", "n64"], ["mupen64", "parallel_n64"]),
    ("wiiu", "Wii U", ["wii u", "wiiu"], ["cemu"]),
    ("wii", "Wii", ["wii"], []),
    ("gc", "GameCube", ["gamecube", "game cube", "ngc", "gc"], ["dolphin"]),
    ("32x", "Sega 32X", ["32x"], []),
    ("scd", "Sega CD", ["sega cd", "mega cd", "mega-cd", "segacd"], []),
    ("md", "Genesis / Mega Drive", ["genesis", "mega drive", "megadrive", "md"], ["genesis_plus_gx", "picodrive", "blastem"]),
    ("sms", "Master System", ["master system", "sms", "mark iii"], []),
    ("gg", "Game Gear", ["game gear", "gg"], []),
    ("sg1k", "SG-1000", ["sg-1000", "sg1000"], []),
    ("sat", "Sega Saturn", ["saturn"], ["yabause", "kronos", "mednafen_saturn", "beetle_saturn"]),
    ("dc", "Dreamcast", ["dreamcast"], ["flycast", "redream"]),
    ("pico-8", "PICO-8", ["pico-8", "pico8"], []),
    ("pico", "Sega Pico", ["sega pico", "pico"], []),
    ("ps3", "PlayStation 3", ["playstation 3", "ps3"], ["rpcs3"]),
    ("ps2", "PlayStation 2", ["playstation 2", "ps2"], ["pcsx2"]),
    ("psp", "PlayStation Portable", ["playstation portable", "psp"], ["ppsspp"]),
    ("ps1", "PlayStation", ["playstation", "psx", "ps1", "psone"],
     ["duckstation", "swanstation", "pcsx_rearmed", "mednafen_psx", "beetle_psx"]),
    ("pccd", "PC Engine CD", ["pc engine cd", "turbografx-cd", "turbografx cd", "pce cd", "pcecd"], []),
    ("pce", "PC Engine / TurboGrafx-16", ["pc engine", "turbografx", "pce", "tg16"], ["mednafen_pce", "beetle_pce"]),
    ("pc-fx", "PC-FX", ["pc-fx", "pcfx"], ["pcfx"]),
    ("ngcd", "Neo Geo CD", ["neo geo cd", "neogeo cd", "neocd"], ["neocd"]),
    ("ngp", "Neo Geo Pocket", ["neo geo pocket", "ngp", "ngpc"], ["mednafen_ngp", "race"]),
    ("arc", "Arcade", ["arcade", "mame", "fbneo", "neo geo", "neogeo", "cps1", "cps2", "cps3"], ["mame", "fbneo", "fbalpha"]),
    ("lynx", "Atari Lynx", ["lynx"], ["handy"]),
    ("jcd", "Atari Jaguar CD", ["jaguar cd"], []),
    ("jag", "Atari Jaguar", ["jaguar"], ["virtualjaguar"]),
    ("7800", "Atari 7800", ["7800"], ["prosystem"]),
    ("5200", "Atari 5200", ["5200"], []),
    ("2600", "Atari 2600", ["2600", "atari vcs"], ["stella"]),
    ("a2", "Apple II", ["apple ii", "apple 2", "apple2"], ["applewin", "rapplewin"]),
    ("c64", "Commodore 64", ["commodore 64", "c64"], ["vice_x64"]),
    ("amiga", "Amiga", ["amiga"], ["puae"]),
    ("msx", "MSX", ["msx", "msx2"], ["bluemsx", "fmsx"]),
    ("cpc", "Amstrad CPC", ["amstrad", "cpc"], ["cap32", "crocods"]),
    ("zxs", "ZX Spectrum", ["zx spectrum", "spectrum"], ["fuse"]),
    ("zx81", "ZX81", ["zx81"], ["81_libretro"]),
    ("ws", "WonderSwan", ["wonderswan"], ["mednafen_wswan", "beetle_wswan"]),
    ("3do", "3DO", ["3do"], ["opera", "4do"]),
    ("intv", "Intellivision", ["intellivision"], ["freeintv"]),
    ("cv", "ColecoVision", ["colecovision", "coleco"], []),
    ("vect", "Vectrex", ["vectrex"], ["vecx"]),
    ("dos", "DOS", ["dos", "ms-dos"], ["dosbox"]),
    ("tic-80", "TIC-80", ["tic-80", "tic80"], ["tic80"]),
    ("g&w", "Game & Watch", ["game & watch", "game and watch", "game&watch"], ["gw_libretro"]),
    ("duck", "Mega Duck", ["mega duck", "megaduck"], []),
    ("ard", "Arduboy", ["arduboy"], ["arduous"]),
    ("wsv", "Watara Supervision", ["supervision"], ["potator"]),
    ("chf", "Fairchild Channel F", ["channel f"], ["freechaf"]),
    ("ti-83", "TI-83", ["ti-83", "ti83"], []),
    ("uze", "Uzebox", ["uzebox"], ["uzem"]),
    ("cd-i", "Philips CD-i", ["cd-i", "cdi"], ["same_cdi"]),
    ("n-gage", "N-Gage", ["n-gage", "ngage"], []),
    ("xbox", "Xbox", ["xbox"], ["xemu"]),
    ("fm-towns", "FM Towns", ["fm towns", "fm-towns"], []),
    ("8088", "PC-8000/8800", ["pc-88", "pc88", "pc-8800", "pc-8801"], ["quasi88"]),
    ("9800", "PC-9800", ["pc-98", "pc98", "pc-9801"], ["np2kai"]),
    ("wasm4", "WASM-4", ["wasm-4", "wasm4"], []),
    ("elek", "Elektor TV Games", ["elektor"], []),
    ("vc4000", "VC 4000", ["vc 4000", "vc4000"], []),
    ("a2001", "Arcadia 2001", ["arcadia"], []),
    ("escv", "Super Cassette Vision", ["super cassette vision"], []),
    ("ecv", "Cassette Vision", ["cassette vision"], []),
    ("mo2", "Magnavox Odyssey 2", ["odyssey 2", "odyssey2", "videopac"], ["o2em"]),
    ("zeebo", "Zeebo", ["zeebo"], []),
    ("chip-8", "CHIP-8", ["chip-8", "chip8"], []),
]
RA_NAMES = {f: name for f, name, _, _ in RA_SYSTEMS}

# KyleBing pack icon suggested for each RetroAchievements system
PACK_FOR_RA = {
    "gb": "GB", "gbc": "GBC", "gba": "GBA", "nes": "FC", "snes": "SFC", "n64": "N64", "gc": "NGC",
    "ds": "NDS", "vb": "VB", "fds": "FDS", "md": "MD", "sms": "MS", "gg": "GG", "32x": "SEGA32X",
    "scd": "SEGACD", "sat": "SATURN", "dc": "DC", "sg1k": "SG1000", "ps1": "PS", "psp": "PSP",
    "pce": "PCE", "pccd": "PCECD", "pc-fx": "PCFX", "ngcd": "NEOCD", "ngp": "NGP", "arc": "ARCADE",
    "lynx": "LYNX", "7800": "ATARI7800", "5200": "ATARI5200", "2600": "ATARI2600", "c64": "C64",
    "amiga": "AMIGA", "msx": "MSX", "cpc": "CPC", "intv": "INTELLIVISION", "cv": "COLECO",
    "vect": "VECTREX", "dos": "DOS", "pico": "PICO", "tic-80": "TIC", "g&w": "GW", "duck": "MEGADUCK",
    "ard": "ARDUBOY", "wsv": "SUPERVISION", "chf": "CHANNELF", "ti-83": "TI83", "uze": "UZEBOX",
    "mini": "POKEMINI", "mo2": "VIDEOPAC", "8088": "PC88", "9800": "PC98",
}

# All console icons in the pack, with friendlier names where the file name is cryptic
PACK_ICONS = [
    "ADVMAME", "AMIGA", "AMIGACD", "AMIGACDTV", "ARCADE", "ARCADE_FBNEO", "ARDUBOY", "ATARI2600",
    "ATARI5200", "ATARI7800", "ATARI800-alt", "ATARI800", "ATARIST", "ATOMISWAVE", "C64",
    "CANNONBALL", "CAVESTORY", "CHAILOVE", "CHANNELF", "COLECO", "COLSGM", "CPC", "CPET", "CPLUS4",
    "CPS1", "CPS2", "CPS3", "DAPHNE", "DC", "DINOTHAWR", "DOOM", "DOS", "EASYRPG", "ENTERPRISE",
    "FBNEO", "FC", "FDS", "FLASHBACK", "GB", "GBA", "GBC", "GG", "GW", "INTELLIVISION", "LOWRESNX",
    "LUTRO", "LYNX", "MAME", "MAME2003PLUS", "MAME2010", "MD", "MDMSU", "MEGADUCK", "MS", "MSX",
    "MSX2", "N64", "N64DD", "NAOMI", "NDS", "NEOCD", "NEOGEO", "NGC", "NGP", "OPENBOR", "PALMOS",
    "PANASONIC", "PC88", "PC98", "PCE", "PCECD", "PCFX", "PGM", "PICO", "POKEMINI", "PORTS", "PS",
    "PSP", "PSPMINIS", "SATELLAVIEW", "SATURN", "SCUMMVM", "SEGA32X", "SEGACD", "SFC", "SFCMSU",
    "SFX", "SG1000", "SGB", "SUFAMI", "SUPERVISION-alt", "SUPERVISION", "THOMSON", "TI83", "TIC",
    "TYRQUAKE", "UZEBOX", "VB", "VECTREX", "VIC20", "VIDEOPAC-alt", "VIDEOPAC", "VIDEOS", "VIDEOTON",
]
PACK_LABELS = {
    "FC": "NES / Famicom", "SFC": "SNES / Super Famicom", "MD": "Genesis / Mega Drive",
    "MS": "Master System", "GG": "Game Gear", "GB": "Game Boy", "GBC": "Game Boy Color",
    "GBA": "Game Boy Advance", "SGB": "Super Game Boy", "NDS": "Nintendo DS", "N64": "Nintendo 64",
    "N64DD": "Nintendo 64DD", "NGC": "GameCube", "VB": "Virtual Boy", "FDS": "Famicom Disk System",
    "PS": "PlayStation", "PSP": "PlayStation Portable", "PSPMINIS": "PSP minis", "DC": "Dreamcast",
    "SATURN": "Sega Saturn", "SEGACD": "Sega CD", "SEGA32X": "Sega 32X", "SG1000": "SG-1000",
    "PCE": "PC Engine / TurboGrafx-16", "PCECD": "PC Engine CD", "PCFX": "PC-FX", "SFX": "SuperGrafx",
    "NEOGEO": "Neo Geo", "NEOCD": "Neo Geo CD", "NGP": "Neo Geo Pocket", "ARCADE": "Arcade",
    "ATARI2600": "Atari 2600", "ATARI5200": "Atari 5200", "ATARI7800": "Atari 7800",
    "ATARI800": "Atari 800", "ATARIST": "Atari ST", "LYNX": "Atari Lynx", "C64": "Commodore 64",
    "VIC20": "VIC-20", "CPLUS4": "Commodore Plus/4", "CPET": "Commodore PET", "CPC": "Amstrad CPC",
    "COLECO": "ColecoVision", "INTELLIVISION": "Intellivision", "VECTREX": "Vectrex",
    "GW": "Game & Watch", "POKEMINI": "Pokémon Mini", "MEGADUCK": "Mega Duck", "PICO": "Sega Pico",
    "TIC": "TIC-80", "TI83": "TI-83", "VIDEOPAC": "Odyssey 2 / Videopac", "CHANNELF": "Channel F",
    "SATELLAVIEW": "Satellaview", "SUFAMI": "Sufami Turbo", "MDMSU": "Mega Drive MSU-1",
    "SFCMSU": "SNES MSU-1", "PC88": "PC-88", "PC98": "PC-98", "AMIGA": "Amiga",
    "AMIGACD": "Amiga CD32", "AMIGACDTV": "Amiga CDTV", "DOS": "DOS", "MSX": "MSX", "MSX2": "MSX2",
    "SCUMMVM": "ScummVM", "SUPERVISION": "Watara Supervision", "UZEBOX": "Uzebox",
}


def pack_label(name):
    base = name.replace("-alt", "")
    label = PACK_LABELS.get(base, base.replace("_", " ").title())
    return label + (" (alt)" if name.endswith("-alt") else "")


# ---------------------------------------------------------------- matching

def _has_word(text, word):
    return re.search(r"(?<![a-z0-9])" + re.escape(word) + r"(?![a-z0-9])", text) is not None


def match_ra(folder):
    """Best RetroAchievements icon for a system, from its name, core and emulator. '' if unsure."""
    core = folder.get("core", "")
    texts = [folder.get("name", "")]          # the name you gave the system wins
    if core and folder.get("emulator_exe"):
        info = read_core_info(folder["emulator_exe"], core)
        texts.append(info.get("systemname", ""))
        texts.append(info.get("display_name", ""))
    for text in texts:
        text = text.lower()
        for file, _name, keys, _cores in RA_SYSTEMS:
            if any(_has_word(text, k) for k in keys):
                return file
    engine = " ".join([core, folder.get("emulator_type", ""),
                       os.path.basename(folder.get("emulator_exe", ""))]).lower()
    for file, _name, _keys, cores in RA_SYSTEMS:
        if any(c in engine for c in cores):
            return file
    return ""


def list_icon_file(folder):
    """The RetroAchievements icon chosen for a system: its override, else the automatic match."""
    choice = folder.get("list_icon", "")
    if choice == "none":
        return ""
    return choice or match_ra(folder)


def suggested_pack_icon(folder):
    return PACK_FOR_RA.get(list_icon_file(folder) or match_ra(folder), "")


# ---------------------------------------------------------------- downloads

def _download(url, path, timeout=15):
    try:
        data = http_get(url, retries=0, timeout=timeout)
    except Exception:
        return False
    if not data or not data.startswith(b"\x89PNG"):
        return False
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, path)
    return True


def ra_icon_path(file):
    return os.path.join(ICON_DIR, file.replace("&", "and") + ".png")


def fetch_ra_icon(file):
    """Download one RetroAchievements system icon if it isn't cached yet. Returns its path or ''."""
    path = ra_icon_path(file)
    if os.path.isfile(path) or _download(RA_ICON_URL.format(urllib.parse.quote(file)), path):
        return path
    return ""


def pack_icon_path(name):
    return os.path.join(CARD_ART_DIR, name + ".png")


def fetch_pack_icon(name):
    """Download one icon from the KyleBing pack if it isn't cached yet. Returns its path or ''."""
    path = pack_icon_path(name)
    if os.path.isfile(path) or _download(PACK_URL.format(urllib.parse.quote(name)), path, timeout=30):
        return path
    return ""
