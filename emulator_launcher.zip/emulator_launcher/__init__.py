"""Emulator Launcher package. Run launcher.pyw to start the app."""
