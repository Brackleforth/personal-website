"""Finding games in ROM folders: playlists, cue sheets, one-folder-per-game, multi-disk sets."""

import os
import re
import shlex

# Files that usually sit in ROM folders but are not games
IGNORED_EXTENSIONS = {
    ".txt", ".nfo", ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".pdf",
    ".xml", ".json", ".dat", ".srm", ".sav", ".state", ".ini", ".cfg",
    ".db", ".lpl", ".url", ".md", ".sbi", ".mcd", ".mcr",
}

def norm_path(path):
    return os.path.normcase(os.path.normpath(path))


def _referenced_files(playlist):
    """Files that an .m3u or .cue points to (discs, or a cue's .bin/.img tracks)."""
    base = os.path.dirname(playlist)
    ext = os.path.splitext(playlist)[1].lower()
    refs = set()
    try:
        with open(playlist, "r", encoding="utf-8-sig", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                if ext == ".m3u":
                    if line.startswith("#"):
                        continue
                    target = line
                elif line.upper().startswith("FILE "):
                    rest = line[5:].strip()
                    if rest.startswith('"'):
                        target = rest[1:].split('"', 1)[0]
                    else:
                        target = rest.rsplit(" ", 1)[0]
                else:
                    continue
                refs.add(norm_path(os.path.join(base, target)))
    except OSError:
        pass
    return refs


def scan_games(folder_entry):
    """Return a sorted list of (display_name, full_path) for one registered folder.

    - Searches subfolders, so one-folder-per-game layouts work (unless the system has
      "subfolders": False, which keeps to the folder itself).
    - An .m3u playlist replaces the discs it lists; files a .cue points to are hidden.
    - A subfolder holding a single game is shown by the subfolder's name.
    """
    path = folder_entry["path"]
    exts = {e.lower() if e.startswith(".") else "." + e.lower()
            for e in folder_entry.get("extensions", []) if e}
    if not os.path.isdir(path):
        return []

    # Pass 1: every file that passes the extension filter
    candidates = []
    subfolders = folder_entry.get("subfolders", True)
    for root, dirs, files in os.walk(path):
        if not subfolders:
            dirs[:] = []                       # the folder itself only
        for name in files:
            ext = os.path.splitext(name)[1].lower()
            if exts:
                if ext not in exts:
                    continue
            elif ext in IGNORED_EXTENSIONS:
                continue
            candidates.append(os.path.join(root, name))

    # Pass 2: hide whatever a listed playlist or cue sheet refers to
    referenced = set()
    for full in candidates:
        if os.path.splitext(full)[1].lower() in (".m3u", ".cue"):
            referenced |= _referenced_files(full)
    kept = [f for f in candidates if norm_path(f) not in referenced]

    # Pass 3: collapse multi-disk sets into one entry that boots the first disk
    per_dir = {}
    for full in kept:
        per_dir.setdefault(os.path.dirname(full), []).append(full)

    games = []
    for folder, files in per_dir.items():
        items = []            # (launch path, name stem, number of disks)
        sets = {}
        for full in files:
            stem = os.path.splitext(os.path.basename(full))[0]
            info = disk_info(stem)
            if info is None:
                items.append((full, stem, 1))
            else:
                key = (info["key"], os.path.splitext(full)[1].lower())
                sets.setdefault(key, []).append((info, full))
        for members in sets.values():
            members.sort(key=lambda m: disk_order(m[0], m[1]))
            boot_info, boot = members[0]
            stem = os.path.splitext(os.path.basename(boot))[0]
            if len(members) == 1:
                items.append((boot, stem, 1))
            else:
                items.append((boot, boot_info["base"] or stem, len(members)))

        # Friendly names
        is_root = norm_path(folder) == norm_path(path)
        folder_name = os.path.basename(folder)
        for full, stem, count in items:
            if is_root:
                name = stem
            elif len(items) == 1:
                name = os.path.relpath(folder, path)
            elif stem.lower().startswith(folder_name.lower()):
                name = stem
            else:
                name = f"{folder_name} / {stem}"
            if count > 1:
                name += f"  ({count} disks)"
            games.append((name, full))
    games.sort(key=lambda g: g[0].lower())
    return games


# ---------------------------------------------------------------- multi-disk sets


# "(Disk 1 of 4 Side A)", "(Disk 2)", "(Disk B)", "(Disc 1)", "(Disk 1A)"
_DISK_PAREN = re.compile(
    r"\(\s*dis[kc]\s*(\d+|[a-h])\s*([ab])?\s*(?:of\s*\d+)?\s*(?:[-,]?\s*side\s*([ab12]))?[^)]*\)", re.I)
# "(Side A)", "(Side 2)"
_SIDE_PAREN = re.compile(r"\(\s*side\s*([ab12])\s*\)", re.I)
# "Ultima IV Disk 1A", "karateka_disk2", "Game - Disk 1 Side B"
_DISK_BARE = re.compile(r"[\s_\-]*\bdis[kc]\s*(\d+)\s*([ab])?\b(?:[\s_\-,]*side\s*([ab12])\b)?", re.I)
_SIDE_BARE = re.compile(r"[\s_\-]*\bside\s*([ab12])\b", re.I)
# "(Boot)", "[Program]", "(Boot Disk)"
_BOOT_TAG = re.compile(r"\s*[\(\[]\s*(?:boot|program)(?:\s*dis[kc])?\s*[\)\]]", re.I)


def disk_info(stem):
    """Read the disk number and side from a file name. None if it isn't part of a set."""
    disk = side = None
    boot = bool(_BOOT_TAG.search(stem))
    base = _BOOT_TAG.sub("", stem)

    m = _DISK_PAREN.search(base) or _DISK_BARE.search(base)
    if m:
        number = m.group(1)
        disk = int(number) if number.isdigit() else ord(number.lower()) - ord("a") + 1
        side = m.group(2) or m.group(3)
        rest = base[m.end():]
        # Anything after the disk tag is a per-disk label ("(Character Disk)", "[a]"), not the title
        base = base[:m.start()]
    else:
        rest = base
    m = _SIDE_PAREN.search(rest) or _SIDE_BARE.search(rest)
    if m:
        side = side or m.group(1)
        if disk is None:
            base = base[:m.start()]
    if disk is None and side is None and not boot:
        return None

    base = re.sub(r"\s{2,}", " ", base).strip(" -_")
    side_index = {"a": 0, "1": 0, "b": 1, "2": 1}.get((side or "a").lower(), 0)
    return {"base": base, "key": base.lower(), "disk": disk or 1, "side": side_index, "boot": boot}


def disk_order(info, path):
    """Boot/program disks first, then by disk number and side."""
    return (0 if info["boot"] else 1, info["disk"], info["side"], os.path.basename(path).lower())


def disk_set(path):
    """All disks in the same set as this file, boot disk first. Just [path] for single disks."""
    stem, ext = os.path.splitext(os.path.basename(path))
    info = disk_info(stem)
    folder = os.path.dirname(path)
    if info is None or not os.path.isdir(folder):
        return [path]
    members = []
    for name in os.listdir(folder):
        s, e = os.path.splitext(name)
        if e.lower() != ext.lower():
            continue
        other = disk_info(s)
        if other is not None and other["key"] == info["key"]:
            members.append((other, os.path.join(folder, name)))
    members.sort(key=lambda m: disk_order(m[0], m[1]))
    return [m[1] for m in members] or [path]


def split_args(text):
    """Split extra arguments, keeping Windows backslashes intact."""
    return [t[1:-1] if len(t) >= 2 and t[0] == t[-1] == '"' else t
            for t in shlex.split(text, posix=False)] if text.strip() else []


# ---------------------------------------------------------------- display helpers

_REGION_WORDS = re.compile(
    r"\b(USA|Europe|Japan|World|Germany|France|Spain|Italy|Korea|Australia|Brazil|Asia|"
    r"UK|Canada|China|Netherlands|Sweden|Taiwan|Hong Kong|Russia|Scandinavia)\b", re.I)
_TAG = re.compile(r"\s*[\(\[][^\(\)\[\]]*[\)\]]")
_DISK_COUNT = re.compile(r"\s+\(\d+ disks\)$")


def strip_tags(name):
    """'Donkey Kong Land III (USA, Europe) (Rev 1) (SGB Enhanced)' -> 'Donkey Kong Land III'.

    Keeps the '(4 disks)' count the launcher adds to multi-disk sets."""
    m = _DISK_COUNT.search(name)
    suffix = m.group(0) if m else ""
    core = name[:m.start()] if m else name
    cleaned = _TAG.sub("", core).strip()
    return (cleaned or core) + suffix


def region_of(path):
    """The region tag from a No-Intro/Redump-style file name, e.g. 'USA, Europe'."""
    stem = os.path.splitext(os.path.basename(path))[0]
    for group in re.findall(r"\(([^)]*)\)", stem):
        if _REGION_WORDS.search(group):
            return group
    return ""
