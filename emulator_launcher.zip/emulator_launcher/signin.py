"""Keep emulators signed in to RetroAchievements.

You sign in once with your password; RetroAchievements answers with a login token, the same
token every emulator uses. The password is never saved. Before a launch the token is written
where the emulator looks for it, so a token that went stale (after "Reset Connect Key" or a
password change on the website) is fixed for every emulator by one sign-in here.

Supported:
    RetroArch                 cheevos_username / cheevos_token in the launch override file
    PCSX2                     [Achievements] Username / Token in PCSX2.ini (PCSX2 moves the token
                              into its own protected storage when it starts)
    RAppleWin, RAP64, RAVBA…  "Username" / "Token" in RACache\\RAPrefs_<name>.cfg
Not supported: DuckStation stores its token encrypted, so a plain one would break its sign-in
(it signs itself in again when a game boots). Dolphin and PPSSPP: storage not documented.
"""

import json
import os
import time

from .emulators import RA_STANDALONES, set_ini_value, set_json_value

CONNECT_URL = "https://retroachievements.org/dorequest.php"
USER_AGENT = "EmulatorLauncher/1.0"
CHECK_EVERY = 24 * 3600          # ask RetroAchievements about the token at most once a day

JSON_PREFS = {"rapplewin"} | set(RA_STANDALONES)


def supports(emu_type):
    return emu_type in ("retroarch", "pcsx2") or emu_type in JSON_PREFS


class Unreachable(Exception):
    """RetroAchievements didn't answer (offline, server trouble): not a sign-in problem."""


def _post(params, timeout=8):
    import urllib.error
    import urllib.parse
    import urllib.request
    data = urllib.parse.urlencode(params).encode()      # POST, so the password isn't in a URL
    req = urllib.request.Request(CONNECT_URL, data=data, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
    except urllib.error.HTTPError as err:
        if err.code in (401, 403):
            body = err.read()                # rejected: the reply says why
        else:
            raise Unreachable(f"RetroAchievements answered {err.code}") from err
    except (urllib.error.URLError, OSError) as err:
        raise Unreachable(str(err)) from err
    try:
        return json.loads(body or b"{}")
    except ValueError as err:
        raise Unreachable("RetroAchievements sent an unexpected reply") from err


def login_with_password(username, password):
    """Returns (token, None) or (None, the reason it failed). Raises Unreachable."""
    reply = _post({"r": "login2", "u": username, "p": password})
    if reply.get("Success") and reply.get("Token"):
        return reply["Token"], None
    return None, reply.get("Error") or "RetroAchievements didn't accept that username and password."


def token_is_valid(username, token):
    """True or False. Raises Unreachable when RetroAchievements can't be asked."""
    reply = _post({"r": "login2", "u": username, "t": token})
    return bool(reply.get("Success"))


def check_due(settings):
    return time.time() - settings.get("ra_token_checked", 0) > CHECK_EVERY


# ---------------------------------------------------------------- writing it where emulators look

def retroarch_override_lines(username, token):
    """Lines for the --appendconfig file. An empty password makes RetroArch use the token,
    which is what RetroArch does itself after its first sign-in."""
    return [f'cheevos_username = "{username}"', f'cheevos_token = "{token}"', 'cheevos_password = ""']


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            text = f.read().strip()
        return json.loads(text) if text else {}
    except (OSError, ValueError):
        return {}


def write_login(emu_type, config_path, username, token):
    """Put the sign-in into an emulator's settings file. Returns True if anything changed.
    (RetroArch is handled through the override file instead.)"""
    if not config_path or not os.path.isdir(os.path.dirname(config_path)):
        return False
    if emu_type in JSON_PREFS:
        prefs = _read_json(config_path)
        if prefs.get("Username") == username and prefs.get("Token") == token:
            return False
        set_json_value(config_path, "Username", username)
        set_json_value(config_path, "Token", token)
        return True
    if emu_type == "pcsx2":
        set_ini_value(config_path, "Achievements", "Username", username)
        set_ini_value(config_path, "Achievements", "Token", token)
        set_ini_value(config_path, "Achievements", "LoginTimestamp", str(int(time.time())))
        return True
    return False
