"""Game details: hashing files, Hasheous lookups, RetroAchievements progress, cached images."""

import json
import os
import re
import threading
import time

from .library import norm_path, strip_tags
from .paths import IMAGES_DIR, METADATA_DIR, METADATA_PATH

HASHEOUS_LOOKUP = "https://hasheous.org/api/v1/Lookup/ByHash/md5/"
HASHEOUS_ORIGIN = "https://hasheous.org"
RA_API = "https://retroachievements.org/API/API_GetGameInfoAndUserProgress.php"
RA_COMPLETION = "https://retroachievements.org/API/API_GetUserCompletionProgress.php"
RA_HASHES = "https://retroachievements.org/API/API_GetGameHashes.php"
# Fields a description search may fill in; it never replaces anything already known
DESCRIPTION_FIELDS = ("description", "year", "publisher", "igdb_link")
RA_MEDIA = "https://media.retroachievements.org"
USER_AGENT = "EmulatorLauncher/1.0 (personal game launcher)"


def load_metadata():
    try:
        with open(METADATA_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def save_metadata(meta):
    os.makedirs(METADATA_DIR, exist_ok=True)
    tmp = METADATA_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=1)
    os.replace(tmp, METADATA_PATH)


def file_signature(path):
    """Size + modified time, so unchanged files aren't hashed again."""
    try:
        st = os.stat(path)
        return f"{st.st_size}:{int(st.st_mtime)}"
    except OSError:
        return ""


def hash_target(path):
    """The file whose hash identifies the game: first disc of an .m3u, data track of a .cue."""
    seen = set()
    while True:
        key = norm_path(path)
        if key in seen:
            return path
        seen.add(key)
        ext = os.path.splitext(path)[1].lower()
        if ext not in (".m3u", ".cue"):
            return path
        refs = []
        try:
            with open(path, "r", encoding="utf-8-sig", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    if ext == ".m3u" and line and not line.startswith("#"):
                        refs.append(line)
                    elif ext == ".cue" and line.upper().startswith("FILE "):
                        rest = line[5:].strip()
                        refs.append(rest[1:].split('"', 1)[0] if rest.startswith('"')
                                    else rest.rsplit(" ", 1)[0])
        except OSError:
            return path
        if not refs:
            return path
        path = os.path.join(os.path.dirname(path), refs[0])


def md5_candidates(path, cancel=None):
    """MD5s to try for a game file, most likely first.

    Includes a header-stripped variant for NES (16-byte iNES header) and
    SNES (512-byte copier header), since databases list headerless dumps."""
    import hashlib
    import zipfile

    def digest(stream, skip=0):
        h = hashlib.md5()
        if skip:
            stream.read(skip)
        while True:
            if cancel is not None and cancel.is_set():
                raise InterruptedError
            chunk = stream.read(1 << 20)
            if not chunk:
                break
            h.update(chunk)
        return h.hexdigest()

    target = hash_target(path)
    ext = os.path.splitext(target)[1].lower()
    results = []

    if ext == ".zip":
        with zipfile.ZipFile(target) as z:
            members = [m for m in z.infolist() if not m.is_dir()]
            if not members:
                return []
            member = max(members, key=lambda m: m.file_size)
            with z.open(member) as f:
                results.append(digest(f))
            with z.open(member) as f:
                head = f.read(16)
            size = member.file_size
            inner_ext = os.path.splitext(member.filename)[1].lower()
            opener = lambda: z.open(member)
            if head[:4] == b"NES\x1a":
                with opener() as f:
                    results.append(digest(f, 16))
            elif inner_ext in (".smc", ".sfc", ".fig", ".swc") and size % 1024 == 512:
                with opener() as f:
                    results.append(digest(f, 512))
        return results

    if not os.path.isfile(target):
        return []
    with open(target, "rb") as f:
        results.append(digest(f))
    size = os.path.getsize(target)
    with open(target, "rb") as f:
        head = f.read(16)
    if head[:4] == b"NES\x1a":
        with open(target, "rb") as f:
            results.append(digest(f, 16))
    elif ext in (".smc", ".sfc", ".fig", ".swc") and size % 1024 == 512:
        with open(target, "rb") as f:
            results.append(digest(f, 512))
    return results


def http_get(url, params=None, retries=2, timeout=60):
    """GET a URL. Returns bytes, or None for 404. Raises on other errors."""
    import time
    import urllib.error
    import urllib.parse
    import urllib.request
    if params:
        url += "?" + urllib.parse.urlencode(params)
    for attempt in range(retries + 1):
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json, */*"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as err:
            if err.code == 404:
                return None
            if err.code in (429, 500, 502, 503, 504) and attempt < retries:
                time.sleep(5 * (attempt + 1))
                continue
            raise


def hasheous_lookup(md5):
    data = http_get(HASHEOUS_LOOKUP + md5)
    if not data:
        return None
    try:
        return json.loads(data)
    except json.JSONDecodeError:
        return None


def parse_hasheous(data):
    """Pull the fields we display out of a Hasheous ByHash response."""
    info = {"source": "Hasheous"}
    info["title"] = data.get("name") or ""
    info["platform"] = (data.get("platform") or {}).get("name", "")
    info["publisher"] = (data.get("publisher") or {}).get("name", "")
    game_sig = ((data.get("signature") or {}).get("game") or {})
    info["year"] = (game_sig.get("year") or "")[:10]
    info["dat_name"] = ((data.get("signature") or {}).get("rom") or {}).get("name", "")

    for attr in data.get("attributes") or []:
        name = (attr.get("attributeName") or "").lower()
        if "description" in name and attr.get("value") and not info.get("description"):
            info["description"] = attr["value"]
        if name == "logo" and attr.get("link"):
            link = attr["link"]
            info["logo_url"] = link if link.startswith("http") else HASHEOUS_ORIGIN + link

    for m in data.get("metadata") or []:
        if m.get("status") != "Mapped" or not m.get("id"):
            continue
        source = (m.get("source") or "").lower()
        if source == "retroachievements":
            info["ra_id"] = str(m["id"])
        elif source == "igdb":
            info["igdb_link"] = m.get("link", "")
    return info


def ra_hashes(game_id, api_key):
    """MD5s RetroAchievements accepts for a game (its Supported Hashes page). Unpatched dumps first,
    since translations and hacks are rarely in other databases."""
    data = http_get(RA_HASHES, {"i": game_id, "y": api_key})
    try:
        results = (json.loads(data) if data else {}).get("Results") or []
    except (json.JSONDecodeError, AttributeError):
        return []
    results.sort(key=lambda h: bool(h.get("PatchUrl")))
    return [h["MD5"].lower() for h in results if h.get("MD5")]


def description_from_ra_hashes(game_id, api_key, skip=(), limit=10, cancel=None):
    """Look up the game's other known dumps on Hasheous until one has a description.

    For games matched to RetroAchievements whose own file Hasheous has no description for.
    Returns a dict of DESCRIPTION_FIELDS that were found (may be empty)."""
    skip = {m.lower() for m in skip if m}
    for md5 in [m for m in ra_hashes(game_id, api_key) if m not in skip][:limit]:
        if cancel is not None and cancel.is_set():
            break
        data = hasheous_lookup(md5)
        if data:
            info = parse_hasheous(data)
            if info.get("description"):
                found = {k: info[k] for k in DESCRIPTION_FIELDS if info.get(k)}
                found["description_md5"] = md5
                return found
        time.sleep(0.2)
    return {}


def add_description(record, found):
    """Fill only the fields the record is missing."""
    for k, v in found.items():
        if v and not record.get(k):
            record[k] = v
    record["desc_search_done"] = True


def ra_progress(game_id, username, api_key):
    data = http_get(RA_API, {"g": game_id, "u": username, "y": api_key, "a": 1})
    if not data:
        return None
    try:
        d = json.loads(data)
    except json.JSONDecodeError:
        return None
    if not isinstance(d, dict) or not (d.get("Title") or d.get("ID")):
        return None
    return {
        "title": d.get("Title", ""),
        "console": d.get("ConsoleName", ""),
        "developer": d.get("Developer", "") or "",
        "publisher": d.get("Publisher", "") or "",
        "genre": d.get("Genre", "") or "",
        "released": d.get("Released", "") or "",
        "boxart_url": RA_MEDIA + d["ImageBoxArt"] if d.get("ImageBoxArt") else "",
        "num_achievements": d.get("NumAchievements", 0) or 0,
        "earned": d.get("NumAwardedToUser", 0) or 0,
        "earned_hardcore": d.get("NumAwardedToUserHardcore", 0) or 0,
        "award": d.get("HighestAwardKind") or "",
    }


def ra_completion(username, api_key, cancel=None):
    """Your progress on every game you've played, in a few requests (500 games per page).

    Returns {game_id: {"earned", "earned_hardcore", "num_achievements"}}. Raises on network errors."""
    progress = {}
    offset = 0
    while True:
        if cancel is not None and cancel.is_set():
            raise InterruptedError
        data = http_get(RA_COMPLETION, {"u": username, "y": api_key, "c": 500, "o": offset})
        page = json.loads(data) if data else {}
        if not isinstance(page, dict):
            raise ValueError("Unexpected reply from RetroAchievements")
        results = page.get("Results") or []
        for r in results:
            progress[str(r.get("GameID"))] = {
                "earned": r.get("NumAwarded", 0) or 0,
                "earned_hardcore": r.get("NumAwardedHardcore", 0) or 0,
                "num_achievements": r.get("MaxPossible", 0) or 0,
                # "mastered", "completed", "beaten-hardcore", "beaten-softcore" or ""
                "award": r.get("HighestAwardKind") or "",
            }
        offset += len(results)
        if not results or offset >= (page.get("Total") or 0):
            return progress


# ---------------------------------------------------------------- RetroAchievements fallback

RA_CONSOLES = "https://retroachievements.org/API/API_GetConsoleIDs.php"
RA_GAME_LIST = "https://retroachievements.org/API/API_GetGameList.php"
RA_CACHE_DIR = os.path.join(METADATA_DIR, "retroachievements")
RA_CACHE_DAYS = 7              # refresh cached game lists weekly (new sets get added)
NAME_MATCH_THRESHOLD = 0.9     # how similar a name must be to count as the same game
_ra_lock = threading.Lock()
_ra_memory = {}


def _cached_json(name, url, params, max_age_days):
    """Fetch JSON, keeping a copy in metadata/retroachievements for max_age_days."""
    path = os.path.join(RA_CACHE_DIR, name)
    with _ra_lock:
        if name in _ra_memory:
            return _ra_memory[name]
        if os.path.isfile(path) and time.time() - os.path.getmtime(path) < max_age_days * 86400:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    _ra_memory[name] = json.load(f)
                    return _ra_memory[name]
            except (OSError, json.JSONDecodeError):
                pass
    data = http_get(url, params, timeout=90)
    value = json.loads(data) if data else None
    if value is None:
        return None
    os.makedirs(RA_CACHE_DIR, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(value, f)
    os.replace(tmp, path)
    with _ra_lock:
        _ra_memory[name] = value
    return value


def ra_console_id(ra_system, user, api_key):
    """RetroAchievements console ID for a system icon name like 'md' or 'ps1'."""
    consoles = _cached_json("consoles.json", RA_CONSOLES, {"y": api_key, "g": 1}, 30) or []
    for c in consoles:
        icon = os.path.splitext(os.path.basename(str(c.get("IconURL", ""))))[0]
        if icon == ra_system:
            return c.get("ID")
    return None


def ra_game_list(console_id, api_key):
    """Every game with achievements on a console, with the hashes RetroAchievements accepts."""
    games = _cached_json(f"games-{console_id}.json", RA_GAME_LIST,
                         {"y": api_key, "i": console_id, "f": 1, "h": 1}, RA_CACHE_DAYS)
    return games if isinstance(games, list) else []


def normalize_title(name):
    """'Legend of Zelda, The - A Link to the Past (USA)' -> 'legend of zelda a link to the past'."""
    import unicodedata
    name = strip_tags(name)
    name = re.sub(r"\s+\(\d+ disks\)$", "", name)
    # "Pokémon" -> "Pokemon"
    name = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii")
    name = name.lower().replace("&", " and ")
    name = re.sub(r"[^a-z0-9]+", " ", name)
    words = [w for w in name.split() if w not in ("the", "a", "an")]
    return " ".join(words)


_ROMAN = re.compile(r"^(i|ii|iii|iv|v|vi|vii|viii|ix|x|xi|xii|xiii|xiv|xv|xvi)$")


def _numbers(title):
    """Sequel markers in a normalized title: '7', 'vii', 'x5', '2000'..."""
    return {w for w in title.split() if any(ch.isdigit() for ch in w) or _ROMAN.match(w)}


def _name_candidates(path):
    """Names to try: the file name, and the folder name for one-folder-per-game layouts."""
    stem = os.path.splitext(os.path.basename(path))[0]
    folder = os.path.basename(os.path.dirname(path))
    names = [stem]
    if folder and normalize_title(folder) and normalize_title(folder) not in (normalize_title(stem),):
        names.append(folder)
    return [n for n in (normalize_title(x) for x in names) if n]


def ra_fallback(path, md5s, ra_system, user, api_key):
    """Find a game on RetroAchievements by accepted hash, then by name. Returns record fields or None."""
    import difflib
    try:
        console_id = ra_console_id(ra_system, user, api_key)
        if not console_id:
            return None
        games = ra_game_list(console_id, api_key)
    except Exception:
        return None
    # Hacks, homebrew, prototypes and subsets are marked with "~...~" or "[Subset"
    games = [g for g in games if not str(g.get("Title", "")).startswith("~")
             and "[subset" not in str(g.get("Title", "")).lower()]

    wanted = {m.lower() for m in md5s}
    for g in games:
        if wanted & {h.lower() for h in g.get("Hashes") or []}:
            return {"ra_id": str(g["ID"]), "title": g.get("Title", ""), "platform": g.get("ConsoleName", ""),
                    "source": "RetroAchievements", "match": "hash"}

    best, best_score = None, 0.0
    for name in _name_candidates(path):
        for g in games:
            # Some sets cover several releases: "Pokemon Red Version | Pokemon Blue Version"
            for part in str(g.get("Title", "")).split("|"):
                title = normalize_title(part)
                if not title:
                    continue
                if title == name:
                    score = 1.0
                elif _numbers(title) != _numbers(name):
                    continue      # "Final Fantasy IX" is never "Final Fantasy VII"
                else:
                    score = difflib.SequenceMatcher(None, name, title).ratio()
                if score > best_score:
                    best, best_score = g, score
            if best_score == 1.0:
                break
        if best_score == 1.0:
            break
    if best is not None and best_score >= NAME_MATCH_THRESHOLD:
        return {"ra_id": str(best["ID"]), "title": best.get("Title", ""),
                "platform": best.get("ConsoleName", ""), "source": "RetroAchievements",
                "match": "name", "match_score": round(best_score, 2)}
    return None


def download_image(url):
    """Save an image under metadata/images and return its local path ('' on failure)."""
    import hashlib
    if not url:
        return ""
    ext = os.path.splitext(url.split("?", 1)[0])[1].lower()
    if ext not in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
        ext = ".png"
    path = os.path.join(IMAGES_DIR, hashlib.md5(url.encode()).hexdigest() + ext)
    if os.path.isfile(path):
        return path
    try:
        data = http_get(url)
    except Exception:
        return ""
    if not data:
        return ""
    os.makedirs(IMAGES_DIR, exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)
    return path


def lookup_game(path, ra_user="", ra_key="", cancel=None, ra_system=""):
    """Hash a game, look it up, and return a metadata record for it.

    If Hasheous doesn't know the hash, or knows the game but has no RetroAchievements ID for it,
    and RetroAchievements credentials and the system's console are available, falls back to
    RetroAchievements: its own list of accepted hashes first, then the game's name."""
    record = {"signature": file_signature(path), "status": "nomatch"}
    md5s = md5_candidates(path, cancel)
    record["md5"] = md5s[0] if md5s else ""
    for md5 in md5s:
        data = hasheous_lookup(md5)
        if data:
            record.update(parse_hasheous(data))
            record["status"] = "matched"
            record["md5"] = md5
            break
    if not record.get("ra_id") and ra_user and ra_key and ra_system:
        record["name_search_done"] = True
        found = ra_fallback(path, md5s, ra_system, ra_user, ra_key)
        if found and record["status"] == "matched":
            # Keep Hasheous's details; just add the RetroAchievements game
            record["ra_id"] = found["ra_id"]
            record["ra_match"] = found["match"]
        elif found:
            record.update(found)
            record["status"] = "matched"
    if record["status"] == "matched":
        if record.get("ra_id") and ra_user and ra_key:
            try:
                ra = ra_progress(record["ra_id"], ra_user, ra_key)
                if ra:
                    record["ra"] = ra
            except Exception as err:
                record["ra_error"] = str(err)
        if record.get("ra_id") and not record.get("description") and ra_key:
            try:
                add_description(record, description_from_ra_hashes(
                    record["ra_id"], ra_key, skip=md5s, cancel=cancel))
            except Exception:
                pass
        cover_url = (record.get("ra") or {}).get("boxart_url") or record.get("logo_url", "")
        record["image"] = download_image(cover_url)
    return record
