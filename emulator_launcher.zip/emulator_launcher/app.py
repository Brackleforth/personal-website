"""
Emulator Launcher: the main window with an always-visible Hardcore / Casual toggle.

- Games tab: pick a system, search, and launch (double-click or Enter).
- Systems tab: register ROM folders. Each one has its own emulator
  (RetroArch, DuckStation, PCSX2, Dolphin, or any other .exe), and
  RetroArch folders also pick a core.
- The Hardcore toggle is applied right before every launch:
    RetroArch    -> --appendconfig with cheevos_hardcore_mode_enable
    DuckStation  -> settings.ini        [Cheevos]       ChallengeMode
    PCSX2        -> inis\\PCSX2.ini      [Achievements]  ChallengeMode
    Dolphin      -> RetroAchievements.ini [Achievements] HardcoreEnabled
  Other emulators are launched normally; their hardcore setting is left alone.

Settings are stored in launcher_config.json next to this script.
"""

import os
import queue
import re
import subprocess
import threading
import time
import uuid
import webbrowser
import tkinter as tk
from datetime import date, datetime
from tkinter import filedialog, ttk

from .controller import XInputPad
from . import icons
from .dialogs import (SMART_RULES, ActionPicker, ChoiceDialog, ColorPicker, FolderDialog, ReminderDialog,
                      SeriesDialog, SmartGroupDialog,
                      ask_string, ask_yes_no, show_error, show_info, show_warning)
from .emulators import (DEFAULT_RETROARCH, EMULATORS, cores_dir, detect_config,
                        write_hardcore)
from .library import disk_set, norm_path, scan_games, split_args, strip_tags
from .metadata import (add_description, apply_ra_search, description_from_ra_hashes, download_image,
                       file_signature, http_get, needs_ra_search, ra_fallback,
                       load_metadata, lookup_game, ra_completion,
                       ra_progress, save_metadata)
from .paths import OVERRIDE_CFG
from .settings import load_settings, save_settings
from . import achievements as ACH
from . import theme
from .theme import T, px, scrollbar
from . import reminders as R
from .widgets import (TargetBlock, ACCENTS, BIG_BUTTON_FONT, CardGrid, GameListView, ReminderStrip, TabBar,
                      list_icon_size, load_photo, popup_menu, ra_game_url)

SORTS = [("name", "Name"), ("release_old", "Release date (oldest first)"),
         ("release_new", "Release date (newest first)"), ("developer", "Developer"),
         ("publisher", "Publisher"), ("genre", "Genre"),
         ("progress", "Achievement progress"), ("achievements", "Most achievements"),
         ("ratio_low", "Retro Ratio (easiest first)"), ("ratio_high", "Retro Ratio (hardest first)")]
BEATEN_AWARDS = {"beaten-hardcore", "beaten-softcore", "completed", "mastered"}


def upgrade_rules(rules):
    """Smart groups made with the first set of rules, translated to the current ones."""
    rules = list(rules)
    old = {"started", "not_mastered", "not_beaten", "almost"}
    if not old & set(rules):
        return rules
    new = [r for r in rules if r not in old]
    if "started" in rules and "not_beaten" in rules:
        new.insert(0, "started_not_beaten")
    elif "started" in rules or "not_mastered" in rules:
        new.insert(0, "started_not_mastered")
    return new
SERIES_SORTS = [("custom", "Custom order")] + SORTS + [("system", "System")]


def release_key(text):
    """'1994-10-18', '1994-10-18 00:00:00', 'Oct 18, 1994' or '1994' -> sortable 'YYYY-MM-DD'."""
    import re
    if not text:
        return ""
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", text)
    if m:
        return "-".join(m.groups())
    m = re.search(r"(\d{4})-(\d{2})", text)
    if m:
        return f"{m.group(1)}-{m.group(2)}-00"
    m = re.search(r"\b(1[89]\d\d|20\d\d)\b", text)
    return f"{m.group(1)}-00-00" if m else ""


HOME_SORTS = [("recent", "Most recent (best match when searching)")] + SORTS + [("system", "System")]
RECENT_DAYS = 14                     # games drop off Home if not launched again within this
TAB_NAMES = ["home", "systems", "series", "settings"]


def played_label(timestamp):
    days = (date.today() - date.fromtimestamp(timestamp)).days
    if days <= 0:
        return "Today"
    if days == 1:
        return "Yesterday"
    return f"{days} days ago"


class Launcher:
    def __init__(self, root):
        self.root = root
        self.settings = load_settings()
        R.RESET_HOUR = int(self.settings.get("reminder_reset_hour", 4)) % 24
        self.process = None              # running emulator
        self.minimized_for_game = False
        self.scan_cache = {}             # system id -> scanned games, for card counts
        self.open_system_id = None       # system shown in the Systems tab's list
        self.open_series = None          # series shown in the Series tab's list
        self.meta = load_metadata()      # normalized rom path -> metadata record
        self.scan_thread = None
        self.scan_cancel = threading.Event()
        self.scan_queue = queue.Queue()
        self.scan_step = "Looking up"
        self.scan_stats = {"looked_up": 0, "achievements": 0, "new_unlocks": 0}
        self.icon_photos = {}            # RetroAchievements icon file -> PhotoImage for lists
        self.icon_files = {}             # system id -> icon file ('' for none)
        self.icon_requested = set()
        self.icon_queue = queue.Queue()
        self.icon_thread = None
        self.prune_counter = 0
        self.home_times = []             # last-played time for each Home row
        self.last_entry = None           # the game most recently launched
        self.ra_updates = queue.Queue()  # results of after-game achievement refreshes
        self.link_results = queue.Queue()  # results of linking a game to a RetroAchievements page

        self.restart_requested = False
        theme.apply(root, self.settings.get("theme", "dark"))

        root.title("Emulator Launcher")     # shown on the taskbar and in Alt+Tab, not in the title bar
        self.app_icons = [theme.make_icon(px(size)) for size in (16, 32, 48)]
        root.iconphoto(False, *self.app_icons)    # main window only; dialogs are left alone
        # 16:10, scaled for the screen's DPI but never larger than the screen
        screen_w, screen_h = root.winfo_screenwidth(), root.winfo_screenheight()
        width = min(px(1088), int(screen_w * 0.9), int(screen_h * 0.85 * 1.6))
        root.geometry(f"{width}x{int(width / 1.6)}")
        root.minsize(min(px(832), width), min(px(520), int(width / 1.6)))

        # App bar: tabs on the left, Hardcore toggle on the right
        self.app_bar = tk.Frame(root, padx=10, pady=8)
        self.app_bar.pack(fill="x")
        self.build_toggle_bar()
        tab_buttons = tk.Frame(self.app_bar)
        tab_buttons.pack(side="left", anchor="s")
        tk.Frame(root, height=1, bg=T["border"]).pack(fill="x", padx=10)
        self.notebook = TabBar(root, tab_buttons)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=(4, 6))
        self.build_home_tab()
        self.build_systems_tab()
        self.build_series_tab()
        self.ach_inflight = set()
        self.ach_tried = {}
        self.ratio_queue, self.ratio_busy, self.ratio_tried = [], set(), set()
        self.ratio_results = queue.Queue()
        self.ratio_running = False
        self.ach_results = queue.Queue()
        for view in (self.home_list, self.sys_list, self.ser_list):
            view.award_for = self.award_for_entry
            view.panel.ach_model = self.achievement_model
            view.panel.ach_request = self.request_achievements
            view.panel.on_mark = self.mark_achievement
            view.panel.show_badges = lambda: self.settings.get("achievement_badges", True)
            view.panel.is_target = self.is_target
            view.show_system_names = lambda: self.settings.get("show_system_names", True)
            view.panel.on_choose = (lambda v=view: v.selected_index() is not None
                                    and self.choose_candidate(v.entries[v.selected_index()]))
            view.game_running = self.is_running
            view.status_hint = lambda text: self.status.config(text=text) if text else self.set_idle_status()
        self.build_settings_tab()
        self.build_status_bar()
        self.notebook.bind("<<NotebookTabChanged>>", lambda e: self.on_tab_changed())
        self.root.bind_all("<MouseWheel>", self.on_mousewheel, add="+")
        self.root.bind_all("<Button-3>", self.on_right_click_back, add="+")

        self.prune_recent()
        self.refresh_all()
        self.refresh_reminders()
        self.apply_reminders_visibility()
        self.refresh_target()
        self.notebook.select(0)          # always open on Home
        self.set_idle_status()
        from . import settings as settings_module
        if settings_module.LOAD_WARNING:
            self.root.after(300, lambda: show_warning("Settings", settings_module.LOAD_WARNING, self.root))
        self.check_process()

        self.pad = XInputPad()
        self.pad_connected = False
        self.pad_prev = set()
        self.pad_repeat = {}
        self.desc_scroll = 0.0      # fractional lines carried between polls
        if self.pad.available:
            self.root.after(500, self.poll_pad)

    # ================================================================ layout

    def build_toggle_bar(self):
        self.toggle_btn = tk.Button(self.app_bar, font=BIG_BUTTON_FONT, width=14,
                                    command=self.toggle_hardcore,
                                    **({"relief": "raised"} if theme.is_classic()
                                       else {"relief": "flat", "bd": 0, "pady": 4}))
        self.toggle_btn.pack(side="right")
        # The achievement you're going for sits just left of the toggle (hidden when there's none)
        self.target_block = TargetBlock(self.app_bar, self.target_menu)
        self.target_block.on_click = self.go_to_target
        self.target_earned = None
        # Only used for occasional notes (game running, unsupported emulator)
        self.toggle_note = tk.Label(self.app_bar, fg=T["text_faint"], justify="right")
        self.toggle_note.pack(side="right", padx=12)

    def build_home_tab(self):
        tab = tk.Frame(self.notebook)
        self.notebook.add(tab, text="  Home  ")
        self.home_list = GameListView(tab, back=None, launch=self.launch,
                                      menu_items=self.home_menu_items, details=self.details_for,
                                      sorter=self.sort_recent, icon_for=self.icon_for_entry,
                                      sort_options=HOME_SORTS,
                                      sort_id=self.settings.get("sort_home", "recent"),
                                      on_sort=lambda sid: self.remember_sort("sort_home", sid),
                                      empty_text="Nothing played in the last two weeks",
                                      link=self.link_to_ra)
        self.home_list.pack(fill="both", expand=True)
        # Typing in Home's search box searches the whole library; clearing it shows Recently played
        self.home_searching = False
        self.home_list.search_hook = self.home_search

        self.home_list.after_search = self.set_idle_status
        self.home_list.search_entry.bind("<Escape>", lambda e: self.home_list.search_var.set(""))
        tk.Button(self.home_list.header, text="⏰  + Reminder", command=self.add_reminder).pack(
            side="right", padx=(px(12), 0))
        self.reminder_strip = ReminderStrip(self.home_list.extra, self.toggle_reminder, self.reminder_popup)

    def build_systems_tab(self):
        tab = tk.Frame(self.notebook)
        self.notebook.add(tab, text="  Systems  ")
        self.sys_grid = CardGrid(tab)
        self.sys_grid.on_swap = lambda i, j: self.swap_cards("folders", i, j)
        self.sys_list = GameListView(tab, back=self.show_system_cards, launch=self.launch,
                                     menu_items=self.system_menu_items, details=self.details_for,
                                     sort_options=SORTS, sorter=self.sort_entries,
                                     sort_id=self.settings.get("sort_systems", "name"),
                                     on_sort=lambda sid: self.remember_sort("sort_systems", sid),
                                     icon_for=self.icon_for_entry, link=self.link_to_ra)

    def build_series_tab(self):
        tab = tk.Frame(self.notebook)
        self.notebook.add(tab, text="  Groups  ")
        self.ser_grid = CardGrid(tab)
        self.ser_grid.on_swap = lambda i, j: self.swap_cards("series", i, j)
        self.ser_list = GameListView(tab, back=self.show_series_cards, launch=self.launch,
                                     menu_items=self.series_menu_items, details=self.details_for,
                                     sort_options=SERIES_SORTS, sorter=self.sort_entries,
                                     sort_id=self.settings.get("sort_series", "custom"),
                                     on_sort=lambda sid: self.remember_sort("sort_series", sid),
                                     icon_for=self.icon_for_entry, link=self.link_to_ra)

    def build_settings_tab(self):
        tab = tk.Frame(self.notebook, padx=8, pady=8)
        self.notebook.add(tab, text="  Settings  ")
        self.settings_tab = tab          # the controller outline is drawn on this page

        systems = tk.LabelFrame(tab, text="Systems", padx=8, pady=8)
        systems.pack(fill="x")
        columns = ("name", "emulator", "core", "folder")
        tree_frame = tk.Frame(systems, highlightthickness=0)
        tree_frame.pack(fill="x")
        self.tree_frame = tree_frame
        # Six rows is plenty; it scrolls if you have more systems
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="browse",
                                 height=6)
        for col, text, width in (("name", "Name", 170), ("emulator", "Emulator", 110),
                                 ("core", "Core", 170), ("folder", "ROM folder", 320)):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=px(width), anchor="w")
        tscroll = scrollbar(tree_frame, self.tree.yview)
        self.tree.config(yscrollcommand=tscroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        tscroll.pack(side="right", fill="y")
        self.tree.bind("<Double-Button-1>", lambda e: self.edit_system())

        btns = tk.Frame(systems)
        btns.pack(fill="x", pady=(6, 0))
        self.add_btn = tk.Button(btns, text="Add…", width=12, command=self.add_system)
        self.add_btn.pack(side="left")
        self.edit_btn = tk.Button(btns, text="Edit…", width=12, command=self.edit_system)
        self.edit_btn.pack(side="left", padx=6)
        self.remove_btn = tk.Button(btns, text="Remove", width=12, command=self.remove_system)
        self.remove_btn.pack(side="left")

        meta = tk.LabelFrame(tab, text="Game details (metadata)", padx=8, pady=6)
        meta.pack(fill="x", pady=(10, 0))
        creds = tk.Frame(meta)
        creds.pack(fill="x")
        tk.Label(creds, text="RetroAchievements username:").grid(row=0, column=0, sticky="e")
        self.ra_user_var = tk.StringVar(value=self.settings.get("ra_username", ""))
        self.ra_user_entry = tk.Entry(creds, textvariable=self.ra_user_var, width=22)
        self.ra_user_entry.grid(row=0, column=1, sticky="w", padx=4)
        tk.Label(creds, text="Web API key:").grid(row=0, column=2, sticky="e", padx=(12, 0))
        self.ra_key_var = tk.StringVar(value=self.settings.get("ra_api_key", ""))
        self.ra_key_entry = tk.Entry(creds, textvariable=self.ra_key_var, width=36, show="•")
        self.ra_key_entry.grid(row=0, column=3, sticky="w", padx=4)
        tk.Label(creds, fg=T["text_faint"], justify="left",
                 text="Optional. Adds developer, genre, box art and your achievement progress. "
                      "The key is on your RetroAchievements settings page.").grid(
            row=1, column=0, columnspan=4, sticky="w", pady=(2, 0))
        for var in (self.ra_user_var, self.ra_key_var):
            var.trace_add("write", lambda *a: self.save_ra_credentials())

        row = tk.Frame(meta, padx=px(5), pady=px(4))
        row.pack(fill="x", pady=(4, 0))
        self.scan_btn = tk.Button(row, text="Check for updates", width=18, command=self.scan_all)
        self.scan_btn.pack(side="left")
        self.cancel_btn = tk.Button(row, text="Cancel", width=10, command=self.cancel_scan, state="disabled")
        self.cancel_btn.pack(side="left", padx=6)
        self.rescan_var = tk.BooleanVar(value=False)
        self.rescan_cb = theme.checkbox(row, "Re-check games already scanned", self.rescan_var)
        self.rescan_cb.pack(side="left", padx=6)
        self.badges_var = tk.BooleanVar(value=self.settings.get("achievement_badges", True))
        self.badges_cb = theme.checkbox(row, "Show achievement badges", self.badges_var,
                                        self.on_badges_changed)
        self.badges_cb.pack(side="left", padx=(px(18), 6))
        self.scan_progress = ttk.Progressbar(meta, mode="determinate")
        self.scan_progress.pack(fill="x", pady=(8, 0))
        self.scan_label = tk.Label(meta, anchor="w", fg=T["text_muted"])
        self.scan_label.pack(fill="x")
        self.update_scan_summary()

        # Launcher and Reminders share a row, half the width each
        bottom = tk.Frame(tab)
        bottom.pack(fill="x", pady=(10, 0))
        bottom.columnconfigure(0, weight=1, uniform="bottom")
        bottom.columnconfigure(1, weight=1, uniform="bottom")
        launcher = tk.LabelFrame(bottom, text="Launcher", padx=8, pady=6)
        launcher.grid(row=0, column=0, sticky="nsew", padx=(0, px(5)))
        self.minimize_var = tk.BooleanVar(value=self.settings.get("minimize_on_launch", False))
        self.minimize_cb = theme.checkbox(launcher, "Minimize while a game is running",
                                          self.minimize_var, self.on_minimize_changed)
        self.minimize_cb.grid(row=0, column=0, sticky="w", padx=px(5), pady=px(3))
        self.hide_tags_var = tk.BooleanVar(value=self.settings.get("hide_tags", False))
        self.hide_tags_cb = theme.checkbox(launcher, "Hide region and version tags",
                                           self.hide_tags_var, self.on_hide_tags_changed)
        self.hide_tags_cb.grid(row=1, column=0, sticky="w", padx=px(5), pady=px(3))

        self.list_icons_var = tk.BooleanVar(value=self.settings.get("show_list_icons", True))
        self.list_icons_cb = theme.checkbox(launcher, "Show system icons in game lists",
                                            self.list_icons_var, self.on_list_icons_changed)
        self.list_icons_cb.grid(row=2, column=0, sticky="w", padx=px(5), pady=px(3))

        self.system_names_var = tk.BooleanVar(value=self.settings.get("show_system_names", True))
        self.system_names_cb = theme.checkbox(launcher, "Show system name in game lists",
                                              self.system_names_var, self.on_system_names_changed)
        self.system_names_cb.grid(row=3, column=0, sticky="w", padx=px(5), pady=px(3))

        reminders = tk.LabelFrame(bottom, text="Reminders", padx=8, pady=6)
        reminders.grid(row=0, column=1, sticky="nsew", padx=(px(5), 0))
        day_row = tk.Frame(reminders, padx=px(5), pady=px(4))
        day_row.pack(fill="x")
        tk.Label(day_row, text="New day starts at:").pack(side="left", padx=(0, 6))
        self.reset_btn = tk.Button(day_row, width=20, command=self.pick_reset_hour,
                                   text=R.hour_label(R.RESET_HOUR) + "  ▾")
        self.reset_btn.pack(side="left")
        self.show_rem_var = tk.BooleanVar(value=self.settings.get("show_reminders", True))
        self.show_rem_cb = theme.checkbox(reminders, "Show reminders on the Home tab",
                                          self.show_rem_var, self.on_show_reminders_changed)
        self.show_rem_cb.pack(anchor="w", padx=px(5), pady=(px(8), 0))
        self.nav_index = 0          # controller position on this tab
        self.nav_shown = False      # the highlight appears on the first controller press
        self.nav_widget = None
        self.nav_ring = []          # the four edges of the outline around the highlighted control
        self.nav_ring_target = None

    def build_status_bar(self):
        if theme.is_classic():
            self.status = tk.Label(self.root, anchor="w", relief="sunken", padx=6)
        else:
            self.status = tk.Label(self.root, anchor="w", relief="flat", padx=10, pady=3,
                                   bg=T["surface"], fg=T["text_muted"], font=("Segoe UI", 9))
        self.status.pack(fill="x", side="bottom")

    def on_theme_changed(self):
        """Save the theme and rebuild the window so every widget picks up the new colors."""
        name = self.theme_var.get()
        if name == theme.CURRENT:
            return
        self.settings["theme"] = name
        save_settings(self.settings)
        if self.is_running():
            self.status.config(text="Theme saved. It applies when the game closes and the launcher reopens.")
            return
        self.scan_cancel.set()          # stop a metadata scan; it picks up where it left off next time
        self.restart_requested = True
        self.root.destroy()

    def on_hide_tags_changed(self):
        self.settings["hide_tags"] = self.hide_tags_var.get()
        save_settings(self.settings)
        self.refresh_open_lists()

    def on_minimize_changed(self):
        self.settings["minimize_on_launch"] = self.minimize_var.get()
        save_settings(self.settings)

    def current_tab(self):
        return TAB_NAMES[self.notebook.index("current")]

    def on_tab_changed(self):
        if self.current_tab() == "home":
            self.prune_recent()
            self.refresh_home()
        self.update_toggle_look()
        self.set_idle_status()

    def refresh_open_lists(self):
        """Redraw every game list after names, icons or settings change."""
        self.refresh_home()
        if self.open_system_id:
            self.open_system(self.open_system_id, keep_search=True)
        if self.open_series:
            self.open_series_list(self.open_series, keep_search=True)

    def on_show_reminders_changed(self):
        self.settings["show_reminders"] = self.show_rem_var.get()
        save_settings(self.settings)
        self.apply_reminders_visibility()

    def apply_reminders_visibility(self):
        """The reminder carousel on Home, hidden or shown (Settings › Reminders)."""
        extra = self.home_list.extra
        if self.settings.get("show_reminders", True):
            extra.pack(fill="x", after=self.home_list.header)
        else:
            if self.reminder_strip.focus is not None:
                self.reminder_strip.leave()
            extra.pack_forget()

    def on_system_names_changed(self):
        self.settings["show_system_names"] = self.system_names_var.get()
        save_settings(self.settings)
        self.refresh_open_lists()

    def on_list_icons_changed(self):
        self.settings["show_list_icons"] = self.list_icons_var.get()
        save_settings(self.settings)
        self.refresh_open_lists()

    def on_right_click_back(self, event):
        """Right-clicking anywhere outside the game list goes back, like B on a controller.

        A right-click on a game opens its menu instead (that handler stops this one)."""
        try:
            if event.widget.winfo_toplevel() is not self.root:
                return          # inside a dialog or a pop-up menu
        except (AttributeError, KeyError):
            return
        tab = self.current_tab()
        if tab == "systems" and self.open_system_id:
            self.show_system_cards()
        elif tab == "series" and self.open_series:
            self.show_series_cards()

    def on_mousewheel(self, event):
        if self.reminder_strip.handle_wheel(event):
            return
        for grid in (self.sys_grid, self.ser_grid):
            if grid.handle_wheel(event):
                return

    def refresh_all(self):
        self.refresh_settings_tree()
        if self.open_system_id and self.system_by_id(self.open_system_id):
            self.open_system(self.open_system_id, keep_search=True)
        else:
            self.show_system_cards()
        if self.open_series and self.series_by_name(self.open_series):
            self.open_series_list(self.open_series, keep_search=True)
        else:
            self.show_series_cards()
        self.prune_recent()                 # e.g. a removed system's games leave Home
        self.refresh_home()

    # ================================================================ lookups

    def system_by_id(self, system_id):
        return next((f for f in self.settings["folders"] if f["id"] == system_id), None)

    def series_by_name(self, name):
        return next((s for s in self.settings["series"] if s["name"] == name), None)

    def games_for(self, folder, fresh=False):
        if fresh or folder["id"] not in self.scan_cache:
            self.scan_cache[folder["id"]] = scan_games(folder)
        return self.scan_cache[folder["id"]]

    # ================================================================ Systems tab

    def show_system_cards(self):
        self.open_system_id = None
        specs = []
        for f in self.settings["folders"]:
            count = len(self.games_for(f))
            detail = EMULATORS[f["emulator_type"]]["label"]
            if f["core"]:
                detail += " · " + os.path.splitext(f["core"])[0].replace("_libretro", "")
            specs.append(dict(
                title=f["name"], subtitle=f"{count} game{'s' if count != 1 else ''}", detail=detail,
                accent=f.get("color") or ACCENTS[f["emulator_type"]], art=self.card_art(f),
                command=lambda i=f["id"]: self.open_system(i), movable=True,
                menu=[("Open", lambda i=f["id"]: self.open_system(i))]
                + self.move_items("folders", len(specs)) + [
                      ("Card color…", lambda k=len(specs): self.pick_card_color("folders", k)),
                      ("Card art", self.card_art_items("folders", len(specs))),
                      ("List icon…", lambda k=len(specs): self.pick_list_icon(k)),
                      ("Edit system…", lambda i=f["id"]: self.edit_system(i))]))
        specs.append(dict(title="+  Add system", subtitle="", detail="Register a ROM folder",
                          accent=ACCENTS["add"], command=self.add_system, muted=True))
        self.sys_grid.set_cards(specs)
        self.sys_list.pack_forget()
        self.sys_grid.pack(fill="both", expand=True, padx=4, pady=4)
        self.update_toggle_look()
        self.set_idle_status()

    def open_system(self, system_id, keep_search=False):
        folder = self.system_by_id(system_id)
        if folder is None:
            return
        self.open_system_id = system_id
        games = self.games_for(folder, fresh=True)
        self.sys_grid.pack_forget()
        self.sys_list.pack(fill="both", expand=True)
        entries = [(self.display_name(path, name), path, system_id) for name, path in games]
        self.sys_list.show(folder["name"], entries, keep_search)
        self.sys_list.listbox.focus_set()
        self.update_toggle_look()
        self.set_idle_status()

    def system_menu_items(self, index):
        entry = self.sys_list.entries[index]
        return [("Launch", lambda: self.launch(entry))] + self.disk_items(entry) + [
                ("Look up details", lambda: self.scan_entries([entry], force=True))] + self.ra_items(entry) + self.achievement_items(entry) + self.guide_items(entry) + [
                None,
                ("Add to Group…", lambda: self.add_to_series(entry))] + self.rename_items(entry)

    # ================================================================ names and sorting

    def display_name(self, path, default):
        custom = self.settings.get("custom_titles", {}).get(norm_path(path))
        if custom:
            return custom
        return strip_tags(default) if self.settings.get("hide_tags") else default

    def disk_items(self, entry):
        disks = disk_set(entry[1])
        if len(disks) < 2:
            return []
        def pick():
            items = [(os.path.splitext(os.path.basename(d))[0],
                      lambda d=d: self.launch((entry[0], d, entry[2]))) for d in disks]
            self.open_actions("Launch with disk", items)
        return [("Launch with disk…", pick)]

    def rename_items(self, entry):
        game = {"path": entry[1], "system_id": entry[2], "title": entry[0].rsplit("    [", 1)[0]}
        items = [None, ("Add reminder for this game…", lambda: self.add_reminder(game)),
                 ("Rename…", lambda: self.rename_game(entry))]
        if norm_path(entry[1]) in self.settings.get("custom_titles", {}):
            items.append(("Reset to original name", lambda: self.rename_game(entry, reset=True)))
        return items

    def rename_game(self, entry, reset=False):
        """Change the name shown for a game everywhere. The file itself isn't touched."""
        key = norm_path(entry[1])
        titles = self.settings.setdefault("custom_titles", {})
        if reset:
            titles.pop(key, None)
        else:
            current = titles.get(key)
            if current is None:
                current = entry[0]
                if entry in self.ser_list.entries or entry in self.home_list.entries:
                    current = current.rsplit("    [", 1)[0]   # drop the "[System]" tag
            new = ask_string("Rename", "Name to show for this game:",
                                         initialvalue=current, parent=self.root)
            new = (new or "").strip()
            if not new or new == current:
                return
            titles[key] = new
        save_settings(self.settings)
        self.refresh_open_lists()

    def remember_sort(self, key, sort_id):
        self.settings[key] = sort_id
        save_settings(self.settings)

    def sort_entries(self, entries, sort_id):
        """Order list entries by metadata. Games without the value go last, by name."""
        def rec(entry):
            return self.meta.get(norm_path(entry[1])) or {}

        def ra(entry):
            return rec(entry).get("ra") or {}

        name = lambda i: entries[i][0].lower()
        indexes = list(range(len(entries)))
        if sort_id == "custom":
            return [(i, "") for i in indexes]
        if sort_id == "name":
            return [(i, "") for i in sorted(indexes, key=name)]

        if sort_id in ("release_old", "release_new"):
            values = {i: release_key(ra(entries[i]).get("released") or rec(entries[i]).get("year", ""))
                      for i in indexes}
            # Names A–Z within the same date, dates in the chosen direction
            known = sorted((i for i in indexes if values[i]), key=name)
            known = sorted(known, key=lambda i: values[i], reverse=(sort_id == "release_new"))
            unknown = sorted((i for i in indexes if not values[i]), key=name)
            return ([(i, values[i][:4]) for i in known] + [(i, "date unknown") for i in unknown])

        if sort_id in ("progress", "achievements"):
            def value(i):
                r = ra(entries[i])
                total = r.get("num_achievements", 0)
                if not total:
                    return None
                return r.get("earned", 0) / total if sort_id == "progress" else total
            values = {i: value(i) for i in indexes}
            known = sorted((i for i in indexes if values[i] is not None),
                           key=lambda i: (-values[i], name(i)))
            unknown = sorted((i for i in indexes if values[i] is None), key=name)
            def label(i):
                r = ra(entries[i])
                if sort_id == "progress":
                    return f"{r.get('earned', 0)}/{r.get('num_achievements', 0)}"
                return f"{r.get('num_achievements', 0)} achievements"
            return [(i, label(i)) for i in known] + [(i, "") for i in unknown]

        if sort_id in ("ratio_low", "ratio_high"):
            values = {i: ra(entries[i]).get("retro_ratio") for i in indexes}
            # Games matched to RetroAchievements but without a ratio yet: fetched in the background
            missing = [str(rec(entries[i]).get("ra_id")) for i in indexes
                       if values[i] is None and rec(entries[i]).get("ra_id")
                       and ra(entries[i]).get("num_achievements")]
            self.queue_ratio_fetch(missing)
            known = sorted((i for i in indexes if values[i] is not None),
                           key=lambda i: (values[i] if sort_id == "ratio_low" else -values[i], name(i)))
            unknown = sorted((i for i in indexes if values[i] is None), key=name)
            pending = set(self.ratio_queue) | self.ratio_busy
            return ([(i, f"Ratio {values[i]:.2f}") for i in known] +
                    [(i, "ratio…" if str(rec(entries[i]).get("ra_id")) in pending else "") for i in unknown])

        # Text fields: developer, publisher, genre, system
        def text(i):
            e = entries[i]
            if sort_id == "system":
                folder = self.system_by_id(e[2])
                return folder["name"] if folder else ""
            if sort_id == "developer":
                return ra(e).get("developer", "")
            if sort_id == "publisher":
                return ra(e).get("publisher") or rec(e).get("publisher", "")
            return ra(e).get("genre", "")
        values = {i: text(i) for i in indexes}
        known = sorted((i for i in indexes if values[i]), key=lambda i: (values[i].lower(), name(i)))
        unknown = sorted((i for i in indexes if not values[i]), key=name)
        suffix = (lambda i: "") if sort_id == "system" else (lambda i: values[i])
        return [(i, suffix(i)) for i in known] + [(i, "") for i in unknown]

    # ----- card order

    def move_items(self, kind, index):
        """Menu entries that move a card one place, for controller users."""
        last = len(self.settings[kind]) - 1
        items = []
        if index > 0:
            items.append(("Move left", lambda: self.swap_cards(kind, index, index - 1)))
        if index < last:
            items.append(("Move right", lambda: self.swap_cards(kind, index, index + 1)))
        return items

    def pick_card_color(self, kind, index):
        """Pick a preset color for a System card (kind='folders') or Series card (kind='series')."""
        item = self.settings[kind][index]
        default = ACCENTS[item["emulator_type"]] if kind == "folders" else ACCENTS["series"]
        dlg = ColorPicker(self.root, f"Card color: {item['name']}", item.get("color", ""), default)
        if dlg.result is None:
            return
        item["color"] = dlg.result
        save_settings(self.settings)
        if kind == "folders":
            self.show_system_cards()
        else:
            self.show_series_cards()

    def swap_cards(self, kind, i, j):
        """Swap two System cards (kind='folders') or two Series cards (kind='series')."""
        items = self.settings[kind]
        if not (0 <= i < len(items) and 0 <= j < len(items)):
            return
        items[i], items[j] = items[j], items[i]
        save_settings(self.settings)
        grid = self.sys_grid if kind == "folders" else self.ser_grid
        grid.focus = j                      # the controller highlight follows the moved card
        if kind == "folders":
            self.refresh_settings_tree()
            self.show_system_cards()
        else:
            self.show_series_cards()

    # ================================================================ icons and card art

    def icon_for_entry(self, entry):
        """Small RetroAchievements system icon for a game list row, or None."""
        if not self.settings.get("show_list_icons", True):
            return None
        system_id = entry[2]
        if system_id not in self.icon_files:
            folder = self.system_by_id(system_id)
            self.icon_files[system_id] = icons.list_icon_file(folder) if folder else ""
        file = self.icon_files[system_id]
        if not file:
            return None
        if file in self.icon_photos:
            return self.icon_photos[file]
        path = icons.ra_icon_path(file)
        if not os.path.isfile(path):
            self.request_icon(file)
            return None
        size = list_icon_size()
        photo = load_photo(path, size, size, pixel_art=True)
        if photo is not None:
            self.icon_photos[file] = photo
        return photo

    def request_icon(self, file):
        """Download a system icon in the background; lists update when it arrives."""
        if file in self.icon_requested:
            return
        self.icon_requested.add(file)
        self.icon_queue.put(file)
        if self.icon_thread is None or not self.icon_thread.is_alive():
            self.icon_thread = threading.Thread(target=self.icon_worker, daemon=True)
            self.icon_thread.start()
            self.root.after(400, self.poll_icons)

    def icon_worker(self):
        while True:
            try:
                file = self.icon_queue.get(timeout=0.5)
            except queue.Empty:
                return
            icons.fetch_ra_icon(file)

    def poll_icons(self):
        if self.icon_thread is not None and self.icon_thread.is_alive():
            self.root.after(400, self.poll_icons)
            return
        if not self.icon_queue.empty():          # a request slipped in as the worker finished
            self.icon_thread = threading.Thread(target=self.icon_worker, daemon=True)
            self.icon_thread.start()
            self.root.after(400, self.poll_icons)
        for view in (self.home_list, self.sys_list, self.ser_list):
            if view.winfo_ismapped():
                view.refresh_icons()

    def pick_list_icon(self, index):
        folder = self.settings["folders"][index]
        auto = icons.match_ra(folder)
        options = [("", f"Automatic ({icons.RA_NAMES[auto]})" if auto else "Automatic (no match found)"),
                   ("none", "No icon")]
        options += sorted(((f, n) for f, n in icons.RA_NAMES.items()), key=lambda o: o[1].lower())
        dlg = ChoiceDialog(self.root, "List icon", f"Icon shown beside {folder['name']} games:",
                           options, folder.get("list_icon", ""))
        if dlg.result is None:
            return
        folder["list_icon"] = dlg.result
        self.icon_files.pop(folder["id"], None)
        save_settings(self.settings)
        self.refresh_open_lists()

    @staticmethod
    def card_art(item):
        path = item.get("card_art", "")
        return path if path and os.path.isfile(path) else None

    def card_art_items(self, kind, index):
        """The 'Card art' submenu for a System card (kind='folders') or Series card."""
        item = self.settings[kind][index]
        entries = []
        if kind == "folders":
            suggestion = icons.suggested_pack_icon(item)
            if suggestion:
                entries.append((f"Use {icons.pack_label(suggestion)} icon",
                                lambda: self.set_pack_art(kind, index, suggestion)))
        entries += [("Choose from icon pack…", lambda: self.choose_pack_art(kind, index)),
                    ("Choose image file…", lambda: self.choose_art_file(kind, index))]
        if item.get("card_art"):
            entries += [None, ("Remove card art", lambda: self.set_card_art(kind, index, ""))]
        return entries

    def set_card_art(self, kind, index, path):
        self.settings[kind][index]["card_art"] = path
        save_settings(self.settings)
        if kind == "folders":
            self.show_system_cards()
        else:
            self.show_series_cards()

    def set_pack_art(self, kind, index, name):
        self.status.config(text=f"Downloading the {icons.pack_label(name)} icon…")
        self.root.config(cursor="watch")
        self.root.update_idletasks()
        try:
            path = icons.fetch_pack_icon(name)
        finally:
            self.root.config(cursor="")
        if not path:
            self.status.config(text="Couldn't download that icon. Check your internet connection.")
            return
        self.set_card_art(kind, index, path)
        self.status.config(text=f"Card art set to the {icons.pack_label(name)} icon.")

    def choose_pack_art(self, kind, index):
        item = self.settings[kind][index]
        initial = icons.suggested_pack_icon(item) if kind == "folders" else None
        options = sorted(((n, f"{icons.pack_label(n)}   ({n})") for n in icons.PACK_ICONS),
                         key=lambda o: o[1].lower())
        dlg = ChoiceDialog(self.root, "Card art", f"Console icon for {item['name']}:\n"
                           "(icons by KyleBing, retro-game-console-icons)", options, initial)
        if dlg.result:
            self.set_pack_art(kind, index, dlg.result)

    def choose_art_file(self, kind, index):
        path = filedialog.askopenfilename(
            parent=self.root, title="Choose card art",
            filetypes=[("Images", "*.png *.gif *.jpg *.jpeg *.webp"), ("All files", "*.*")])
        if not path:
            return
        if load_photo(path, 64, 64) is None:
            show_warning("Card art", "That image couldn't be loaded. PNG and GIF always work; "
                                               "JPG and WebP need Pillow (pip install pillow).")
            return
        self.set_card_art(kind, index, os.path.normpath(path))

    # ================================================================ achievements after playing

    def record_for(self, path):
        """Metadata for a game; for a multi-disk set launched from another disk, the set's record."""
        record = self.meta.get(norm_path(path))
        if record is None:
            for disk in disk_set(path):
                record = self.meta.get(norm_path(disk))
                if record is not None:
                    return norm_path(disk), record
            return norm_path(path), None
        return norm_path(path), record

    def award_for_entry(self, entry):
        """RetroAchievements award for a game: mastered, completed, beaten-hardcore/softcore or ''."""
        _key, record = self.record_for(entry[1])
        return ((record or {}).get("ra") or {}).get("award", "")

    def ra_items(self, entry):
        """RetroAchievements entries for a game's menu: open its page, or link/re-link it."""
        _key, record = self.record_for(entry[1])
        if record and record.get("ra_id"):
            return [("Open on RetroAchievements", lambda: webbrowser.open(ra_game_url(record["ra_id"]))),
                    ("Change RetroAchievements link…", lambda: self.link_to_ra(entry))]
        items = [("Link to a RetroAchievements page…", lambda: self.link_to_ra(entry))]
        if record and record.get("ra_candidates"):
            items.insert(0, ("Choose from possible matches…", lambda: self.choose_candidate(entry)))
        return items

    def choose_candidate(self, entry):
        """Several RetroAchievements sets fit a game about equally: let you pick one."""
        _key, record = self.record_for(entry[1])
        candidates = (record or {}).get("ra_candidates") or []
        if not candidates:
            return
        title = entry[0].rsplit("    [", 1)[0]
        options = [(c["id"], f"{c['title']}   ·   {int(round(c['score'] * 100))}% match")
                   for c in candidates]
        options.append(("__paste__", "None of these — paste a page address…"))
        choice = ChoiceDialog(self.root, "Possible matches",
                              f"Which RetroAchievements set is {title}?", options).result
        if choice == "__paste__":
            self.link_to_ra(entry)
        elif choice:
            self.link_to_ra(entry, game_id=choice)

    # ---------------------------------------------------------------- achievement list

    def achievement_model(self, record):
        return ACH.build(ACH.load_cache(record.get("ra_id")), self.settings.get("achievement_marks", {}))

    def request_achievements(self, record):
        """The Achievements tab is open on a game: refresh its list if it's old, and fetch any
        badges it's missing (all of them, the first time). Runs in the background."""
        ra_id = str(record.get("ra_id") or "")
        if not ra_id or ra_id in self.ach_inflight:
            return
        # One try per game every few minutes, so a failed request isn't retried on every redraw
        if time.time() - self.ach_tried.get(ra_id, 0) < 300:
            return
        user, key = self.ra_credentials()
        fetch = bool(user and key) and ACH.is_stale(ra_id)
        badges = self.settings.get("achievement_badges", True)
        if not fetch and not (badges and ACH.missing_badges(ACH.load_cache(ra_id))):
            return
        self.ach_inflight.add(ra_id)
        self.ach_tried[ra_id] = time.time()

        def worker():
            ra = None
            if fetch:
                try:
                    ra = ra_progress(ra_id, user, key)
                except Exception:
                    ra = None
            saved = 0
            if badges:
                try:
                    saved = ACH.download_badges(ACH.load_cache(ra_id), http_get)
                except Exception:
                    pass
            self.ach_results.put((ra_id, ra, saved))

        threading.Thread(target=worker, daemon=True).start()
        self.root.after(300, self.poll_achievements)

    def poll_achievements(self):
        try:
            ra_id, ra, saved = self.ach_results.get_nowait()
        except queue.Empty:
            if self.ach_inflight:
                self.root.after(300, self.poll_achievements)
            return
        if ra:
            for record in self.meta.values():
                if str(record.get("ra_id")) == ra_id:
                    record["ra"] = ra
            save_metadata(self.meta)
        for view in (self.home_list, self.sys_list, self.ser_list):
            if saved:
                view.panel.badge_photos.clear()
            view.panel.rendered_for = None
            if view.winfo_ismapped():
                view.update_details()
        self.refresh_target()
        # Cleared last, so redrawing the panel doesn't start the same request again
        self.ach_inflight.discard(ra_id)
        if self.ach_inflight:
            self.root.after(300, self.poll_achievements)

    def mark_achievement(self, ach_id, action, record=None, achievement=None):
        """Your own tags: missable / not missable / progression, and the target."""
        if action in ("target", "clear_target"):
            self.set_target(record, achievement if action == "target" else None)
            return
        marks = self.settings.setdefault("achievement_marks", {})
        mark = marks.setdefault(str(ach_id), {})
        if action == "missable":
            mark["missable"] = True
        elif action == "unmissable":
            mark["missable"] = False
        elif action == "clear_missable":
            mark.pop("missable", None)
        elif action == "progression":
            mark["progression"] = True
        elif action == "clear_progression":
            mark.pop("progression", None)
        if not mark:
            marks.pop(str(ach_id), None)
        save_settings(self.settings)
        for view in (self.home_list, self.sys_list, self.ser_list):
            if view.winfo_ismapped():
                view.update_details()

    # ---------------------------------------------------------------- target achievement

    def is_target(self, ach_id):
        return str((self.settings.get("target") or {}).get("id", "")) == str(ach_id)

    def set_target(self, record, a):
        """Pin one achievement beside the Hardcore toggle (None clears it)."""
        if a is None:
            self.settings.pop("target", None)
            self.status.config(text="Target cleared.")
        else:
            ra = (record or {}).get("ra") or {}
            self.settings["target"] = {
                "game_id": str((record or {}).get("ra_id", "")), "id": str(a["id"]),
                "title": a["title"], "description": a["description"], "badge": a["badge"],
                "points": a["points"], "game": ra.get("title") or (record or {}).get("title", "")}
            self.status.config(text=f"🎯 Target: {a['title']} — {a['description']}")
        self.target_earned = None
        save_settings(self.settings)
        self.refresh_target()
        for view in (self.home_list, self.sys_list, self.ser_list):
            view.panel.rendered_for = None
            if view.winfo_ismapped():
                view.update_details()

    def refresh_target(self):
        """Redraw the target block from the game's cached achievement list."""
        target = self.settings.get("target")
        if not target:
            self.target_block.pack_forget()
            return
        earned = ""
        for a in (ACH.load_cache(target.get("game_id")) or {}).get("achievements", []):
            if a["id"] == target.get("id"):
                earned = "hardcore" if a["earned_hardcore"] else "casual" if a["earned"] else ""
                break
        if self.target_earned == "" and earned:
            self.status.config(text=f"🎯 Target unlocked: {target.get('title', '')}!")
        self.target_earned = earned
        height = self.toggle_btn.winfo_reqheight()
        self.target_block.fit_height(height if height >= px(30) else px(46))
        self.target_block.show(target, earned)
        self.target_block.pack(side="right", padx=(0, px(12)), before=self.toggle_note)

    def go_to_target(self):
        """Clicking the target: Home tab, its game selected, achievements showing."""
        target = self.settings.get("target") or {}
        game_id = str(target.get("game_id", ""))
        if not game_id:
            return
        keys = {k for k, r in self.meta.items() if str(r.get("ra_id")) == game_id}
        if not keys:
            self.status.config(text=f"🎯 {target.get('title', '')}: that game isn't in your library any more.")
            return
        self.notebook.select(TAB_NAMES.index("home"))
        view = self.home_list

        def find():
            return next((i for i in view.visible if norm_path(view.entries[i][1]) in keys), None)

        index = find()
        if index is None:
            # Not recently played: search the whole library for it instead
            entry = next((e for e in self.library_entries() if norm_path(e[1]) in keys), None)
            if entry is None:
                self.status.config(text=f"🎯 {target.get('title', '')}: that game's file wasn't found.")
                return
            view.search_var.set(entry[0].split("    [")[0])
            index = find()
            if index is None:
                view.search_changed()             # make sure the search has run
                index = find()
        if index is None:
            return
        view.select_index(index)
        view.panel.set_mode("achievements")
        self.status.config(text=f"🎯  {target.get('title', '')} — {target.get('description', '')}")

    def target_menu(self, event):
        target = self.settings.get("target") or {}
        items = [("Go to this game", self.go_to_target),
                 ("Clear target", lambda: self.set_target(None, None))]
        if target.get("id"):
            items.append(("Open on RetroAchievements", lambda: webbrowser.open(
                f"https://retroachievements.org/achievement/{target['id']}")))
        popup_menu(self.root, items, event.x_root, event.y_root)

    def on_badges_changed(self):
        self.settings["achievement_badges"] = self.badges_var.get()
        save_settings(self.settings)
        for view in (self.home_list, self.sys_list, self.ser_list):
            view.panel.badge_photos.clear()
            view.panel.rendered_for = None

    def view_for_entry(self, entry):
        for view in (self.home_list, self.sys_list, self.ser_list):
            if view.winfo_ismapped() and entry in view.entries:
                return view
        return None

    def achievement_items(self, entry):
        """Menu entries (also the controller's X menu) for the achievement list."""
        _key, record = self.record_for(entry[1])
        if not record or not record.get("ra_id") or not (record.get("ra") or {}).get("num_achievements"):
            return []
        view = self.view_for_entry(entry)
        items = []
        if view is not None:
            showing = view.panel.mode == "achievements"
            items.append(("Show description" if showing else "View achievements",
                          lambda: (view.select_index(view.entries.index(entry)),
                                   view.panel.toggle_mode())))
        return items

    def mark_dialog(self, record):
        """Controller-friendly marking: pick an achievement, then what to mark it as."""
        model = self.achievement_model(record)
        if not model:
            return
        g = model["groups"]
        everything = g["missable"] + g["story"] + g["remaining"] + g["earned"]
        tags = {"ra": "⚠ ", "user": "⚠ (yours) ", "ra_off": "", "": ""}
        options = [(a["id"], f"{tags[a['missable']]}{a['title']}{'  ✓' if a['is_earned'] else ''}")
                   for a in everything]
        dlg = ChoiceDialog(self.root, "Mark an achievement", "Which achievement?", options)
        if dlg.result is None:
            return
        a = next(x for x in everything if x["id"] == dlg.result)
        actions = []
        if a["missable"] == "":
            actions.append(("missable", "⚠ Mark as missable"))
        elif a["missable"] == "user":
            actions.append(("clear_missable", "Remove my missable mark"))
        elif a["missable"] == "ra":
            actions.append(("unmissable", "Not missable (hide RetroAchievements' tag)"))
        else:
            actions.append(("clear_missable", "Restore RetroAchievements' missable tag"))
        if a["story"] == "":
            actions.append(("progression", "◆ Mark as progression"))
        elif a["story"] == "user":
            actions.append(("clear_progression", "Remove my progression mark"))
        actions.append(("clear_target", "Clear target") if self.is_target(a["id"])
                       else ("target", "🎯 Mark as target"))
        dlg = ChoiceDialog(self.root, a["title"], a["description"], actions)
        if dlg.result is not None:
            self.mark_achievement(a["id"], dlg.result, record, a)

    # ---------------------------------------------------------------- guide pages (FAQs, maps…)

    def guide_url(self, entry):
        return self.settings.get("guides", {}).get(norm_path(entry[1]), "")

    def guide_items(self, entry):
        """Menu entries for a web page that opens alongside the game."""
        if self.guide_url(entry):
            return [("Open guide page", lambda: webbrowser.open(self.guide_url(entry))),
                    ("Change guide page…", lambda: self.set_guide(entry)),
                    ("Remove guide page", lambda: self.set_guide(entry, remove=True))]
        return [("Add a guide page…", lambda: self.set_guide(entry))]

    def set_guide(self, entry, remove=False):
        """A web page (FAQ, map, walkthrough) that opens in your browser whenever the game starts."""
        guides = self.settings.setdefault("guides", {})
        key = norm_path(entry[1])
        title = entry[0].rsplit("    [", 1)[0]
        if remove:
            guides.pop(key, None)
            save_settings(self.settings)
            self.status.config(text=f"Removed the guide page for {title}.")
            return
        suggestion = guides.get(key, "")
        if not suggestion:
            try:
                clip = self.root.clipboard_get().strip()
                if re.match(r"https?://\S+$", clip):
                    suggestion = clip              # paste it for them
            except Exception:
                pass
        text = ask_string("Guide page",
                          f"Paste the address of a page to open with {title}, such as a GameFAQs "
                          "guide or a map. It opens in your browser each time the game starts.",
                          suggestion, self.root)
        if text is None or not text.strip():
            return
        url = text.strip()
        if not re.match(r"[a-z][a-z0-9+.-]*://", url, re.I):
            url = "https://" + url
        if not re.match(r"https?://[^\s/]+\.[^\s]+", url, re.I) and not url.lower().startswith("file://"):
            show_warning("Guide page", "That doesn't look like a web address.", self.root)
            return
        guides[key] = url
        save_settings(self.settings)
        self.status.config(text=f"{title} will open {url} when it starts.")

    def link_to_ra(self, entry, game_id=None):
        """Match a game by hand: paste any of its RetroAchievements page addresses
        (or pass game_id, when it was picked from the possible matches)."""
        user, api_key = self.ra_credentials()
        if not (user and api_key):
            show_warning("RetroAchievements", "Add your RetroAchievements username and Web API key "
                                              "on the Settings tab first.", self.root)
            return
        if game_id:
            self.start_link(entry, str(game_id), user, api_key)
            return
        suggestion = ""
        try:
            clip = self.root.clipboard_get()
            if "retroachievements.org/game/" in clip:
                suggestion = clip.strip()          # paste it for them
        except Exception:
            pass
        title = entry[0].rsplit("    [", 1)[0]
        text = ask_string("Link to RetroAchievements",
                          f"Paste the address of {title}'s page on RetroAchievements.\n"
                          "Any page of the game works, e.g. retroachievements.org/game/9419/hashes",
                          suggestion, self.root)
        if not text:
            return
        m = re.search(r"retroachievements\.org/game/(\d+)", text) or re.fullmatch(r"\s*(\d+)\s*", text)
        if not m:
            show_error("Link to RetroAchievements", "That doesn't look like a RetroAchievements game "
                                                    "address. It should contain /game/ and a number.",
                       self.root)
            return
        self.start_link(entry, m.group(1), user, api_key)

    def start_link(self, entry, game_id, user, api_key):
        title = entry[0].rsplit("    [", 1)[0]
        meta_key, old = self.record_for(entry[1])
        self.status.config(text=f"Linking {title} to RetroAchievements game {game_id}…")

        def worker():
            try:
                ra = ra_progress(game_id, user, api_key)
                image = download_image(ra["boxart_url"]) if ra and ra.get("boxart_url") else ""
            except Exception:
                ra, image = None, ""
            found = {}
            if ra and not (old or {}).get("description"):
                try:
                    found = description_from_ra_hashes(game_id, api_key, skip=[(old or {}).get("md5", "")])
                except Exception:
                    pass
            self.link_results.put((meta_key, entry[1], title, game_id, old, ra, image, found))

        threading.Thread(target=worker, daemon=True).start()
        self.root.after(300, self.poll_link)

    def poll_link(self):
        try:
            meta_key, path, title, game_id, old, ra, image, found = self.link_results.get_nowait()
        except queue.Empty:
            self.root.after(300, self.poll_link)
            return
        if not ra:
            self.status.config(text="")
            show_error("Link to RetroAchievements",
                       f"Couldn't find RetroAchievements game {game_id}. Check the address and your "
                       "internet connection.", self.root)
            return
        old = old or {}
        # Keep what the other source (Hasheous) already found — description, year, publisher —
        # and add the RetroAchievements game on top of it
        record = {k: v for k, v in old.items() if old.get("status") == "matched"}
        record.update({"signature": old.get("signature") or file_signature(path), "md5": old.get("md5", ""),
                       "status": "matched", "match": "manual", "ra_id": str(game_id),
                       "title": ra.get("title", "") or old.get("title", ""),
                       "platform": old.get("platform") or ra.get("console", ""),
                       "ra": ra, "image": image or old.get("image", "")})
        record["source"] = "Hasheous + RetroAchievements" if old.get("description") else "RetroAchievements"
        for stale in ("ra_match", "name_search_done", "desc_search_done", "ra_candidates", "ra_confidence",
                      "ra_special", "match_score"):
            record.pop(stale, None)
        record["ra_method"] = "manual"
        if found:
            add_description(record, found)
        self.meta[meta_key] = record
        save_metadata(self.meta)
        self.status.config(text=f"Linked {title} to “{ra.get('title', '')}” on RetroAchievements.")
        self.refresh_lists()

    def refresh_achievements(self, entry):
        """After a game closes, fetch its latest achievement progress from RetroAchievements."""
        user, api_key = self.ra_credentials()
        if not (user and api_key):
            return
        key, record = self.record_for(entry[1])
        if record is None or record.get("status") == "error":
            # Never looked up: do a full lookup for this one game (hash + details + progress)
            if not (self.scan_thread is not None and self.scan_thread.is_alive()):
                self.scan_entries([entry], force=True)
            return
        if not record.get("ra_id"):
            return
        title = entry[0].rsplit("    [", 1)[0]
        self.status.config(text=f"Updating achievements for {title}…")
        before = (record.get("ra") or {}).get("earned", 0)

        def worker():
            time.sleep(2)            # give RetroAchievements a moment to record the last unlocks
            try:
                ra = ra_progress(record["ra_id"], user, api_key)
            except Exception:
                ra = None
            self.ra_updates.put((key, title, before, ra))

        threading.Thread(target=worker, daemon=True).start()
        self.root.after(500, self.poll_ra_updates)

    def poll_ra_updates(self):
        try:
            key, title, before, ra = self.ra_updates.get_nowait()
        except queue.Empty:
            self.root.after(500, self.poll_ra_updates)
            return
        if self.is_running():
            return                    # another game started meanwhile; leave its status alone
        if ra is None:
            self.status.config(text=f"Couldn't update achievements for {title} (no connection?).")
            return
        record = self.meta.get(key)
        if record is not None:
            record["ra"] = ra
            save_metadata(self.meta)
        gained = ra.get("earned", 0) - before
        total = ra.get("num_achievements", 0)
        note = f"  ·  {gained} new this session!" if gained > 0 else ""
        self.status.config(text=f"🏆  {title}: {ra.get('earned', 0)} / {total} achievements{note}")
        self.refresh_lists()

    def refresh_lists(self):
        """Re-sort and redraw the game lists after a game's details change, keeping the selection."""
        self.refresh_target()
        for view in (self.home_list, self.sys_list, self.ser_list):
            if view.entries:
                view.refresh()

    # ================================================================ reminders (Home carousel)

    def refresh_reminders(self):
        reminders, changed = R.cleanup(self.settings.get("reminders", []))
        if changed:
            self.settings["reminders"] = reminders
            save_settings(self.settings)
        now = datetime.now()
        items = []
        for r in R.todays(reminders, now):
            state = "done" if R.is_done(r, R.today(now)) else "due" if R.is_due(r, now) else "todo"
            items.append((r, R.describe(r, now), state))
        strip = self.reminder_strip
        focused = strip.focused()
        strip.set_items(items)
        if focused is not None:          # keep the controller on the same reminder after re-sorting
            ids = [r["id"] for r, _, _ in items]
            if focused["id"] in ids:
                strip.focus = ids.index(focused["id"])
                strip.draw()
                strip.ensure_visible(strip.focus)
        if items:
            strip.pack(fill="x", pady=(px(8), 0))
        else:
            strip.leave() if strip.focus is not None else None
            strip.pack_forget()

    def pick_reset_hour(self):
        options = [(h, R.hour_label(h)) for h in range(24)]
        dlg = ChoiceDialog(self.root, "New day starts at", "When do daily reminders reset?",
                           options, initial=R.RESET_HOUR)
        if dlg.result is None:
            return
        R.RESET_HOUR = dlg.result
        self.settings["reminder_reset_hour"] = dlg.result
        save_settings(self.settings)
        self.reset_btn.config(text=R.hour_label(dlg.result) + "  ▾")
        self.refresh_reminders()
        self.status.config(text=f"Reminders now reset at {R.hour_label(dlg.result)}.")

    def toggle_reminder(self, reminder):
        today = R.today().isoformat()
        if reminder.get("done_on") == today:
            reminder["done_on"] = ""
            self.status.config(text=f"“{reminder['text']}” marked not done.")
        else:
            reminder["done_on"] = today
            again = " See you tomorrow." if reminder.get("repeat") == "daily" else ""
            self.status.config(text=f"✓  “{reminder['text']}” done.{again}  (Click it again to undo.)")
        save_settings(self.settings)
        self.refresh_reminders()

    def reminder_items(self, reminder):
        done = R.is_done(reminder)
        items = [("Mark not done" if done else "Mark done", lambda: self.toggle_reminder(reminder))]
        game = reminder.get("game")
        if game:
            entry = (game.get("title", ""), game.get("path", ""), game.get("system_id"))
            items += [("Launch " + game.get("title", "game"), lambda: self.launch(entry)),
                      ("Show game in its system", lambda: self.show_game(entry))]
        items += [None, ("Edit…", lambda: self.edit_reminder(reminder)),
                  ("Delete", lambda: self.delete_reminder(reminder)), None,
                  ("New reminder…", self.add_reminder)]
        return items

    def reminder_popup(self, reminder, x, y):
        popup_menu(self.root, self.reminder_items(reminder), x, y)

    def add_reminder(self, game=None):
        dlg = ReminderDialog(self.root, game=game)
        if not dlg.result:
            return
        r = dict(R.new_reminder(dlg.result["text"]), **dlg.result)
        self.settings.setdefault("reminders", []).append(r)
        save_settings(self.settings)
        self.refresh_reminders()
        when = "today" if R.shows_today(r) else f"on {R.WEEKDAYS[r['weekday']]}s"
        self.status.config(text=f"Reminder added: “{r['text']}” (shows {when}).")

    def edit_reminder(self, reminder):
        dlg = ReminderDialog(self.root, reminder=reminder)
        if dlg.result:
            reminder.update(dlg.result)
            save_settings(self.settings)
            self.refresh_reminders()

    def delete_reminder(self, reminder):
        if ask_yes_no("Delete reminder", f"Delete the reminder “{reminder['text']}”?",
                      yes="Delete", no="Cancel", default_yes=False):
            self.settings["reminders"] = [r for r in self.settings.get("reminders", [])
                                          if r["id"] != reminder["id"]]
            save_settings(self.settings)
            self.refresh_reminders()

    def show_game(self, entry):
        """Open the game's system on the Systems tab with the game selected."""
        if self.system_by_id(entry[2]) is None:
            show_error("Reminder", "That game's system has been removed.", self.root)
            return
        self.notebook.select(TAB_NAMES.index("systems"))
        self.open_system(entry[2])
        for i, e in enumerate(self.sys_list.entries):
            if norm_path(e[1]) == norm_path(entry[1]):
                self.sys_list.select_index(i)
                break

    def home_pad(self, action):
        """Controller on Home: up from the top of the list moves into the reminder carousel."""
        strip = self.reminder_strip
        if self.home_list.panel.pad_focus is not None:
            self.home_list.handle_pad(action, self.open_actions)     # controller is in the details
            return
        if strip.focus is not None:
            if action in ("left", "right"):
                strip.move(-1 if action == "left" else 1)
            elif action in ("down", "back"):
                strip.leave()
            elif action == "select" and strip.focused():
                self.toggle_reminder(strip.focused())
            elif action == "actions" and strip.focused():
                r = strip.focused()
                self.open_actions(r["text"], self.reminder_items(r))
            return
        if action == "up" and strip.winfo_ismapped() and self.home_list.at_top():
            if strip.enter():
                self.status.config(text="Reminders  |  left/right: choose  ·  A: done / undo  ·  X: more  ·  ↓ back to games")
                return
        if action == "actions" and self.home_list.selected_index() is None:
            self.open_actions("Home", [("New reminder…", self.add_reminder)])
            return
        self.home_list.handle_pad(action, self.open_actions)

    # ================================================================ Home (recently played)

    def prune_recent(self):
        """Drop games not launched for RECENT_DAYS, and games whose system was removed."""
        cutoff = time.time() - RECENT_DAYS * 86400
        recent = self.settings.get("recent", [])
        kept = [r for r in recent
                if r.get("last_played", 0) >= cutoff and self.system_by_id(r.get("system_id"))]
        if len(kept) != len(recent):
            self.settings["recent"] = kept
            save_settings(self.settings)
            return True
        return False

    def raw_name(self, path, system_id, fallback):
        """The game's scanned name (before custom names or tag hiding), for storing."""
        for name, game_path in self.scan_cache.get(system_id, []):
            if norm_path(game_path) == norm_path(path):
                return name
        return fallback

    def record_recent(self, entry):
        name, path, system_id = entry
        base = name.rsplit("    [", 1)[0]
        title = self.raw_name(path, system_id, base)
        recent = [r for r in self.settings.get("recent", []) if norm_path(r["path"]) != norm_path(path)]
        recent.insert(0, {"path": path, "system_id": system_id, "title": title,
                          "last_played": time.time()})
        self.settings["recent"] = recent[:200]
        save_settings(self.settings)

    def recent_entries(self):
        entries, times = [], []
        for r in self.settings.get("recent", []):
            folder = self.system_by_id(r["system_id"])
            if folder is None:
                continue
            title = self.display_name(r["path"], r["title"])
            entries.append((f"{title}    [{folder['name']}]", r["path"], r["system_id"]))
            times.append(r["last_played"])
        return entries, times

    def refresh_home(self):
        if self.home_searching:
            self.home_list.show("Searching…", self.library_entries(), keep_search=True)
            return
        entries, self.home_times = self.recent_entries()
        self.home_list.show("Recently played", entries, keep_search=True)

    def library_entries(self):
        """Every game in every system, tagged with its system, for Home's search."""
        entries = []
        for folder in self.settings["folders"]:
            for name, path in self.games_for(folder):
                entries.append((f"{self.display_name(path, name)}    [{folder['name']}]", path, folder["id"]))
        return entries

    def home_search(self, term):
        """Switch Home between Recently played and a search of the whole library."""
        searching = bool(term)
        if searching != self.home_searching:
            self.home_searching = searching
            if searching:
                self.status.config(text="Searching all systems…")
                self.root.update_idletasks()
                self.home_list.title.config(text="Searching…")
                self.home_list.entries = self.library_entries()
            else:
                self.home_list.title.config(text="Recently played")
                self.home_list.entries, self.home_times = self.recent_entries()

    def sort_recent(self, entries, _sort_id):
        """Recently played: newest first, labelled with how long ago each game was played.
        Searching: best matches first (name starts with the text, then a word does), then A–Z."""
        if _sort_id != "recent":
            return self.sort_entries(entries, _sort_id)
        if not self.home_searching:
            return [(i, played_label(self.home_times[i])) for i in range(len(entries))]
        term = self.home_list.search_var.get().strip().lower()

        def rank(i):
            name = entries[i][0].lower()
            if name.startswith(term):
                return (0, name)
            if any(word.startswith(term) for word in name.replace("-", " ").split()):
                return (1, name)
            return (2, name)
        return [(i, "") for i in sorted(range(len(entries)), key=rank)]

    def home_menu_items(self, index):
        entry = self.home_list.entries[index]
        return [("Launch", lambda: self.launch(entry))] + self.disk_items(entry) + [
                ("Look up details", lambda: self.scan_entries([entry], force=True))] + self.ra_items(entry) + self.achievement_items(entry) + self.guide_items(entry) + [
                None,
                ("Add to Group…", lambda: self.add_to_series(entry))] + (
                [] if self.home_searching else
                [("Remove from Recently played", lambda: self.forget_recent(entry))]) + self.rename_items(entry)

    def forget_recent(self, entry):
        self.settings["recent"] = [r for r in self.settings.get("recent", [])
                                   if norm_path(r["path"]) != norm_path(entry[1])]
        save_settings(self.settings)
        self.refresh_home()

    # ================================================================ Series tab

    def show_series_cards(self):
        self.open_series = None
        specs = []
        for s in self.settings["series"]:
            if s.get("smart"):
                # A smart group's games come from its rules, counted fresh each time
                matches = self.series_entries(s)
                count = len(matches)
                detail = "⚡ " + self.rules_summary(s["smart"])
            else:
                count = len(s["games"])
                systems = {g["system_id"] for g in s["games"]}
                names = sorted({self.system_by_id(i)["name"] for i in systems if self.system_by_id(i)})
                detail = ", ".join(names) if len(names) <= 2 else f"{len(names)} systems"
            smart_items = ([("Edit rules…", lambda g=s: self.new_smart_group(g))] if s.get("smart") else [])
            specs.append(dict(
                title=s["name"], subtitle=f"{count} game{'s' if count != 1 else ''}",
                detail=detail or "Empty", accent=s.get("color") or ACCENTS["series"],
                art=self.card_art(s),
                command=lambda n=s["name"]: self.open_series_list(n), movable=True,
                menu=[("Open", lambda n=s["name"]: self.open_series_list(n))] + smart_items
                + self.move_items("series", len(specs)) + [
                      ("Card color…", lambda k=len(specs): self.pick_card_color("series", k)),
                      ("Card art", self.card_art_items("series", len(specs))),
                      ("Rename…", lambda n=s["name"]: self.rename_series(n)),
                      ("Delete group", lambda n=s["name"]: self.delete_series(n))]))
        specs.append(dict(title="+  New group", subtitle="",
                          detail="Or right-click a game › Add to Group",
                          accent=ACCENTS["add"], command=self.new_series, muted=True))
        self.ser_grid.set_cards(specs)
        self.ser_list.pack_forget()
        self.ser_grid.pack(fill="both", expand=True, padx=4, pady=4)
        self.set_idle_status()

    def series_entries(self, series):
        if series.get("smart"):
            smart = series["smart"]
            rules = upgrade_rules(smart.get("rules", []))
            systems = set(smart.get("systems", []))
            match_any = smart.get("match") == "any"
            return [e for e in self.library_entries()
                    if (not systems or e[2] in systems) and self.smart_match(e, rules, match_any)]
        entries = []
        for g in series["games"]:
            folder = self.system_by_id(g["system_id"])
            system = folder["name"] if folder else "missing system"
            title = self.display_name(g["path"], g["title"])
            entries.append((f"{title}    [{system}]", g["path"], g["system_id"]))
        return entries

    # ----- smart groups: rules instead of a game list

    def smart_match(self, entry, rules, match_any=False):
        if not rules:
            return True                      # a systems-only smart group: every game there
        record = self.meta.get(norm_path(entry[1])) or {}
        ra = record.get("ra") or {}
        total, earned, award = ra.get("num_achievements", 0), ra.get("earned", 0), ra.get("award", "")
        has_set = bool(record.get("ra_id") and total)

        def check(rule):
            if rule == "needs_link":
                # Scanned, but not tied to RetroAchievements: link it by hand
                return record.get("status") in ("matched", "nomatch") and not record.get("ra_id")
            if not has_set:
                return False                 # the other rules are about achievements
            if rule == "missables":
                model = self.achievement_model(record)
                return bool(model and model["missables_open"])
            return {"started_not_beaten": earned >= 1 and award not in BEATEN_AWARDS,
                    "started_not_mastered": earned >= 1 and award != "mastered",
                    "started_not_completed": earned >= 1 and earned < total
                                             and award not in ("completed", "mastered"),
                    "beaten": award in ("beaten-hardcore", "beaten-softcore"),
                    "completed": award == "completed",
                    "mastered": award == "mastered",
                    "not_started": earned == 0}.get(rule, False)
        results = (check(r) for r in rules)
        return any(results) if match_any else all(results)

    def rules_summary(self, smart):
        names = {k: label for k, label, _note in SMART_RULES}
        joiner = " or " if smart.get("match") == "any" else " · "
        parts = [joiner.join(names.get(r, r) for r in upgrade_rules(smart.get("rules", [])))]
        parts = [p for p in parts if p]
        systems = [self.system_by_id(i)["name"] for i in smart.get("systems", []) if self.system_by_id(i)]
        if systems:
            parts.append(", ".join(systems) if len(systems) <= 2 else f"{len(systems)} systems")
        return " · ".join(parts)

    def new_smart_group(self, existing=None):
        smart = (existing or {}).get("smart") or {}
        dlg = SmartGroupDialog(self.root, name=(existing or {}).get("name", ""),
                               rules=upgrade_rules(smart.get("rules", ())), chosen=smart.get("systems", ()),
                               match=smart.get("match", "all"),
                               systems=[(f["id"], f["name"]) for f in self.settings["folders"]],
                               title="Edit smart group" if existing else "New smart group")
        if not dlg.result:
            return
        name = dlg.result["name"]
        clash = self.series_by_name(name)
        if clash is not None and clash is not existing:
            show_info("Smart group", f"There's already a group named {name}.")
            return
        if existing:
            existing["name"] = name
            existing["smart"] = {k: dlg.result[k] for k in ("rules", "systems", "match")}
        else:
            self.settings["series"].append({"name": name, "games": [], "smart": {
                k: dlg.result[k] for k in ("rules", "systems", "match")}})
        save_settings(self.settings)
        self.show_series_cards()

    # ----- Retro Ratio, fetched for games scanned before it was recorded

    def queue_ratio_fetch(self, ids):
        user, key = self.ra_credentials()
        new = [i for i in dict.fromkeys(ids)
               if i not in self.ratio_tried and i not in self.ratio_queue and i not in self.ratio_busy]
        if not new or not (user and key):
            return
        self.ratio_queue.extend(new)
        self.ratio_tried.update(new)
        if not self.ratio_running:
            self.ratio_running = True
            threading.Thread(target=self.ratio_worker, args=(user, key), daemon=True).start()
            self.root.after(500, self.poll_ratio)

    def ratio_worker(self, user, key):
        while True:
            try:
                ra_id = self.ratio_queue.pop(0)
            except IndexError:
                break
            self.ratio_busy.add(ra_id)
            try:
                ra = ra_progress(ra_id, user, key)
            except Exception:
                ra = None
            self.ratio_results.put((ra_id, ra))
            time.sleep(0.25)
        self.ratio_results.put(None)              # finished

    def poll_ratio(self):
        changed, finished = False, False
        while True:
            try:
                item = self.ratio_results.get_nowait()
            except queue.Empty:
                break
            if item is None:
                finished = True
                continue
            ra_id, ra = item
            self.ratio_busy.discard(ra_id)
            if ra:
                for record in self.meta.values():
                    if str(record.get("ra_id")) == ra_id:
                        record["ra"] = ra
                changed = True
        if changed:
            save_metadata(self.meta)
        left = len(self.ratio_queue) + len(self.ratio_busy)
        if finished or changed and left % 10 == 0:
            self.refresh_lists()                  # re-sort as ratios arrive
        if finished:
            self.ratio_running = False
            self.set_idle_status()
            return
        self.status.config(text=f"Getting Retro Ratios from RetroAchievements… {left} to go")
        self.root.after(500, self.poll_ratio)

    def open_series_list(self, name, keep_search=False):
        series = self.series_by_name(name)
        if series is None:
            return
        self.open_series = name
        self.ser_grid.pack_forget()
        self.ser_list.pack(fill="both", expand=True)
        self.ser_list.show(name, self.series_entries(series), keep_search)
        self.ser_list.listbox.focus_set()
        self.set_idle_status()

    def series_menu_items(self, index):
        entry = self.ser_list.entries[index]
        last = len(self.ser_list.entries) - 1
        items = [("Launch", lambda: self.launch(entry))] + self.disk_items(entry) + [
                 ("Look up details", lambda: self.scan_entries([entry], force=True))] + self.ra_items(entry) + self.achievement_items(entry) + self.guide_items(entry) + [None]
        if (self.series_by_name(self.open_series) or {}).get("smart"):
            return items + [("Edit this smart group's rules…", lambda: self.new_smart_group(
                self.series_by_name(self.open_series)))] + self.rename_items(entry)
        if self.ser_list.sort_id == "custom":
            if index > 0:
                items.append(("Move up", lambda: self.move_in_series(index, -1)))
            if index < last:
                items.append(("Move down", lambda: self.move_in_series(index, 1)))
        else:
            items.append(("Switch to custom order to rearrange",
                          lambda: self.ser_list.set_sort("custom")))
        items += [None, ("Remove from group", lambda: self.remove_from_series(index))]
        return items + self.rename_items(entry)

    def add_to_series(self, entry):
        display, path, system_id = entry
        names = [s["name"] for s in self.settings["series"] if not s.get("smart")]
        dlg = SeriesDialog(self.root, display, names)
        if not dlg.result:
            return
        series = self.series_by_name(dlg.result)
        if series is None:
            series = {"name": dlg.result, "games": []}
            self.settings["series"].append(series)
        if any(norm_path(g["path"]) == norm_path(path) for g in series["games"]):
            self.status.config(text=f"“{display}” is already in {series['name']}.")
            return
        series["games"].append({"title": display, "path": path, "system_id": system_id})
        save_settings(self.settings)
        self.refresh_series_view()
        self.status.config(text=f"Added “{display}” to {series['name']}.")

    def new_series(self):
        kind = ChoiceDialog(self.root, "New group", "What kind of group?",
                            [("regular", "Regular group — you add games to it"),
                             ("smart", "Smart group — fills itself from rules")]).result
        if kind is None:
            return
        if kind == "smart":
            self.new_smart_group()
            return
        name = ask_string("New group", "Group name:", parent=self.root)
        name = (name or "").strip()
        if not name:
            return
        if self.series_by_name(name):
            show_info("New group", f"There's already a group named {name}.")
            return
        self.settings["series"].append({"name": name, "games": []})
        save_settings(self.settings)
        self.show_series_cards()

    def rename_series(self, name):
        series = self.series_by_name(name)
        new = ask_string("Rename group", "New name:", initialvalue=name, parent=self.root)
        new = (new or "").strip()
        if not series or not new or new == name:
            return
        if self.series_by_name(new):
            show_info("Rename group", f"There's already a group named {new}.")
            return
        series["name"] = new
        save_settings(self.settings)
        self.show_series_cards()

    def delete_series(self, name):
        if ask_yes_no("Delete group", f"Delete the group “{name}”?\n(The games themselves are not touched.)",
                      yes="Delete", no="Cancel", default_yes=False):
            self.settings["series"] = [s for s in self.settings["series"] if s["name"] != name]
            save_settings(self.settings)
            self.show_series_cards()

    def move_in_series(self, index, step):
        series = self.series_by_name(self.open_series)
        games = series["games"]
        games[index], games[index + step] = games[index + step], games[index]
        save_settings(self.settings)
        self.ser_list.show(series["name"], self.series_entries(series), keep_search=True)
        self.ser_list.select_index(index + step)

    def remove_from_series(self, index):
        series = self.series_by_name(self.open_series)
        del series["games"][index]
        save_settings(self.settings)
        self.ser_list.show(series["name"], self.series_entries(series), keep_search=True)

    def refresh_series_view(self):
        if self.open_series and self.series_by_name(self.open_series):
            self.open_series_list(self.open_series, keep_search=True)
        else:
            self.show_series_cards()

    # ================================================================ Settings tab (systems)

    def refresh_settings_tree(self):
        self.tree.delete(*self.tree.get_children())
        for f in self.settings["folders"]:
            core = os.path.splitext(f["core"])[0].replace("_libretro", "") if f["core"] else "—"
            self.tree.insert("", "end", iid=f["id"],
                             values=(f["name"], EMULATORS[f["emulator_type"]]["label"], core, f["path"]))

    def add_system(self):
        dlg = FolderDialog(self.root, self.settings.get("last_emulator", DEFAULT_RETROARCH))
        if dlg.result:
            dlg.result["id"] = uuid.uuid4().hex
            self.store_system(dlg.result)

    def edit_system(self, system_id=None):
        if system_id is None:
            sel = self.tree.selection()
            if not sel:
                return
            system_id = sel[0]
        folder = self.system_by_id(system_id)
        if folder is None:
            return
        dlg = FolderDialog(self.root, self.settings.get("last_emulator", DEFAULT_RETROARCH), folder)
        if dlg.result:
            dlg.result["id"] = system_id
            for key in ("color", "card_art", "list_icon"):     # set from the card menu, not the dialog
                dlg.result[key] = folder.get(key, "")
            index = self.settings["folders"].index(folder)
            self.settings["folders"].remove(folder)
            self.store_system(dlg.result, index)

    def store_system(self, result, index=None):
        existing = {f["name"] for f in self.settings["folders"]}
        base, n = result["name"], 2
        while result["name"] in existing:
            result["name"] = f"{base} ({n})"
            n += 1
        if index is None:
            self.settings["folders"].append(result)
        else:
            self.settings["folders"].insert(index, result)
        self.settings["last_emulator"] = result["emulator_exe"]
        self.scan_cache.pop(result["id"], None)
        self.icon_files.pop(result["id"], None)
        save_settings(self.settings)
        self.refresh_all()

    def remove_system(self):
        sel = self.tree.selection()
        if not sel:
            return
        folder = self.system_by_id(sel[0])
        in_series = sum(1 for s in self.settings["series"] for g in s["games"] if g["system_id"] == folder["id"])
        extra = f"\n\n{in_series} group entr{'y' if in_series == 1 else 'ies'} use it and will stop launching." \
            if in_series else ""
        if ask_yes_no("Remove system", f"Remove '{folder['name']}' from the launcher?\n"
                                       f"(No files are deleted.){extra}",
                      yes="Remove", no="Cancel", default_yes=False):
            self.settings["folders"].remove(folder)
            self.scan_cache.pop(folder["id"], None)
            save_settings(self.settings)
            self.refresh_all()

    # ================================================================ metadata

    def details_for(self, entry):
        return self.meta.get(norm_path(entry[1])), bool(self.ra_credentials()[0])

    def ra_credentials(self):
        user = self.ra_user_var.get().strip() if hasattr(self, "ra_user_var") else ""
        key = self.ra_key_var.get().strip() if hasattr(self, "ra_key_var") else ""
        return (user, key) if user and key else ("", "")

    def save_ra_credentials(self):
        self.settings["ra_username"] = self.ra_user_var.get().strip()
        self.settings["ra_api_key"] = self.ra_key_var.get().strip()
        save_settings(self.settings)

    def update_scan_summary(self):
        matched = sum(1 for r in self.meta.values() if r.get("status") == "matched")
        total = len(self.meta)
        self.scan_label.config(text=f"{matched} of {total} scanned games have details." if total
                               else "No games scanned yet.")

    def scan_all(self):
        entries = []
        for folder in self.settings["folders"]:
            entries += [(name, path, folder["id"]) for name, path in self.games_for(folder, fresh=True)]
        self.scan_entries(entries, force=self.rescan_var.get(), update_achievements=True)

    def scan_entries(self, entries, force=False, update_achievements=False):
        """Look up new or changed games. With update_achievements, then refresh your
        RetroAchievements progress for every game in the library."""
        if self.scan_thread is not None and self.scan_thread.is_alive():
            show_info("Scan", "A scan is already running.")
            return
        user, key = self.ra_credentials()
        todo = []
        seen = set()
        ra_systems = {}
        for name, path, sid in entries:
            meta_key = norm_path(path)
            if meta_key in seen:
                continue
            seen.add(meta_key)
            if sid not in ra_systems:                 # RetroAchievements console, for name search
                folder = self.system_by_id(sid)
                ra_systems[sid] = icons.list_icon_file(folder) if folder else ""
            rec = self.meta.get(meta_key)
            # Games not tied to RetroAchievements are searched again by the scan's own step
            # (rematch_phase), from saved hashes, so they aren't hashed again here
            if (force or rec is None or rec.get("status") == "error"
                    or rec.get("signature") != file_signature(path)):
                todo.append((name, path, ra_systems[sid]))
        do_achievements = update_achievements and bool(user and key)
        if not todo and not do_achievements:
            self.scan_label.config(text="Everything is already scanned. Add your RetroAchievements key "
                                        "to also update achievements, or tick “Re-check games already "
                                        "scanned” to look again.")
            return
        self.scan_cancel.clear()
        self.scan_stats = {"looked_up": len(todo), "achievements": 0, "new_unlocks": 0}
        self.scan_step = "Looking up"
        self.scan_btn.config(state="disabled")
        self.cancel_btn.config(state="normal")
        self.scan_progress.config(maximum=max(1, len(todo)), value=0)
        self.scan_thread = threading.Thread(target=self.scan_worker, args=(todo, user, key, do_achievements),
                                            daemon=True)
        self.scan_thread.start()
        self.root.after(150, self.poll_scan)

    def cancel_scan(self):
        self.scan_cancel.set()
        self.scan_label.config(text="Stopping after the current game…")

    def scan_worker(self, todo, user, key, do_achievements=False):
        """Runs in a background thread; reports through scan_queue."""
        for i, (name, path, ra_system) in enumerate(todo):
            if self.scan_cancel.is_set():
                break
            self.scan_queue.put(("progress", i, len(todo), name))
            try:
                record = lookup_game(path, user, key, self.scan_cancel, ra_system)
            except InterruptedError:
                break
            except Exception as err:
                record = {"signature": file_signature(path), "status": "error", "error": str(err)}
            self.scan_queue.put(("result", path, record))
            time.sleep(0.3)   # be gentle with the free servers

        if do_achievements and not self.scan_cancel.is_set():
            self.rematch_phase(user, key)
        if do_achievements and not self.scan_cancel.is_set():
            self.achievement_phase(user, key)
        if do_achievements and not self.scan_cancel.is_set():
            self.description_phase(key)
        self.scan_queue.put(("done", self.scan_cancel.is_set()))

    def rematch_phase(self, user, key):
        """Games not tied to RetroAchievements: search again with the current rules, using the
        hashes saved at scan time (no re-hashing) and the cached weekly game lists (background)."""
        reply = queue.Queue()
        self.scan_queue.put(("need_rematch", reply))
        todo = reply.get()          # [(meta key, path, ra_system, md5s, extra names, title)]
        if not todo:
            return
        self.scan_queue.put(("phase", len(todo), "Searching RetroAchievements"))
        for i, (meta_key, path, ra_system, md5s, extra, title) in enumerate(todo):
            if self.scan_cancel.is_set():
                return
            self.scan_queue.put(("progress", i, len(todo), title))
            try:
                found = ra_fallback(path, md5s, ra_system, user, key, extra)
            except Exception:
                continue
            ra, image = None, ""
            if found and found.get("ra_id"):
                try:
                    ra = ra_progress(found["ra_id"], user, key)
                    image = download_image(ra["boxart_url"]) if ra and ra.get("boxart_url") else ""
                except Exception:
                    pass
                time.sleep(0.3)
            self.scan_queue.put(("rematch", meta_key, found, ra, image))

    def games_needing_rematch(self):
        out = []
        for name, path, system_id in self.library_entries():
            key = norm_path(path)
            rec = self.meta.get(key)
            if not needs_ra_search(rec) or rec.get("signature") != file_signature(path):
                continue                     # changed files are hashed again by the scan itself
            folder = self.system_by_id(system_id)
            ra_system = icons.list_icon_file(folder) if folder else ""
            if not ra_system:
                continue
            md5s = rec.get("md5s") or [rec.get("md5", "")]
            extra = [rec.get("title", ""), rec.get("dat_name", "")] if rec.get("status") == "matched" else []
            out.append((key, path, ra_system, [m for m in md5s if m], extra, name.split("    [")[0]))
        return out

    def description_phase(self, key):
        """Games linked to RetroAchievements but without a description: try the other dumps
        RetroAchievements lists for the game on Hasheous (background thread). Each game is
        searched once; a re-check searches again."""
        reply = queue.Queue()
        self.scan_queue.put(("need_descriptions", reply))
        todo = reply.get()                     # [(meta key, ra_id, title, own md5)]
        if not todo:
            return
        self.scan_queue.put(("phase", len(todo), "Finding descriptions"))
        for i, (meta_key, ra_id, title, md5) in enumerate(todo):
            if self.scan_cancel.is_set():
                return
            self.scan_queue.put(("progress", i, len(todo), title))
            try:
                found = description_from_ra_hashes(ra_id, key, skip=[md5], cancel=self.scan_cancel)
            except Exception:
                continue                       # try again next time
            self.scan_queue.put(("description", meta_key, found))

    def games_needing_description(self):
        force = self.rescan_var.get()
        return [(k, r["ra_id"], r.get("title") or os.path.basename(k), r.get("md5", ""))
                for k, r in self.meta.items()
                if r.get("status") == "matched" and r.get("ra_id") and not r.get("description")
                and (force or not r.get("desc_search_done"))]

    def achievement_phase(self, user, key):
        """Bulk achievement update (background thread).

        One request per 500 games gets your progress on everything you've played. Games that
        were matched before you added your key also need their details fetched once."""
        self.scan_queue.put(("phase", 0, "Checking your RetroAchievements progress…"))
        try:
            progress = ra_completion(user, key, self.scan_cancel)
        except InterruptedError:
            return
        except Exception as err:
            self.scan_queue.put(("ra_error", str(err)))
            return
        reply = queue.Queue()
        self.scan_queue.put(("completion", progress, reply))
        need_details = reply.get()             # [(meta key, ra_id, title)] from the main thread
        if not need_details:
            return
        self.scan_queue.put(("phase", len(need_details), "Fetching achievement details"))
        for i, (meta_key, ra_id, title) in enumerate(need_details):
            if self.scan_cancel.is_set():
                return
            self.scan_queue.put(("progress", i, len(need_details), title))
            try:
                ra = ra_progress(ra_id, user, key)
            except Exception:
                ra = None
            if ra:
                self.scan_queue.put(("ra_detail", meta_key, ra))
            time.sleep(0.3)

    def apply_completion(self, progress):
        """Update every matched game from the bulk progress list. Returns games needing details."""
        need_details = []
        updated = 0
        for meta_key, record in self.meta.items():
            ra_id = record.get("ra_id")
            if not ra_id or record.get("status") != "matched":
                continue
            ra = record.get("ra")
            if not ra:
                need_details.append((meta_key, ra_id, record.get("title") or os.path.basename(meta_key)))
                continue
            # A game missing from your progress list simply has no unlocks yet
            p = progress.get(str(ra_id), {"earned": 0, "earned_hardcore": 0})
            before = ra.get("earned", 0)
            ra["earned"] = p["earned"]
            ra["earned_hardcore"] = p["earned_hardcore"]
            ra["award"] = p.get("award", "")
            if p.get("num_achievements"):
                ra["num_achievements"] = p["num_achievements"]
            if p["earned"] != before:
                updated += 1
                self.scan_stats["new_unlocks"] += max(0, p["earned"] - before)
        self.scan_stats["achievements"] += updated
        return need_details

    def poll_scan(self):
        finished = False
        changed = False
        while True:
            try:
                msg = self.scan_queue.get_nowait()
            except queue.Empty:
                break
            if msg[0] == "progress":
                _, i, total, name = msg
                self.scan_progress.config(value=i)
                self.scan_label.config(text=f"{self.scan_step} {i + 1} of {total}: {name}")
                self.status.config(text=f"{self.scan_step}… {i + 1}/{total}")
            elif msg[0] == "phase":
                _, total, label = msg
                self.scan_step = label.rstrip("…")
                self.scan_progress.config(maximum=max(1, total), value=0)
                self.scan_label.config(text=label)
                self.status.config(text=label)
            elif msg[0] == "completion":
                _, progress, reply = msg
                reply.put(self.apply_completion(progress))
                changed = True
            elif msg[0] == "need_rematch":
                msg[1].put(self.games_needing_rematch())
            elif msg[0] == "rematch":
                _, meta_key, found, ra, image = msg
                record = self.meta.get(meta_key)
                if record is not None and not record.get("ra_id"):    # a manual link made meanwhile wins
                    if apply_ra_search(record, found):
                        if ra:
                            record["ra"] = ra
                        if image and not record.get("image"):
                            record["image"] = image
                        self.scan_stats["linked"] = self.scan_stats.get("linked", 0) + 1
                    elif record.get("ra_candidates"):
                        self.scan_stats["possible"] = self.scan_stats.get("possible", 0) + 1
                    changed = True
            elif msg[0] == "need_descriptions":
                msg[1].put(self.games_needing_description())
            elif msg[0] == "description":
                _, meta_key, found = msg
                if meta_key in self.meta:
                    add_description(self.meta[meta_key], found)
                    if found:
                        self.scan_stats["descriptions"] = self.scan_stats.get("descriptions", 0) + 1
                    changed = True
            elif msg[0] == "ra_detail":
                _, meta_key, ra = msg
                if meta_key in self.meta:
                    self.meta[meta_key]["ra"] = ra
                    self.scan_stats["achievements"] += 1
                    changed = True
            elif msg[0] == "ra_error":
                self.scan_stats["ra_error"] = msg[1]
            elif msg[0] == "result":
                _, path, record = msg
                old = self.meta.get(norm_path(path)) or {}
                if (old.get("match") == "manual" and record.get("signature") == old.get("signature")
                        and (record.get("status") != "matched" or not record.get("ra_id")
                             or "name" in (record.get("match"), record.get("ra_match")))):
                    # Your own link beats a guess, but keep any description etc. the scan found
                    merged = dict(record) if record.get("status") == "matched" else {}
                    merged.update({k: old[k] for k in ("ra_id", "ra", "title", "match", "status",
                                                       "signature", "md5") if k in old})
                    merged["image"] = old.get("image") or merged.get("image", "")
                    merged.pop("ra_match", None)
                    record = merged
                self.meta[norm_path(path)] = record
                changed = True
            elif msg[0] == "done":
                finished = True
                cancelled = msg[1]
        if changed:
            save_metadata(self.meta)
            for view in (self.home_list, self.sys_list, self.ser_list):
                if view.winfo_ismapped():
                    view.update_details()
        if finished:
            self.scan_btn.config(state="normal")
            self.cancel_btn.config(state="disabled")
            self.scan_progress.config(value=self.scan_progress.cget("maximum"))
            errors = sum(1 for r in self.meta.values() if r.get("status") == "error")
            self.update_scan_summary()
            stats = self.scan_stats
            parts = []
            if stats["looked_up"]:
                parts.append(f"{stats['looked_up']} game{'s' if stats['looked_up'] != 1 else ''} looked up")
            if stats["achievements"]:
                parts.append(f"achievements updated for {stats['achievements']} game"
                             f"{'s' if stats['achievements'] != 1 else ''}")
            if stats["new_unlocks"]:
                parts.append(f"🏆 {stats['new_unlocks']} new unlock{'s' if stats['new_unlocks'] != 1 else ''}")
            if stats.get("linked"):
                parts.append(f"{stats['linked']} newly linked to RetroAchievements")
            if stats.get("possible"):
                parts.append(f"{stats['possible']} with possible matches to choose from")
            if stats.get("descriptions"):
                parts.append(f"{stats['descriptions']} description{'s' if stats['descriptions'] != 1 else ''} found")
            summary = ("Cancelled. " if cancelled else "Done. ") + (" · ".join(parts) or "Everything was up to date.")
            if stats.get("ra_error"):
                summary += " Couldn't reach RetroAchievements; check your username and key."
            if errors:
                summary += f" {errors} lookup{'s' if errors != 1 else ''} failed (network?); check again to retry."
            self.scan_label.config(text=summary)
            self.status.config(text=summary)
        else:
            self.root.after(150, self.poll_scan)

    # ================================================================ controller

    PAD_ACTIONS = {"up": "up", "down": "down", "left": "left", "right": "right",
                   "a": "select", "start": "select", "b": "back", "x": "actions", "view": "actions",
                   "y": "hardcore", "lb": "tab_prev", "rb": "tab_next",
                   "lt": "page_up", "rt": "page_down", "rs": "toggle_details"}
    PAD_REPEATS = {"up", "down", "left", "right", "lt", "rt"}

    def window_is_active(self):
        """True when this window (or one of its dialogs) is in front."""
        try:
            import ctypes
            user32 = ctypes.windll.user32
            fg = user32.GetForegroundWindow()
            mine = int(self.root.wm_frame(), 16)
            return fg == mine or user32.GetAncestor(fg, 3) == mine   # 3 = GA_ROOTOWNER
        except Exception:
            return self.root.focus_displayof() is not None

    def poll_pad(self):
        try:
            connected, pressed, right_y = self.pad.poll()
        except Exception:
            connected, pressed, right_y = False, set(), 0.0
        if connected != self.pad_connected:
            self.pad_connected = connected
            if connected and not self.is_running():
                self.status.config(text="Controller connected.")

        # Ignore the pad while a game is running or another program is in front
        if connected and not self.is_running() and self.window_is_active():
            now = time.monotonic()
            for button in pressed - self.pad_prev:
                self.pad_repeat[button] = now + 0.40
                self.safe_dispatch(self.PAD_ACTIONS.get(button))
            for button in pressed & self.pad_prev:
                if button in self.PAD_REPEATS and now >= self.pad_repeat.get(button, now + 1):
                    self.pad_repeat[button] = now + 0.08
                    self.safe_dispatch(self.PAD_ACTIONS.get(button))
            self.scroll_description(right_y)
        else:
            self.desc_scroll = 0.0
        self.pad_prev = pressed
        self.root.after(16, self.poll_pad)

    def safe_dispatch(self, action):
        """Run a controller action. A bug in one action must never stop the controller polling."""
        try:
            self.dispatch_pad(action)
        except Exception:
            import traceback
            traceback.print_exc()
            self.status.config(text=f"Something went wrong with the controller action “{action}”.")

    def scroll_description(self, right_y):
        """Right stick scrolls the open game's description; pushing further scrolls faster."""
        if not right_y:
            self.desc_scroll = 0.0
            return
        tab = self.current_tab()
        view = (self.home_list if tab == "home" else
                self.sys_list if tab == "systems" and self.open_system_id else
                self.ser_list if tab == "series" and self.open_series else None)
        if view is None:
            return
        # Up to ~25 lines per second at full tilt; stick up scrolls up
        self.desc_scroll += -right_y * 25 * 0.016
        lines = int(self.desc_scroll)
        if lines:
            self.desc_scroll -= lines
            view.panel.scroll_widget().yview_scroll(lines, "units")

    def open_actions(self, title, items):
        """Controller menu. Submenus ((label, [items])) open as a second picker."""
        flat = []
        for item in items or []:
            if item is not None and isinstance(item[1], list):
                label, sub = item
                flat.append((label + "  ▸", lambda l=label, t=sub: self.open_actions(l, t)))
            else:
                flat.append(item)
        if any(i is not None for i in flat):
            ActionPicker(self.root, title, flat)

    def dispatch_pad(self, action):
        if action is None:
            return
        # A dialog of ours is open: it gets the input (B closes any dialog)
        grab = self.root.grab_current()
        if grab is not None and grab is not self.root:
            if hasattr(grab, "handle_pad"):
                grab.handle_pad(action)
            elif action == "back":
                grab.destroy()
            return

        tabs = self.notebook.tabs()
        current = self.notebook.index("current")
        tab = TAB_NAMES[current]
        if action in ("tab_prev", "tab_next"):
            for view in (self.home_list, self.sys_list, self.ser_list):
                if view.panel.pad_focus is not None:      # leaving the tab: focus back to the list
                    view.panel.leave_focus()
                    view.dim_selection(False)
            step = -1 if action == "tab_prev" else 1
            self.notebook.select((current + step) % len(tabs))
            return
        if action == "hardcore":
            self.toggle_hardcore()
            return

        if tab == "home":
            self.home_pad(action)
        elif tab == "systems":
            if self.open_system_id:
                self.sys_list.handle_pad(action, self.open_actions)
            else:
                self.sys_grid.handle_pad(action, self.open_actions)
        elif tab == "series":
            if self.open_series:
                self.ser_list.handle_pad(action, self.open_actions)
            else:
                self.ser_grid.handle_pad(action, self.open_actions)
        else:
            self.settings_pad(action)

    # ----- Settings tab with a controller
    # Up/down (or left/right) walk through every control in order, and holding repeats.
    # LT/RT jump between the Systems, Game details and Launcher boxes. A presses, toggles or
    # edits the highlighted control; X opens extra actions.

    SETTINGS_SECTIONS = ("Systems", "Game details", "Launcher", "Reminders")

    def settings_nav_items(self):
        items = [{"section": 0, "kind": "row", "iid": iid, "widget": self.tree_frame}
                 for iid in self.tree.get_children()]
        items += [{"section": 0, "kind": "button", "widget": b}
                  for b in (self.add_btn, self.edit_btn, self.remove_btn)]
        items += [
            {"section": 1, "kind": "entry", "widget": self.ra_user_entry, "var": self.ra_user_var,
             "label": "RetroAchievements username", "secret": False},
            {"section": 1, "kind": "entry", "widget": self.ra_key_entry, "var": self.ra_key_var,
             "label": "RetroAchievements Web API key", "secret": True},
            {"section": 1, "kind": "button", "widget": self.scan_btn},
            {"section": 1, "kind": "button", "widget": self.cancel_btn},
            {"section": 1, "kind": "toggle", "widget": self.rescan_cb},
            {"section": 1, "kind": "toggle", "widget": self.badges_cb},
        ]
        items += [{"section": 2, "kind": "toggle", "widget": w}
                  for w in [self.minimize_cb, self.hide_tags_cb, self.list_icons_cb, self.system_names_cb]]
        items.append({"section": 3, "kind": "button", "widget": self.reset_btn})
        items.append({"section": 3, "kind": "toggle", "widget": self.show_rem_cb})
        # Skip buttons that can't be pressed right now (e.g. Cancel when nothing is running)
        return [i for i in items if i["kind"] != "button" or str(i["widget"].cget("state")) != "disabled"]

    def nav_highlight(self, widget, on):
        """Draw (or remove) the controller highlight around a control."""
        if widget is None:
            return
        try:
            if on:
                if not hasattr(widget, "_nav_saved"):
                    widget._nav_saved = (widget.cget("highlightthickness"),
                                         widget.cget("highlightbackground"), widget.cget("highlightcolor"))
                widget.config(highlightthickness=px(2), highlightbackground=T["accent"],
                              highlightcolor=T["accent"])
            elif hasattr(widget, "_nav_saved"):
                thickness, background, color = widget._nav_saved
                widget.config(highlightthickness=thickness, highlightbackground=background,
                              highlightcolor=color)
        except tk.TclError:
            pass

    def ring_clear(self):
        for edge in self.nav_ring:
            edge.destroy()
        self.nav_ring = []
        self.nav_ring_target = None

    def ring_follow(self, _event=None):
        """Keep the outline on its control when the window is resized."""
        if self.nav_ring_target is not None and self.nav_ring:
            self.ring_draw(self.nav_ring_target)

    def ring_draw(self, widget):
        """A clear blue outline around a control, the same as the text boxes get.

        Drawn on the Settings page itself (not inside the control's own box), using screen
        positions, so it lines up exactly and is never cut off by a small surrounding frame."""
        for edge in self.nav_ring:
            edge.destroy()
        self.nav_ring = []
        page = self.settings_tab
        widget.update_idletasks()
        t, pad = px(2), px(2)
        x = widget.winfo_rootx() - page.winfo_rootx() - pad - t
        y = widget.winfo_rooty() - page.winfo_rooty() - pad - t
        w, h = widget.winfo_width() + 2 * (pad + t), widget.winfo_height() + 2 * (pad + t)
        for ex, ey, ew, eh in ((x, y, w, t), (x, y + h - t, w, t), (x, y, t, h), (x + w - t, y, t, h)):
            edge = tk.Frame(page, bg=T["accent"], highlightthickness=0, bd=0)
            edge.place(in_=page, x=ex, y=ey, width=ew, height=eh, bordermode="outside")
            edge.lift()
            self.nav_ring.append(edge)

    def ring_on(self, widget):
        self.ring_clear()
        self.nav_ring_target = widget
        if not getattr(self, "_ring_follow_bound", False):
            self.settings_tab.bind("<Configure>", self.ring_follow, add="+")
            self._ring_follow_bound = True
        self.ring_draw(widget)

    def nav_show(self, items):
        self.nav_highlight(self.nav_widget, False)
        self.ring_clear()
        if not items:
            self.nav_widget = None
            return
        self.nav_index = max(0, min(len(items) - 1, self.nav_index))
        item = items[self.nav_index]
        self.nav_widget = item["widget"]
        if item["kind"] in ("button", "toggle"):
            self.ring_on(self.nav_widget)
        elif item["kind"] == "entry":
            self.nav_highlight(self.nav_widget, True)
        # System rows show as the selected row only; the list itself isn't outlined
        if item["kind"] == "row":
            self.tree.selection_set(item["iid"])
            self.tree.focus(item["iid"])
            self.tree.see(item["iid"])
        section = self.SETTINGS_SECTIONS[item["section"]]
        self.status.config(text=f"Settings › {section}  |  LT/RT: previous/next box  ·  A: choose  ·  X: more")

    def settings_pad(self, action):
        items = self.settings_nav_items()
        if not items:
            return
        if not self.nav_shown:
            self.nav_shown = True           # first press just shows where you are
            self.nav_show(items)
            return
        self.nav_index = max(0, min(len(items) - 1, self.nav_index))
        item = items[self.nav_index]
        if action in ("up", "left"):
            self.nav_index = max(0, self.nav_index - 1)
        elif action in ("down", "right"):
            self.nav_index = min(len(items) - 1, self.nav_index + 1)
        elif action in ("page_up", "page_down"):
            target = item["section"] + (-1 if action == "page_up" else 1)
            first = next((i for i, it in enumerate(items) if it["section"] == target), None)
            if first is not None:
                self.nav_index = first
        elif action == "select":
            self.nav_activate(item)
            return
        elif action == "actions":
            extra = [("Add system…", self.add_system), ("Check for updates", self.scan_all)]
            if item["kind"] == "row":
                extra = [("Edit system…", lambda: self.edit_system(item["iid"])),
                         ("Remove system", self.remove_system), None] + extra
            self.open_actions("Settings", extra)
            return
        else:
            return
        self.nav_show(items)

    def nav_activate(self, item):
        kind = item["kind"]
        if kind == "row":
            self.edit_system(item["iid"])
        elif kind in ("button", "toggle"):
            item["widget"].invoke()
        elif kind == "entry":
            value = ask_string(item["label"], f"{item['label']}:", item["var"].get(), self.root,
                               secret=item["secret"])
            if value is not None:
                item["var"].set(value.strip())
        # The list can change (a system added or removed), so redraw the highlight
        if self.root.winfo_exists() and self.current_tab() == "settings":
            self.nav_show(self.settings_nav_items())

    # ================================================================ hardcore toggle

    def toggle_hardcore(self):
        self.settings["hardcore"] = not self.settings["hardcore"]
        save_settings(self.settings)
        self.update_toggle_look()

    def update_toggle_look(self):
        if self.settings["hardcore"]:
            self.toggle_btn.config(text="HARDCORE", bg="#b3261e", fg="white",
                                   activebackground="#8c1d18", activeforeground="white")
        else:
            self.toggle_btn.config(text="CASUAL", bg="#2e7d32", fg="white",
                                   activebackground="#1b5e20", activeforeground="white")
        folder = self.system_by_id(self.open_system_id) if self.open_system_id else None
        on_systems_tab = bool(self.notebook.tabs()) and self.current_tab() == "systems"
        if self.is_running():
            note = "A game is running. A change applies at the next launch."
        elif on_systems_tab and folder and not self.manages_hardcore(folder):
            note = f"Not applied to {folder['name']}: its emulator isn't supported."
        else:
            note = ""
        self.toggle_note.config(text=note)

    @staticmethod
    def manages_hardcore(folder):
        return folder["emulator_type"] == "retroarch" or bool(EMULATORS[folder["emulator_type"]]["hardcore"])

    def apply_hardcore(self, folder):
        """Write the toggle's value where this emulator reads it. Returns False to cancel the launch."""
        emu = folder["emulator_type"]
        on = self.settings["hardcore"]
        if emu == "retroarch":
            with open(OVERRIDE_CFG, "w", encoding="utf-8") as f:
                f.write(f'cheevos_hardcore_mode_enable = "{"true" if on else "false"}"\n')
            return True

        hardcore = EMULATORS[emu]["hardcore"]
        if not hardcore:
            return True
        path = folder.get("config_file") or detect_config(emu, folder["emulator_exe"])
        if not path or not os.path.isdir(os.path.dirname(path)):
            return ask_yes_no(
                "Hardcore setting",
                f"Couldn't find {EMULATORS[emu]['label']}'s settings file, so the hardcore "
                "toggle can't be applied.\n\nSet it under Settings → Edit. Launch anyway?",
                yes="Launch anyway", no="Cancel")
        try:
            write_hardcore(emu, path, on)
        except (OSError, ValueError) as err:
            return ask_yes_no(
                "Hardcore setting", f"Couldn't update:\n{path}\n\n{err}\n\nLaunch anyway?",
                yes="Launch anyway", no="Cancel")
        return True

    # ================================================================ launching

    def is_running(self):
        return self.process is not None and self.process.poll() is None

    def build_command(self, folder, rom):
        exe = folder["emulator_exe"]
        extra = split_args(folder.get("extra_args", ""))
        if any("{rom}" in a for a in extra):
            return [exe] + [a.replace("{rom}", rom) for a in extra]

        emu = folder["emulator_type"]
        if emu == "retroarch":
            core = os.path.join(cores_dir(exe), folder["core"])
            return [exe] + extra + ["-L", core, "--appendconfig", OVERRIDE_CFG, rom]
        if emu in ("duckstation", "pcsx2"):
            return [exe, "-batch"] + extra + ["--", rom]
        if emu == "dolphin":
            return [exe, "-b"] + extra + ["-e", rom]
        if emu == "rapplewin":
            if os.path.splitext(rom)[1].lower() == ".hdv":
                return [exe] + extra + ["-h1", rom]
            cmd = [exe] + extra + ["-d1", rom]
            disks = disk_set(rom)
            if len(disks) > 1:
                # Put the disk that follows the boot disk in drive 2
                pos = next((i for i, d in enumerate(disks) if norm_path(d) == norm_path(rom)), 0)
                cmd += ["-d2", disks[(pos + 1) % len(disks)]]
            return cmd
        return [exe] + extra + [rom]

    def launch(self, entry):
        name, rom, system_id = entry
        if self.is_running():
            show_info("Running", "A game is already running. Close it first.")
            return
        folder = self.system_by_id(system_id)
        if folder is None:
            show_error("Launch", "The system this game belonged to has been removed.\n"
                                           "Add it again under Settings, or remove the entry.")
            return
        if not os.path.isfile(rom):
            show_error("Launch", f"Game file not found:\n{rom}")
            return
        exe = folder["emulator_exe"]
        if not os.path.isfile(exe):
            show_error("Emulator", f"Emulator not found:\n{exe}\n\nFix it under Settings → Edit.")
            return
        if folder["emulator_type"] == "retroarch":
            core_path = os.path.join(cores_dir(exe), folder["core"])
            if not os.path.isfile(core_path):
                show_error("Core", f"Core not found:\n{core_path}")
                return

        if not self.apply_hardcore(folder):
            return
        guide = self.guide_url(entry)
        if guide:
            # Opened first so the emulator, starting a moment later, ends up in front
            try:
                webbrowser.open(guide)
            except Exception:
                pass
        try:
            self.process = subprocess.Popen(self.build_command(folder, rom), cwd=os.path.dirname(exe))
        except OSError as err:
            show_error("Launch failed", str(err))
            return

        if self.manages_hardcore(folder):
            mode = "Hardcore" if self.settings["hardcore"] else "Casual"
        else:
            mode = "mode set in emulator"
        self.status.config(text=f"Running: {name}  [{mode}]  ({EMULATORS[folder['emulator_type']]['label']})")
        self.last_entry = entry
        self.record_recent(entry)
        self.refresh_home()
        if self.current_tab() == "home":
            self.home_list.select_index(0)       # the game just launched is now at the top
        for view in (self.home_list, self.sys_list, self.ser_list):
            view.update_launch_state()
        self.update_toggle_look()

        self.minimized_for_game = self.minimize_var.get()
        if self.minimized_for_game:
            self.root.iconify()

    def check_process(self):
        if self.process is not None and self.process.poll() is not None:
            self.process = None
            if self.minimized_for_game:
                self.minimized_for_game = False
                self.root.deiconify()
                self.root.lift()
                self.root.focus_force()
            for view in (self.home_list, self.sys_list, self.ser_list):
                view.update_launch_state()
            self.update_toggle_look()
            self.set_idle_status()
            if self.last_entry is not None:
                self.refresh_achievements(self.last_entry)
        # Once a minute, let games that passed the two-week mark drop off Home
        self.prune_counter += 1
        if self.prune_counter >= 60:
            self.prune_counter = 0
            if self.prune_recent():
                self.refresh_home()
            self.refresh_reminders()          # reminders turn "due", and daily ones reset at midnight
        self.root.after(1000, self.check_process)

    def set_idle_status(self):
        if self.is_running():
            return
        tab = self.current_tab() if self.notebook.tabs() else "home"
        if tab == "home" and self.home_searching:
            found = len(self.home_list.visible)
            self.status.config(text=f"{found} match{'es' if found != 1 else ''} in your library "
                                    f"({len(self.home_list.entries)} games)  |  Esc clears the search")
        elif tab == "home":
            n = len(self.home_list.entries)
            self.status.config(text=f"{n} game{'s' if n != 1 else ''} played in the last two weeks  "
                                    f"|  Games drop off after {RECENT_DAYS} days without a launch"
                               if n else "Games you launch appear here for two weeks.")
        elif tab == "systems" and self.open_system_id:
            folder = self.system_by_id(self.open_system_id)
            view = self.sys_list
            emu = EMULATORS[folder["emulator_type"]]["label"]
            if folder["core"]:
                emu += f" · {os.path.splitext(folder['core'])[0]}"
            self.status.config(text=f"{len(view.visible)} of {len(view.entries)} games  |  {emu}  "
                                    "|  Right-click a game to add it to a group")
        elif tab == "series" and self.open_series:
            n = len(self.ser_list.entries)
            self.status.config(text=f"{n} game{'s' if n != 1 else ''} in this group  "
                                    "|  Right-click to reorder or remove")
        else:
            n = len(self.settings["folders"])
            self.status.config(text=f"{n} system{'s' if n != 1 else ''}  |  Click a card to open it."
                               if n else "Click “+ Add system” to get started.")


def main():
    theme.enable_dpi_awareness()        # must happen before the window is created
    theme.set_app_identity()            # taskbar shows the app's icon rather than Python's
    while True:
        root = tk.Tk()
        # Hidden while it's built, so it doesn't flash up as a small white box first
        root.withdraw()
        app = Launcher(root)
        root.update_idletasks()
        theme.style_title_bar(root, hide_caption=True, now=True)   # dark title bar before it shows
        root.deiconify()
        # Once more after it's on screen, in case Windows ignored it while hidden
        theme.style_title_bar(root, hide_caption=True)
        root.mainloop()
        if not app.restart_requested:   # a theme change rebuilds the window; anything else quits
            break
