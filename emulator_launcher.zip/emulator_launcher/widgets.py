"""Reusable pieces of the main window: card grids, the game list and its details panel."""

import os
import re
import time
import tkinter as tk
import webbrowser
from tkinter import font as tkfont
from tkinter import ttk

from .library import region_of
from .theme import T, px, scrollbar


def list_row_height():
    """Game list row height: enough for a system icon with a little air around it."""
    return max(px(30), list_icon_size() + px(6))


def list_icon_size():
    """System icons are 32×32; show them at 24 px on normal screens, 32 on high-DPI ones."""
    return 32 if px(24) >= 30 else 24


def card_width():
    return px(210)


def card_height():
    return px(120)


ACCENTS = {"retroarch": "#5b4bbd", "duckstation": "#c27c0e", "pcsx2": "#1f6fb2",
           "dolphin": "#1a9b8a", "ppsspp": "#d9531e", "rapplewin": "#3a8f3a", "other": "#6b6b6b", "series": "#b0306a", "add": "#9e9e9e",
           "rap64": "#2e8b57", "ravba": "#6a4fb3", "rasnes9x": "#8a5cc7", "ranes": "#b33a3a",
           "rameka": "#2a6fb0", "raquasi88": "#7a6a3a"}


class TabBar(tk.Frame):
    """Page container with tab buttons that live in a separate bar.

    Unlike ttk.Notebook, the buttons can share a row with other controls (the Hardcore
    toggle). Mirrors the bits of the Notebook API the app uses: add, select, index, tabs,
    and the <<NotebookTabChanged>> event."""

    TAB_FONT = ("Segoe UI", 12)
    TAB_FONT_ON = ("Segoe UI", 12, "bold")

    def __init__(self, master, button_bar):
        super().__init__(master)
        self.button_bar = button_bar
        self.pages = []
        self.buttons = []           # (label, underline)
        self.current = 0

    def add(self, page, text):
        index = len(self.pages)
        holder = tk.Frame(self.button_bar, cursor="hand2")
        holder.pack(side="left", padx=(0, 4))
        label = tk.Label(holder, text=text.strip(), font=self.TAB_FONT, padx=14, pady=6)
        label.pack()
        underline = tk.Frame(holder, height=3)
        underline.pack(fill="x")
        for w in (holder, label):
            w.bind("<Button-1>", lambda e, i=index: self.select(i))
        self.pages.append(page)
        self.buttons.append((label, underline))
        if index == 0:
            self.select(0)

    def select(self, index):
        index = index % len(self.pages)
        for i, page in enumerate(self.pages):
            if i != index:
                page.pack_forget()
        self.pages[index].pack(fill="both", expand=True)
        for i, (label, underline) in enumerate(self.buttons):
            on = i == index
            label.config(font=self.TAB_FONT_ON if on else self.TAB_FONT,
                         fg=T["text"] if on else T["text_muted"])
            underline.config(bg=T["accent"] if on else self.button_bar.cget("bg"))
        changed = index != self.current
        self.current = index
        if changed:
            self.event_generate("<<NotebookTabChanged>>")

    def index(self, _what="current"):
        return self.current

    def tabs(self):
        return list(self.pages)


class CardGrid(tk.Frame):
    """A scrolling, wrapping grid of clickable cards."""

    def __init__(self, master):
        super().__init__(master)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        scroll = scrollbar(self, self.canvas.yview)
        self.canvas.config(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.holder = tk.Frame(self.canvas)
        self.window = self.canvas.create_window((0, 0), window=self.holder, anchor="nw")
        self.holder.bind("<Configure>", lambda e: self.canvas.config(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self.on_resize)
        self.cards = []
        self.specs = []
        self.columns = 1
        self.focus = 0
        self.show_focus = False      # only highlight once the controller is used
        self.on_swap = None          # fn(i, j): swap cards i and j (set by the owner)
        self.drag = None             # state of a drag in progress

    def on_resize(self, event):
        self.canvas.itemconfig(self.window, width=event.width)
        columns = max(1, event.width // (card_width() + 16))
        if columns != self.columns:
            self.columns = columns
            self.layout()

    def handle_wheel(self, event):
        """Scroll if the pointer is over this grid. Returns True if it did."""
        if not self.winfo_ismapped():
            return False
        widget = self.winfo_containing(event.x_root, event.y_root)
        while widget is not None:
            if widget is self:
                self.canvas.yview_scroll(int(-event.delta / 120), "units")
                return True
            widget = widget.master
        return False

    def set_cards(self, specs):
        """specs: dicts with title, subtitle, detail, accent, command, optional menu (list of (label, fn))."""
        for card in self.cards:
            card.destroy()
        self.specs = specs
        self.cards = [self.make_card(**spec) for spec in specs]
        self.focus = min(self.focus, max(0, len(self.cards) - 1))
        self.layout()
        self.paint_focus()

    def paint_focus(self):
        for i, card in enumerate(self.cards):
            focused = self.show_focus and i == self.focus
            card.config(highlightthickness=3 if focused else 1,
                        highlightbackground=T["accent"] if focused else T["border"])

    def ensure_visible(self):
        if not self.cards:
            return
        self.update_idletasks()
        card = self.cards[self.focus]
        total = max(1, self.holder.winfo_height())
        view_h = self.canvas.winfo_height()
        top = self.canvas.yview()[0] * total
        y, h = card.winfo_y(), card.winfo_height()
        if y < top:
            self.canvas.yview_moveto(max(0, y - 8) / total)
        elif y + h > top + view_h:
            self.canvas.yview_moveto((y + h + 8 - view_h) / total)

    def handle_pad(self, action, open_actions):
        if not self.cards:
            return
        if not self.show_focus:
            self.show_focus = True        # first press just reveals the highlight
            self.paint_focus()
            return
        n, cols, i = len(self.cards), self.columns, self.focus
        if action == "left" and i % cols:
            i -= 1
        elif action == "right" and i + 1 < n and (i + 1) % cols:
            i += 1
        elif action == "up" and i - cols >= 0:
            i -= cols
        elif action == "down" and i // cols < (n - 1) // cols:
            i = min(n - 1, i + cols)
        elif action == "select":
            self.specs[i]["command"]()
            return
        elif action == "actions" and self.specs[i].get("menu"):
            open_actions(self.specs[i]["title"], self.specs[i]["menu"])
            return
        if i != self.focus:
            self.focus = i
            self.paint_focus()
            self.ensure_visible()

    def make_card(self, title, subtitle, detail, accent, command, menu=None, muted=False,
                  movable=False, art=None):
        """art: an image path shown on the right side of the card (optional)."""
        bg, hover = T["surface"], T["surface_hover"]
        card = tk.Frame(self.holder, bg=bg, width=card_width(), height=card_height(),
                        highlightthickness=1, highlightbackground=T["border"], cursor="hand2")
        card.pack_propagate(False)
        tk.Frame(card, bg=accent, height=px(6)).pack(fill="x")
        widgets = []
        text_width = card_width() - px(24)
        photo = load_photo(art, int(card_width() * 0.42), card_height() - px(18)) if art else None
        if photo is not None:
            art_label = tk.Label(card, image=photo, bg=bg)
            art_label.image = photo                 # keep a reference, or Tk drops the picture
            art_label.pack(side="right", padx=(0, px(8)), pady=px(6))
            widgets.append(art_label)
            text_width -= photo.width() + px(8)
        title_label = tk.Label(card, text=title, bg=bg, font=("Segoe UI", 13, "bold"),
                               fg=T["text_faint"] if muted else T["text"], anchor="w",
                               justify="left", wraplength=max(px(60), text_width))
        subtitle_label = tk.Label(card, text=subtitle, bg=bg, font=("Segoe UI", 10),
                                  fg=T["text_muted"], anchor="w")
        detail_label = tk.Label(card, text=detail, bg=bg, font=("Segoe UI", 9),
                                fg=T["text_faint"], anchor="w", justify="left",
                                wraplength=max(px(60), text_width))
        title_label.pack(fill="x", padx=12, pady=(10, 2))
        subtitle_label.pack(fill="x", padx=12)
        detail_label.pack(fill="x", padx=12, side="bottom", pady=(0, 10))
        widgets += [title_label, subtitle_label, detail_label]

        def paint(color):
            card.config(bg=color)
            for w in widgets:
                w.config(bg=color)

        def popup(event):
            popup_menu(card, menu, event.x_root, event.y_root)

        for w in [card] + widgets:
            # A click opens the card; pressing and moving drags it instead
            w.bind("<ButtonPress-1>", lambda e: self.drag_start(e, card, title, accent, movable))
            w.bind("<B1-Motion>", self.drag_motion)
            w.bind("<ButtonRelease-1>", lambda e: self.drag_end(e, command))
            w.bind("<Enter>", lambda e: paint(hover))
            w.bind("<Leave>", lambda e: paint(bg))
            if menu:
                w.bind("<Button-3>", popup)
        return card

    # ----- drag and drop

    DRAG_THRESHOLD = 6

    def card_at(self, x_root, y_root):
        widget = self.winfo_containing(x_root, y_root)
        while widget is not None:
            if widget in self.cards:
                return self.cards.index(widget)
            widget = widget.master
        return None

    def drag_start(self, event, card, title, accent, movable):
        self.drag = {"source": self.cards.index(card), "x": event.x_root, "y": event.y_root,
                     "title": title, "accent": accent, "movable": movable and self.on_swap is not None,
                     "active": False, "ghost": None, "target": None}

    def drag_motion(self, event):
        d = self.drag
        if not d or not d["movable"]:
            return
        if not d["active"]:
            if abs(event.x_root - d["x"]) + abs(event.y_root - d["y"]) < self.DRAG_THRESHOLD:
                return
            d["active"] = True
            ghost = tk.Toplevel(self)
            ghost.overrideredirect(True)
            try:
                ghost.attributes("-alpha", 0.85)
                ghost.attributes("-topmost", True)
            except tk.TclError:
                pass
            tk.Label(ghost, text=d["title"], bg=d["accent"], fg="white",
                     font=("Segoe UI", 11, "bold"), padx=14, pady=10).pack()
            d["ghost"] = ghost
            self.cards[d["source"]].config(highlightthickness=3, highlightbackground=T["drag_source"])
        d["ghost"].geometry(f"+{event.x_root + 12}+{event.y_root + 12}")

        # Scroll when dragging near the top or bottom edge
        top = self.canvas.winfo_rooty()
        bottom = top + self.canvas.winfo_height()
        if event.y_root < top + 30:
            self.canvas.yview_scroll(-1, "units")
        elif event.y_root > bottom - 30:
            self.canvas.yview_scroll(1, "units")

        target = self.card_at(event.x_root, event.y_root)
        if target is not None and not self.specs[target].get("movable"):
            target = None
        if target != d["target"]:
            d["target"] = target
            self.paint_focus()
            self.cards[d["source"]].config(highlightthickness=3, highlightbackground=T["drag_source"])
            if target is not None and target != d["source"]:
                self.cards[target].config(highlightthickness=3, highlightbackground=T["drop_target"])

    def drag_end(self, event, command):
        d, self.drag = self.drag, None
        if not d:
            return
        if not d["active"]:
            # A plain click: only open if the release is still on the same card
            if self.card_at(event.x_root, event.y_root) == d["source"]:
                command()
            return
        d["ghost"].destroy()
        self.paint_focus()
        target = d["target"]
        if target is not None and target != d["source"]:
            self.on_swap(d["source"], target)

    def layout(self):
        for i, card in enumerate(self.cards):
            card.grid(row=i // self.columns, column=i % self.columns, padx=8, pady=8, sticky="nw")


def image_box():
    """Max width/height of cover art in the details panel."""
    return px(240)
BIG_BUTTON_FONT = ("Segoe UI", 14, "bold")   # shared by the Hardcore toggle and Launch, so they match


def load_photo(path, box=None, box_h=None, pixel_art=False):
    """Load an image scaled to fit box × box_h. Uses Pillow if installed, else Tk's PNG/GIF support.

    pixel_art keeps hard pixel edges when enlarging (for tiny icons)."""
    box = box or image_box()
    box_h = box_h or box
    if not path or not os.path.isfile(path):
        return None
    try:
        from PIL import Image, ImageTk
        img = Image.open(path).convert("RGBA")
        scale = min(box / img.width, box_h / img.height)
        if scale > 1 and not pixel_art:
            scale = 1                      # don't blow photos up
        if scale != 1:
            size = (max(1, round(img.width * scale)), max(1, round(img.height * scale)))
            resample = Image.NEAREST if pixel_art and scale > 1 else Image.LANCZOS
            img = img.resize(size, resample)
        return ImageTk.PhotoImage(img)
    except ImportError:
        pass
    except Exception:
        return None
    if os.path.splitext(path)[1].lower() not in (".png", ".gif"):
        return None
    try:
        photo = tk.PhotoImage(file=path)
        w, h = photo.width(), photo.height()
        shrink = max(1, -(-w // box), -(-h // box_h))
        if shrink > 1:
            return photo.subsample(shrink)
        grow = min(box // max(1, w), box_h // max(1, h))
        return photo.zoom(grow) if pixel_art and grow > 1 else photo
    except tk.TclError:
        return None


_MD_BOLD = re.compile(r"\*\*(.+?)\*\*|__(.+?)__")
_MD_ITALIC = re.compile(r"(?<![\w*])\*(?!\s)([^*\n]+?)(?<!\s)\*(?![\w*])")
_MD_LINK = re.compile(r"\[([^\]]+)\]\([^)]+\)")


def markdown_chunks(text):
    """Split a markdown description into (text, tag) chunks for a Text widget.

    Drops a leading heading (usually 'Game - Synopsis'), shows later headings in bold,
    turns list markers into bullets, and removes emphasis markers and link targets."""
    chunks = []
    seen_content = False
    for raw in (text or "").replace("\r", "").split("\n"):
        line = raw.strip()
        heading = re.match(r"^#{1,6}\s*(.*)$", line)
        if heading:
            if seen_content:
                chunks.append((heading.group(1).strip() + "\n", "h"))
            continue
        if line:
            seen_content = True
        line = re.sub(r"^[-*+]\s+", "•  ", line)
        line = _MD_LINK.sub(r"\1", line)
        line = _MD_BOLD.sub(lambda m: m.group(1) or m.group(2), line)
        line = _MD_ITALIC.sub(r"\1", line)
        chunks.append((line + "\n", None))

    # Trim leading blank lines and collapse runs of blank lines to one
    tidy = []
    for chunk in chunks:
        blank = not chunk[0].strip()
        if blank and (not tidy or not tidy[-1][0].strip()):
            continue
        tidy.append(chunk)
    while tidy and not tidy[-1][0].strip():
        tidy.pop()
    return tidy


def ra_game_url(ra_id):
    return f"https://retroachievements.org/game/{ra_id}"


# RetroAchievements award circles: gold = hardcore, white = softcore; filled = all achievements
AWARDS = {
    "mastered": ("Mastered", "#e5b143", True),
    "completed": ("Completed", "#e5b143", False),
    "beaten-hardcore": ("Beaten", "#c4c4c4", True),
    "beaten-softcore": ("Beaten (softcore)", "#c4c4c4", False),
}


def draw_award(canvas, kind, size, bg):
    """Draw the award circle for kind on a small canvas."""
    canvas.delete("all")
    canvas.config(bg=bg)
    if kind not in AWARDS:
        return
    _label, color, filled = AWARDS[kind]
    edge = "#7a5c12" if color == "#e5b143" else "#8a8a8a"
    pad = max(1, size // 8)
    ring = max(2, size // 5)
    if filled:
        canvas.create_oval(pad, pad, size - pad, size - pad, fill=color, outline=edge)
    else:
        canvas.create_oval(pad, pad, size - pad, size - pad, fill="", outline=color, width=ring)
        canvas.create_oval(pad, pad, size - pad, size - pad, fill="", outline=edge, width=1)


def load_badge(game_id, badge, locked, size):
    """An achievement badge from the local cache: grayed out while locked (needs Pillow)."""
    from .achievements import badge_path
    if not (game_id and badge):
        return None
    path = badge_path(game_id, badge)
    if not os.path.isfile(path):
        return None
    try:
        from PIL import Image, ImageEnhance, ImageTk
        img = Image.open(path).convert("RGBA").resize((size, size), Image.LANCZOS)
        if locked:
            alpha = img.getchannel("A")
            img = ImageEnhance.Brightness(img.convert("L")).enhance(0.55).convert("RGBA")
            img.putalpha(alpha)
        return ImageTk.PhotoImage(img)
    except ImportError:
        return load_photo(path, size, size)
    except Exception:
        return None


class TargetBlock(tk.Frame):
    """The achievement you're going for, shown in the app bar beside the Hardcore toggle.

    Gray badge while locked, full color once unlocked. Right-click for its menu.
    Its text is kept to a fixed width so a long name never widens the window."""

    TEXT_WIDTH = px(360)

    def fit(self, text, font):
        """Shorten text with an ellipsis until it fits TEXT_WIDTH."""
        try:
            measure = tkfont.Font(font=font).measure
        except Exception:
            return text if len(text) <= 28 else text[:27].rstrip() + "…"
        if measure(text) <= self.TEXT_WIDTH:
            return text
        while text and measure(text + "…") > self.TEXT_WIDTH:
            text = text[:-1]
        return text.rstrip(" ·") + "…"

    def __init__(self, master, on_menu):
        super().__init__(master, bg=T["field"], padx=px(8), pady=0,
                         highlightthickness=1, highlightbackground=T["border"])
        # A fixed size (set by fit_height): the block never makes the app bar taller or wider
        self.pack_propagate(False)
        self.on_menu = on_menu
        self.photo = None
        self.height = px(46)
        self.badge = tk.Label(self, bg=T["field"])
        self.badge.pack(side="left", padx=(0, px(8)))
        text = tk.Frame(self, bg=T["field"])
        text.pack(side="left", anchor="w")
        self.top = tk.Label(text, bg=T["field"], fg=T["text_faint"], font=("Segoe UI", 9),
                            anchor="w", justify="left")
        self.top.pack(fill="x")
        self.title = tk.Label(text, bg=T["field"], fg=T["text"], font=("Segoe UI", 10, "bold"),
                              anchor="w", justify="left", wraplength=self.TEXT_WIDTH)
        self.title.pack(fill="x")
        self.on_click = None
        for w in (self, self.badge, text, self.top, self.title):
            w.bind("<Button-3>", self.menu)
            w.bind("<Button-1>", lambda e: self.on_click and self.on_click())
            w.config(cursor="hand2")

    def menu(self, event):
        self.on_menu(event)
        return "break"

    def badge_size(self):
        return max(px(20), min(px(36), self.height - px(10)))

    def fit_height(self, height):
        """Match the Hardcore toggle's height; the width is fixed."""
        self.height = height
        width = px(8) * 2 + self.badge_size() + px(8) + self.TEXT_WIDTH + 2
        self.config(width=width, height=height)

    def show(self, target, earned):
        """target: the saved target dict; earned: '', 'casual' or 'hardcore'."""
        size = self.badge_size()
        self.photo = load_badge(target.get("game_id"), target.get("badge"), not earned, size)
        self.badge.config(image=self.photo or "", text="" if self.photo else "🎯",
                          font=("Segoe UI", 16))
        game = target.get("game", "")
        small = ("Segoe UI", 9)
        if earned:
            top = f"✓ Unlocked{' (hardcore)' if earned == 'hardcore' else ''} · {game}"
            self.top.config(text=self.fit(top, small),
                            fg=T["gold"] if earned == "hardcore" else T["text_muted"])
        else:
            self.top.config(text=self.fit(f"🎯 Target · {game}", small), fg=T["text_faint"])
        # One line of title, to keep the block the toggle's height
        self.title.config(text=self.fit(target.get("title", ""), ("Segoe UI", 10, "bold")),
                          fg=T["text_muted"] if earned else T["text"])


class DetailsPanel(tk.Frame):
    """Right-hand panel in two columns.

    Left:  game title, then the description (fills the height).
    Right: box art, then platform/year, developer/publisher, genre and achievements."""

    def __init__(self, master):
        super().__init__(master, padx=12, pady=4)
        self.photo = None
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, minsize=image_box())   # art column never changes width
        self.rowconfigure(0, weight=1)

        # Left column: title + description
        left = tk.Frame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        self.left = left
        self.title = tk.Label(left, font=("Segoe UI", 15, "bold"), anchor="w", justify="left")
        self.title.pack(fill="x")
        # Description / Achievements switch, shown for games with an achievement list
        self.mode = "description"
        self.mode_bar = tk.Frame(left)
        self.mode_tabs = {}
        for mode, label in (("description", "Description"), ("achievements", "Achievements")):
            tab = tk.Label(self.mode_bar, text=label, cursor="hand2", font=("Segoe UI", 10, "bold"),
                           padx=0, pady=px(2))
            tab.pack(side="left", padx=(0, px(16)))
            tab.bind("<Button-1>", lambda e, m=mode: self.set_mode(m))
            self.mode_tabs[mode] = tab
        self.ach_model = None        # fn(record) -> achievements.build(...) result or None
        self.ach_request = None      # fn(record): refresh the list / fetch badges in the background
        self.on_mark = None          # fn(achievement id, action)
        self.show_badges = lambda: True
        self.is_target = lambda ach_id: False
        self.path = ""
        self.pad_focus = None        # None, "tabs" or "list" (controller)
        self.pad_ach_id = None
        self.model = None
        self.record = None
        self.rendered_for = None
        self.show_earned = False
        self.badge_photos = {}
        self.ach_rows = []
        self.render_job = None
        self.hovered = None
        # Shown when a game wasn't found: paste its RetroAchievements page to link it by hand
        self.on_link = None
        self.link_btn = tk.Button(left, text="🔗  Link to a RetroAchievements page…",
                                  command=lambda: self.on_link and self.on_link())
        # When the automatic search found several sets that fit about equally well
        self.on_choose = None
        self.choose_btn = tk.Button(left, command=lambda: self.on_choose and self.on_choose())
        text_frame = tk.Frame(left)
        self.text_frame = text_frame
        text_frame.pack(fill="both", expand=True, pady=(8, 0))
        self.text = tk.Text(text_frame, wrap="word", width=30, height=6, relief="flat",
                            bg=T["bg"], fg=T["text"], font=("Segoe UI", 10), cursor="arrow",
                            spacing2=2, highlightthickness=0, exportselection=False,
                            selectbackground=T["select_bg"], selectforeground=T["text"],
                            inactiveselectbackground=T["select_bg"])
        self.text.tag_configure("h", font=("Segoe UI", 11, "bold"), spacing1=4)
        scroll = scrollbar(text_frame, self.text.yview)
        self.body_scroll = scroll
        self.text.config(yscrollcommand=scroll.set, state="disabled")
        self.text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        # The achievement list's canvas takes the text's place when that tab is open
        self.ach_canvas = tk.Canvas(text_frame, bg=T["bg"], highlightthickness=0, bd=0,
                                    yscrollincrement=px(20))
        self.canvas_shown = False
        self.drawn_width = 0
        self.resize_job = None
        self.ach_y = 0
        c = self.ach_canvas
        c.bind("<Motion>", self.on_canvas_motion)
        c.bind("<Leave>", self.unhover)
        c.bind("<Button-3>", self.on_canvas_right_click)
        c.bind("<MouseWheel>", self.wheel)
        c.bind("<Configure>", self.on_canvas_resize)

        # Right column: box art + facts, a fixed width set by the art size
        right = tk.Frame(self, width=image_box())
        right.grid(row=0, column=1, sticky="ne")
        self.image = tk.Label(right, wraplength=image_box(), justify="left")
        self.image.pack(anchor="n", pady=(0, 10))
        self.facts = tk.Label(right, anchor="w", justify="left", fg=T["text_muted"], wraplength=image_box())
        self.facts.pack(fill="x")
        self.achievements = tk.Label(right, anchor="w", justify="left", font=("Segoe UI", 10, "bold"),
                                     wraplength=image_box())
        self.achievements.pack(fill="x", pady=(8, 0))
        # "● Mastered" / "○ Beaten" under the achievement line
        self.award_row = tk.Frame(right)
        size = px(14)
        self.award_icon = tk.Canvas(self.award_row, width=size, height=size, highlightthickness=0)
        self.award_icon.pack(side="left")
        self.award_text = tk.Label(self.award_row, font=("Segoe UI", 10, "bold"))
        self.award_text.pack(side="left", padx=(px(6), 0))
        # The achievement line links to the game's RetroAchievements page
        self.ra_link = None
        self.achievements.bind("<Button-1>", lambda e: self.open_ra_page())
        self.achievements.bind("<Enter>", lambda e: self.underline_link(True))
        self.achievements.bind("<Leave>", lambda e: self.underline_link(False))
        self.progress = tk.Canvas(right, width=image_box(), height=px(8), highlightthickness=0,
                                  bg=T["bg"])
        # "⚠ 3 missables open" / "◆ 2 to Beaten"
        self.miss_label = tk.Label(right, anchor="w", justify="left", font=("Segoe UI", 10, "bold"),
                                   wraplength=image_box())
        self.beaten_label = tk.Label(right, anchor="w", justify="left", fg=T["story"],
                                     font=("Segoe UI", 10), wraplength=image_box())
        self.fileinfo = tk.Label(right, anchor="w", justify="left", fg=T["text_faint"],
                                 font=("Segoe UI", 9), wraplength=image_box())
        self.fileinfo.pack(fill="x", pady=(12, 0))
        left.bind("<Configure>", self.on_resize)

    def on_resize(self, event):
        self.title.config(wraplength=max(150, event.width - 10))

    # ------------------------------------------------------------ achievements

    def set_mode(self, mode):
        if mode == self.mode:
            return
        self.mode = mode
        self.rendered_for = None
        if self.record is not None:
            self.show_body()

    def toggle_mode(self):
        self.set_mode("description" if self.mode == "achievements" else "achievements")

    def has_achievements(self, record):
        ra = (record or {}).get("ra") or {}
        return bool(record and record.get("ra_id") and (ra.get("num_achievements") or self.model))

    def draw_mode_bar(self, visible):
        if not visible:
            self.mode_bar.pack_forget()
            return
        self.mode_bar.pack(fill="x", pady=(px(4), 0), after=self.title)
        for mode, tab in self.mode_tabs.items():
            active = mode == self.mode
            focused = active and self.pad_focus == "tabs"
            tab.config(fg=T["tab_active"] if active else T["text_faint"],
                       bg=T["select_bg"] if focused else T["bg"], padx=px(6) if focused else 0,
                       font=("Segoe UI", 10, "bold underline" if active else "bold"))

    def show_summary(self):
        from .achievements import missable_note
        note = missable_note(self.model)
        color = T["missable_user"] if self.model and note and \
            self.model["user_missables_open"] == self.model["missables_open"] else T["missable"]
        # (The "◆ N to Beaten" line was removed by request; its label stays hidden.)
        for label, text in ((self.miss_label, note), (self.beaten_label, "")):
            if text:
                label.config(text=text, **({"fg": color} if label is self.miss_label else {}))
                label.pack(fill="x", pady=(px(6), 0), before=self.fileinfo)
            else:
                label.pack_forget()

    def badge_image(self, badge, locked):
        size = px(40)
        game_id = (self.record or {}).get("ra_id", "")
        key = (game_id, badge, locked, size)
        if key in self.badge_photos:
            return self.badge_photos[key]
        photo = load_badge(game_id, badge, locked, size) if self.show_badges() else None
        if photo is None:
            if not self.show_badges():
                return None
            photo = self.badge_photos.get(("", False, size))
            if photo is None:
                photo = tk.PhotoImage(width=size, height=size)     # keeps rows lined up
                self.badge_photos[("", False, size)] = photo
            return photo
        self.badge_photos[key] = photo
        return photo

    def show_body(self):
        """Description or achievement list, depending on the tab."""
        record = self.record
        if self.mode == "achievements" and self.has_achievements(record):
            if self.ach_request:
                self.ach_request(record)
            if self.model:
                # Drawn a moment later, so holding Down through the list doesn't build every game's
                if self.render_job:
                    self.after_cancel(self.render_job)
                same = self.rendered_for == record.get("ra_id")
                self.render_job = self.after(0 if same else 120, self.render_achievements)
            else:
                self.use_canvas(False)
                self.set_description("Loading achievements…" if self.ach_request else
                                     "No achievement list yet.")
        else:
            if self.render_job:
                self.after_cancel(self.render_job)
                self.render_job = None
            self.clear_rows()
            self.use_canvas(False)
            self.set_description(self.description_text(record))
        self.draw_mode_bar(self.has_achievements(record))

    # The achievement list is drawn on one canvas rather than built from widgets: scrolling a
    # canvas is a single repaint, so fast scrolling doesn't smear.

    def use_canvas(self, on):
        """Swap the description text for the achievement canvas (or back), sharing the scrollbar."""
        if on == self.canvas_shown:
            return
        self.canvas_shown = on
        show, hide = (self.ach_canvas, self.text) if on else (self.text, self.ach_canvas)
        hide.pack_forget()
        show.pack(side="left", fill="both", expand=True, before=self.body_scroll)
        self.body_scroll.config(command=show.yview)
        show.config(yscrollcommand=self.body_scroll.set)

    def scroll_widget(self):
        """What the right stick and mouse wheel should scroll."""
        return self.ach_canvas if self.canvas_shown else self.text

    def clear_rows(self):
        self.hovered = None
        self.ach_rows = []
        self.ach_canvas.delete("all")
        self.rendered_for = None

    def render_achievements(self):
        """The grouped list: missables still open, story, the rest, then (folded) what you've earned."""
        self.render_job = None
        if not self.model or self.mode != "achievements":
            return
        c = self.ach_canvas
        same_game = self.rendered_for == (self.record or {}).get("ra_id")
        top = c.yview()[0] if same_game and self.canvas_shown else 0
        self.use_canvas(True)
        self.clear_rows()
        self.drawn_width = c.winfo_width()
        groups = self.model["groups"]
        self.ach_y = px(2)
        sections = [("missable", "⚠  Missable — still open"), ("story", "◆  Story"),
                    ("remaining", "Remaining")]
        for key, heading in sections:
            items = groups[key]
            if not items:
                continue
            self.draw_heading(f"{heading}  ({len(items)})")
            for a in items:
                self.draw_row(a, key)
        if not any(groups[k] for k, _ in sections):
            self.draw_heading("🏆  Everything unlocked!")
        earned = groups["earned"]
        if earned:
            arrow = "▾" if self.show_earned else "▸"
            self.draw_heading(f"{arrow}  Earned  ({len(earned)})", toggle=True)
            if self.show_earned:
                for a in earned:
                    self.draw_row(a, "earned")
        c.config(scrollregion=(0, 0, max(1, self.drawn_width), self.ach_y + px(8)))
        self.rendered_for = (self.record or {}).get("ra_id")
        c.yview_moveto(top)
        self.refocus_after_render()

    def draw_heading(self, text, toggle=False):
        c = self.ach_canvas
        y = self.ach_y + (px(10) if self.ach_rows or self.ach_y > px(2) else 0)
        item = c.create_text(px(2), y, text=text, anchor="nw", font=("Segoe UI", 11, "bold"),
                             fill=T["text_muted"] if toggle else T["text"],
                             tags=("toggle",) if toggle else ())
        self.ach_y = c.bbox(item)[3] + px(4)
        if toggle:
            c.tag_bind("toggle", "<Button-1>", lambda e: self.toggle_earned())
            c.tag_bind("toggle", "<Enter>", lambda e: c.config(cursor="hand2"))
            c.tag_bind("toggle", "<Leave>", lambda e: c.config(cursor="arrow"))

    def draw_row(self, a, group=""):
        c = self.ach_canvas
        width = max(px(240), self.drawn_width)
        top = self.ach_y
        pad = px(5)
        locked = not a["is_earned"]
        badge = px(40)
        x = px(6)
        photo = self.badge_image(a["badge"], locked)
        if photo is not None:
            c.create_image(x, top + pad, image=photo, anchor="nw")
            x += badge + px(10)
        right = width - px(8)
        # Title line: title, points, then the tags; a tag that won't fit moves to its own line
        item = c.create_text(x, top + pad, text=a["title"], anchor="nw", width=right - x,
                             font=("Segoe UI", 10, "bold"), fill=T["text"])
        box = c.bbox(item)
        lx, line_top, bottom = box[2], box[1], box[3]
        pieces = [(f"  {a['points']} pts", T["text_faint"], ("Segoe UI", 9))]
        marks = []
        if self.is_target(a["id"]):
            marks.append(("🎯 Target", T["gold"]))
        marks += [{"ra": ("⚠ Missable", T["missable"]), "user": ("⚠ Missable (yours)", T["missable_user"]),
                   "ra_off": ("⚠ not missable (your call)", T["missable_off"])}.get(a["missable"])]
        marks += [{"win": ("🏁 Win condition", T["story"]), "ra": ("◆ Progression", T["story"]),
                   "user": ("◆ Progression (yours)", T["missable_user"])}.get(a["story"])]
        pieces += [("   " + text, color, ("Segoe UI", 9, "bold")) for text, color in filter(None, marks)]
        for text, color, font in pieces:
            item = c.create_text(lx, line_top + px(2), text=text, anchor="nw", font=font, fill=color)
            b = c.bbox(item)
            if b[2] > right and lx > x:               # wrap to a new line under the title
                c.coords(item, x, bottom)
                b = c.bbox(item)
                line_top = bottom - px(2)
            lx, bottom = b[2], max(bottom, b[3])
        y = bottom + px(2)
        if a["description"]:
            item = c.create_text(x, y, text=a["description"], anchor="nw", width=right - x,
                                 font=("Segoe UI", 10), fill=T["text_muted"] if locked else T["text_faint"])
            y = c.bbox(item)[3] + px(2)
        bits = []
        if a["rarity"]:
            pct = a["pct"]
            bits.append(f"{a['rarity']} · {pct:.1f}% of players" if pct < 10 else
                        f"{a['rarity']} · {pct:.0f}% of players")
        if a["earned_hardcore"]:
            bits.append(f"Earned {a['earned_hardcore']} (hardcore)")
        elif a["earned"]:
            bits.append(f"Earned {a['earned']} (casual)")
        if bits:
            item = c.create_text(x, y, text="   ·   ".join(bits), anchor="nw", width=right - x,
                                 font=("Segoe UI", 9), fill=T["gold"] if a["earned_hardcore"] else T["text_faint"])
            y = c.bbox(item)[3]
        row_bottom = max(y, top + pad + (badge if photo is not None else 0)) + pad
        # Background for the hover highlight, behind everything in the row
        rect = c.create_rectangle(0, top, width, row_bottom, fill=T["bg"], outline="")
        c.tag_lower(rect)
        self.ach_rows.append({"top": top, "bottom": row_bottom, "rect": rect, "a": a, "group": group})
        self.ach_y = row_bottom

    def row_at(self, event):
        y = self.ach_canvas.canvasy(event.y)
        for row in self.ach_rows:
            if row["top"] <= y < row["bottom"]:
                return row
        return None

    def on_canvas_motion(self, event):
        if self.pad_focus == "list":
            return                    # the controller's highlight stays put
        self.hover(self.row_at(event))

    def on_canvas_right_click(self, event):
        row = self.row_at(event)
        if row is not None:
            self.hover(row)
            self.achievement_menu(event, row["a"])
        return "break"

    def hover(self, row):
        """Light up the row under the mouse (and only that one)."""
        if self.hovered is row:
            return
        if self.hovered is not None:
            self.ach_canvas.itemconfig(self.hovered["rect"], fill=T["bg"])
        self.hovered = row
        if row is not None:
            self.ach_canvas.itemconfig(row["rect"], fill=T["row_hover"])

    def unhover(self, _event=None):
        if self.pad_focus != "list":
            self.hover(None)

    def wheel(self, event):
        self.scroll_widget().yview_scroll(int(-event.delta / 120) * 3, "units")
        return "break"

    def on_canvas_resize(self, event):
        """Re-wrap the list when its width changes (after the resize settles)."""
        if self.ach_rows and abs(event.width - self.drawn_width) > 2:
            if self.resize_job:
                self.after_cancel(self.resize_job)
            self.resize_job = self.after(80, self.rerender)

    def rerender(self):
        self.resize_job = None
        if self.canvas_shown and self.model:
            self.render_achievements()

    def toggle_earned(self):
        self.show_earned = not self.show_earned
        self.render_achievements()

    def achievement_menu(self, event, a):
        if self.on_mark:
            popup_menu(self.text, self.achievement_items(a), event.x_root, event.y_root)
        return "break"

    def achievement_items(self, a):
        """The menu for one achievement (right-click, or A / X with a controller)."""
        mark = lambda action: (lambda: self.on_mark(a["id"], action, self.record, a))
        miss = a["missable"]
        items = []
        if miss == "":
            items.append(("⚠  Mark as missable", mark("missable")))
        elif miss == "user":
            items.append(("Remove my missable mark", mark("clear_missable")))
        elif miss == "ra":
            items.append(("Not missable (hide RetroAchievements' tag)", mark("unmissable")))
        elif miss == "ra_off":
            items.append(("Restore RetroAchievements' missable tag", mark("clear_missable")))
        if a["story"] == "":
            items.append(("◆  Mark as progression", mark("progression")))
        elif a["story"] == "user":
            items.append(("Remove my progression mark", mark("clear_progression")))
        if self.is_target(a["id"]):
            items += [None, ("Clear target", mark("clear_target"))]
        else:
            items += [None, ("🎯  Mark as target", mark("target"))]
        items += [None, ("Open on RetroAchievements",
                         lambda: webbrowser.open(f"https://retroachievements.org/achievement/{a['id']}"))]
        return items

    # ------------------------------------------------------------ controller inside the panel
    # D-pad right from the game list focuses the Description | Achievements tabs; down moves into
    # the achievement rows. A or X opens a row's menu, LT/RT jump between groups, B or left goes
    # back to the game list.

    def can_focus(self):
        return self.record is not None and self.has_achievements(self.record)

    def enter_focus(self):
        if not self.can_focus():
            return False
        self.pad_focus = "tabs"
        self.draw_mode_bar(True)
        return True

    def leave_focus(self):
        self.pad_focus = None
        self.pad_ach_id = None
        self.hover(None)
        self.draw_mode_bar(self.has_achievements(self.record))

    def focus_row(self, index):
        if not self.ach_rows:
            return
        index = max(0, min(len(self.ach_rows) - 1, index))
        row = self.ach_rows[index]
        self.pad_focus = "list"
        self.pad_ach_id = row["a"]["id"]
        self.hover(row)
        self.draw_mode_bar(True)
        self.scroll_to_row(row)

    def focused_row_index(self):
        for i, row in enumerate(self.ach_rows):
            if row["a"]["id"] == self.pad_ach_id:
                return i
        return None

    def scroll_to_row(self, row):
        """Keep the focused row on screen, with a little room around it."""
        c = self.ach_canvas
        total = max(1, self.ach_y + px(8))
        view_h = max(1, c.winfo_height())
        first, last = (f * total for f in c.yview())
        margin = px(30)
        if row["top"] - margin < first:
            c.yview_moveto(max(0, row["top"] - margin) / total)
        elif row["bottom"] + margin > last:
            c.yview_moveto(max(0, row["bottom"] + margin - view_h) / total)

    def handle_pad(self, action, open_actions):
        """Returns False once focus goes back to the game list."""
        if action == "toggle_details":
            self.toggle_mode()
            if self.mode == "description" and self.pad_focus == "list":
                self.pad_focus = "tabs"
            self.draw_mode_bar(True)
            return True
        if self.pad_focus == "tabs":
            if action in ("back", "up") or (action == "left" and self.mode == "description"):
                self.leave_focus()
                return False
            if action in ("left", "right"):
                self.set_mode("description" if action == "left" else "achievements")
                self.draw_mode_bar(True)
            elif action in ("down", "select") and self.mode == "achievements":
                if self.render_job:                     # make sure the rows exist
                    self.after_cancel(self.render_job)
                    self.render_achievements()
                self.focus_row(0)
            return True
        # in the achievement rows
        i = self.focused_row_index()
        if i is None:
            self.pad_focus = "tabs"
            self.draw_mode_bar(True)
            return True
        if action in ("back", "left"):
            self.leave_focus()
            return False
        if action == "up":
            if i == 0:
                self.hover(None)
                self.pad_focus = "tabs"
                self.pad_ach_id = None
                self.ach_canvas.yview_moveto(0)
                self.draw_mode_bar(True)
            else:
                self.focus_row(i - 1)
        elif action == "down":
            self.focus_row(i + 1)
        elif action in ("page_up", "page_down"):
            starts = [j for j, row in enumerate(self.ach_rows)
                      if j == 0 or row["group"] != self.ach_rows[j - 1]["group"]]
            if action == "page_down":
                later = [j for j in starts if j > i]
                self.focus_row(later[0] if later else len(self.ach_rows) - 1)
            else:
                # The top of this group first, then the top of the one before
                earlier = [j for j in starts if j < i]
                self.focus_row(earlier[-1] if earlier else 0)
        elif action in ("select", "actions"):
            a = self.ach_rows[i]["a"]
            open_actions(a["title"], self.achievement_items(a))
        return True

    def refocus_after_render(self):
        """After a redraw (a mark changed, badges arrived), keep the same achievement focused."""
        if self.pad_focus != "list":
            return
        i = self.focused_row_index()
        if i is None:
            self.pad_focus = "tabs"
            self.draw_mode_bar(True)
        else:
            self.hover(self.ach_rows[i])


    def description_text(self, record):
        if record is None and not self.path:
            return ""                     # nothing selected (e.g. an empty Recently played list)
        if record is None:
            return ("No details yet. Use “Check for updates” on the Settings tab, "
                    "or right-click this game › Look up details.")
        if record.get("ra_candidates") and not record.get("ra_id") and record.get("status") != "matched":
            return ("This file's hash isn't one RetroAchievements knows, and a few sets have names "
                    "close to it. Choose the right one above, or paste its page address. "
                    "Common for hacks, translations and patched games.")
        if record.get("status") != "matched":
            if record.get("name_search_done"):
                return ("Not found by hash, or by name on RetroAchievements. This is common "
                        "for hacks, translations and homebrew, and for games without an "
                        "achievement set. Renaming the file to its official title and "
                        "choosing Look up details may help.")
            return ("This file's hash doesn't match a known dump (common for compressed "
                    "formats like .chd, .rvz or .7z, and for hacks or translations). "
                    "Add your RetroAchievements key in Settings and Check for updates "
                    "to search by name instead.")
        if record.get("description"):
            return record["description"]
        if record.get("match") == "manual":
            return ("Linked to its RetroAchievements page by you. No description was found "
                    "for any version of this game.")
        if record.get("match") == "name":
            return ("Matched by name on RetroAchievements, which doesn't provide game "
                    "descriptions. If this is the wrong game, rename the file to its "
                    "official title and choose Look up details, or right-click it › "
                    "Change RetroAchievements link.")
        return "No description available."

    def set_description(self, text):
        """Show a description, turning its markdown into plain formatted text."""
        self.text.config(state="normal")
        self.text.delete("1.0", "end")
        for chunk, tag in markdown_chunks(text):
            self.text.insert("end", chunk, tag or ())
        self.text.yview_moveto(0)
        self.text.config(state="disabled")

    def draw_progress(self, earned, earned_hardcore, total):
        """A thin bar: gold for hardcore unlocks, then white for casual (softcore) ones."""
        self.progress.delete("all")
        if not total:
            self.progress.pack_forget()
            return
        self.progress.pack(fill="x", pady=(6, 0), before=self.fileinfo)
        width, h = image_box(), px(8)
        self.progress.create_rectangle(0, 0, width, h, fill=T["progress_track"], width=0)
        self.progress.create_rectangle(0, 0, width * min(earned, total) / total, h,
                                       fill=T["progress_soft"], width=0)
        self.progress.create_rectangle(0, 0, width * min(earned_hardcore, total) / total, h,
                                       fill=T["progress_hard"], width=0)

    def show_file(self, path):
        if not path:
            self.fileinfo.config(text="")
            return
        lines = []
        region = region_of(path)
        if region:
            lines.append(f"Region: {region}")
        lines.append(os.path.basename(path))
        self.fileinfo.config(text="\n".join(lines))

    def set_link(self, ra_id):
        self.ra_link = ra_game_url(ra_id) if ra_id else None
        self.achievements.config(cursor="hand2" if self.ra_link else "")
        self.underline_link(False)

    def underline_link(self, hovering):
        underline = bool(self.ra_link) and hovering
        self.achievements.config(font=("Segoe UI", 10, "bold underline" if underline else "bold"))

    def open_ra_page(self):
        if self.ra_link:
            webbrowser.open(self.ra_link)

    def show_link_button(self, visible):
        candidates = (self.record or {}).get("ra_candidates") or []
        if visible and candidates and self.on_choose:
            n = len(candidates)
            self.choose_btn.config(text=f"🔎  Choose from {n} possible match{'es' if n != 1 else ''}…")
            self.choose_btn.pack(anchor="w", pady=(8, 0), before=self.text_frame)
        else:
            self.choose_btn.pack_forget()
        if visible and self.on_link:
            self.link_btn.pack(anchor="w", pady=(8, 0), before=self.text_frame)
        else:
            self.link_btn.pack_forget()

    def show(self, display_name, record, ra_ready, path=""):
        self.path = path
        if (record or {}).get("ra_id") != (self.record or {}).get("ra_id"):
            self.show_earned = False
        self.record = record
        self.model = self.ach_model(record) if (self.ach_model and record and record.get("ra_id")) else None
        self.show_summary()
        self.photo = None
        self.set_link((record or {}).get("ra_id"))
        # Offer a manual link for any scanned game that isn't tied to RetroAchievements yet
        self.show_link_button(record is not None and record.get("status") in ("nomatch", "matched")
                              and not record.get("ra_id"))
        self.image.config(image="", text="")
        self.draw_progress(0, 0, 0)
        self.award_row.pack_forget()
        self.show_file(path)
        if record is None or record.get("status") != "matched":
            self.title.config(text=display_name)
            self.facts.config(text="")
            self.achievements.config(text="")
            self.show_body()
            return

        ra = record.get("ra") or {}
        self.title.config(text=ra.get("title") or record.get("title") or display_name)
        year = (ra.get("released") or record.get("year") or "")[:4]
        lines = [" · ".join(x for x in (ra.get("console") or record.get("platform", ""), year) if x)]
        developer = ra.get("developer", "")
        publisher = ra.get("publisher") or record.get("publisher", "")
        if developer and publisher and developer != publisher:
            lines.append(f"{developer} / {publisher}")
        elif developer or publisher:
            lines.append(developer or publisher)
        if ra.get("genre"):
            lines.append(ra["genre"])
        self.facts.config(text="\n".join(l for l in lines if l))

        if ra:
            total = ra.get("num_achievements", 0)
            if total:
                self.achievements.config(
                    text=f"🏆  {ra.get('earned', 0)} / {total} achievements"
                         f"   (hardcore {ra.get('earned_hardcore', 0)})", fg=T["gold"])
                self.draw_progress(ra.get("earned", 0), ra.get("earned_hardcore", 0), total)
                kind = ra.get("award", "")
                if kind in AWARDS:
                    draw_award(self.award_icon, kind, px(14), self.cget("bg"))
                    self.award_text.config(text=AWARDS[kind][0],
                                           fg=T["gold"] if AWARDS[kind][1] == "#e5b143" else T["text_muted"])
                    self.award_row.pack(fill="x", pady=(px(6), 0), before=self.fileinfo)
            else:
                self.achievements.config(text="No achievement set yet", fg=T["text_faint"])
        elif record.get("ra_id") and not ra_ready:
            self.achievements.config(text="Has achievements · add your RetroAchievements key in Settings",
                                     fg=T["text_faint"])
        elif record.get("ra_id"):
            self.achievements.config(text="Has achievements · right-click › Look up details to refresh",
                                     fg=T["text_faint"])
        else:
            self.achievements.config(text="")

        self.show_body()
        photo = load_photo(record.get("image", ""))
        if photo is not None:
            self.photo = photo
            self.image.config(image=photo)
        elif record.get("image"):
            self.image.config(text="(Install Pillow to show this image: pip install pillow)", fg=T["text_faint"])


class GameListView(tk.Frame):
    """Optional Back button + title, search box, game list with a details panel, and Launch button.

    Entries are (display_name, rom_path, system_id). The list can show a small system icon
    at the start of each row (icon_for returns a PhotoImage or None)."""

    def __init__(self, master, back, launch, menu_items, details=None,
                 sort_options=(), sorter=None, sort_id="name", on_sort=None, icon_for=None,
                 empty_text="No games here", link=None):
        super().__init__(master, padx=8, pady=8)
        self.sort_options = list(sort_options)   # [(id, label)]
        self.sorter = sorter                     # fn(entries, sort_id) -> [(index, suffix)]
        self.sort_id = sort_id if sort_id in dict(self.sort_options) else (
            self.sort_options[0][0] if self.sort_options else "name")
        self.on_sort = on_sort                   # fn(sort_id), to remember the choice
        self.launch_cb = launch
        self.menu_items = menu_items      # fn(entry_index) -> list of (label, fn) or None separators
        self.details_cb = details         # fn(entry) -> (record or None, ra_ready)
        self.icon_for = icon_for          # fn(entry) -> PhotoImage or None
        self.back_cb = back               # None on top-level pages (Home)
        self.empty_text = empty_text
        self.entries = []
        self.visible = []                 # indexes into self.entries, in display order

        # Page bar: Back + title on the left, search across the middle, Sort on the right
        header = tk.Frame(self)
        header.pack(fill="x")
        self.header = header
        # Space under the page bar for extras (the Home tab's reminder carousel); empty = no height
        self.extra = tk.Frame(self)
        self.extra.pack(fill="x")
        if back is not None:
            tk.Button(header, text="◀  Back", command=back).pack(side="left", padx=(0, 12))
        self.title = tk.Label(header, font=("Segoe UI", 14, "bold"))
        self.title.pack(side="left", padx=(0, 20))
        self.sort_btn = tk.Button(header, command=self.sort_popup)
        if self.sort_options:
            self.sort_btn.pack(side="right", padx=(12, 0))
        self.update_sort_button()
        tk.Label(header, text="🔍", font=("Segoe UI", 11)).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_hook = None           # fn(term) run before the list redraws (Home swaps lists)
        self.after_search = None          # fn() run after it redraws (e.g. to update a match count)
        self.search_var.trace_add("write", lambda *a: self.search_changed())
        self.search_entry = tk.Entry(header, textvariable=self.search_var, font=("Segoe UI", 11))
        self.search_entry.pack(side="left", fill="x", expand=True, padx=(4, 0), ipady=3)

        # opaqueresize off: dragging the divider shows a line and the panes resize once on
        # release, so the details panel doesn't shuffle around while you drag
        panes = tk.PanedWindow(self, orient="horizontal", sashwidth=6, opaqueresize=False)
        panes.pack(fill="both", expand=True, pady=(6, 0))
        frame = tk.Frame(panes)
        # Launch sits under the list, exactly as wide as it. Packed first at the bottom
        # so the list can never squeeze it.
        self.launch_btn = tk.Button(frame, text="LAUNCH", font=BIG_BUTTON_FONT,
                                    bg="#1f5fbf", fg="white", activebackground="#174a96",
                                    activeforeground="white", command=self.launch_selected)
        self.launch_btn.pack(side="bottom", fill="x", pady=(6, 0))
        # One bordered box around the list and its scrollbar, so they read as one piece
        list_frame = tk.Frame(frame, highlightthickness=1, highlightbackground=T["border"],
                              highlightcolor=T["border"], bd=0, bg=T["field"])
        list_frame.pack(side="top", fill="both", expand=True)

        self.row_height = list_row_height()
        style = ttk.Style(self)
        style.configure("Games.Treeview", font=("Segoe UI", 11), rowheight=self.row_height,
                        borderwidth=0, indent=0)
        style.configure("Games.Treeview", padding=0)
        # No dotted focus box around the selected row
        style.layout("Games.Treeview.Item", [("Treeitem.padding", {"sticky": "nswe", "children": [
            ("Treeitem.image", {"side": "left", "sticky": ""}),
            ("Treeitem.text", {"side": "left", "sticky": ""})]})])
        self.tree = ttk.Treeview(list_frame, style="Games.Treeview", show="tree",
                                 selectmode="browse", columns=("info",), takefocus=True)
        self.tree.column("#0", stretch=True, minwidth=px(120))
        self.tree.column("info", stretch=False, width=0, minwidth=0, anchor="e")
        scroll = scrollbar(list_frame, self.tree.yview)
        def on_scroll(first, last):
            scroll.set(first, last)
            self.after_idle(self.place_awards)
        self.tree.config(yscrollcommand=on_scroll)
        self.award_for = None             # fn(entry) -> award kind, for the circles beside 35/35
        self.award_marks = []
        self._list_font = None
        self.show_system_names = lambda: True
        self.game_running = lambda: False
        self.list_dimmed = False
        self.status_hint = None
        self.tree.bind("<Configure>", lambda e: self.after_idle(self.place_awards), add="+")
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.listbox = self.tree          # older code focuses .listbox
        self.panel = DetailsPanel(panes)
        if link is not None:
            self.panel.on_link = lambda: self.selected_index() is not None and link(
                self.entries[self.selected_index()])
        panes.add(frame, minsize=240, stretch="always")
        panes.add(self.panel, minsize=image_box() + 280, stretch="always")

        self.tree.bind("<<TreeviewSelect>>", lambda e: (self.update_details(), self.place_awards()))
        self.tree.bind("<Double-Button-1>", self.on_double_click)
        self.tree.bind("<Return>", lambda e: self.launch_selected())
        self.tree.bind("<Button-3>", self.popup)
        if back is not None:
            for w in (self.tree, self.search_entry):
                w.bind("<Escape>", lambda e: back())
            self.tree.bind("<BackSpace>", lambda e: back())
        self.search_entry.bind("<Down>", lambda e: self.focus_list())

    def show(self, title, entries, keep_search=False):
        self.title.config(text=title)
        self.entries = entries
        if not keep_search:
            self.search_var.set("")      # triggers refresh
        self.refresh()

    def focus_list(self):
        self.tree.focus_set()
        sel = self.tree.selection()
        if sel:
            self.tree.focus(sel[0])

    # ----- sorting

    def update_sort_button(self):
        label = dict(self.sort_options).get(self.sort_id, "Name")
        self.sort_btn.config(text=f"Sort: {label}  ▾")

    def set_sort(self, sort_id):
        self.sort_id = sort_id
        self.update_sort_button()
        if self.on_sort:
            self.on_sort(sort_id)
        self.refresh()

    def sort_menu_items(self):
        return [(("✓  " if sid == self.sort_id else "     ") + label,
                 lambda sid=sid: self.set_sort(sid)) for sid, label in self.sort_options]

    def sort_popup(self):
        menu = tk.Menu(self.sort_btn, tearoff=False)
        for label, fn in self.sort_menu_items():
            menu.add_command(label=label, command=fn)
        menu.tk_popup(self.sort_btn.winfo_rootx(),
                      self.sort_btn.winfo_rooty() + self.sort_btn.winfo_height())

    # ----- rows

    def search_changed(self):
        if self.search_hook:
            self.search_hook(self.search_var.get().strip())
        self.refresh()
        if self.after_search:
            self.after_search()

    def refresh(self):
        term = self.search_var.get().lower().strip()
        selected = self.selected_index()
        if self.sorter:
            ordered = self.sorter(self.entries, self.sort_id)
        else:
            ordered = [(i, "") for i in range(len(self.entries))]
        ordered = [(i, suffix) for i, suffix in ordered if term in self.entries[i][0].lower()]
        self.visible = [i for i, _ in ordered]
        self.tree.delete(*self.tree.get_children())
        awards = self.showing_awards()
        measure = self.measure_text
        # Labels sit at the right of the row; with award circles, trailing spaces leave room for them
        pad = " " * (-(-px(24) // max(1, measure(" "))) if awards else 1)
        ordered = [(i, suffix + pad if suffix else "") for i, suffix in ordered]
        longest = ""
        for i, suffix in ordered:
            image = self.icon_for(self.entries[i]) if self.icon_for else None
            # A thin space after the icon keeps text from touching it
            self.tree.insert("", "end", iid=str(i), text=("  " if image else " ") + self.list_text(i),
                             image=image or "", values=(suffix,))
            longest = max(longest, suffix, key=len)
        widest = max((measure(s) for _i, s in ordered if s), default=0)
        self.tree.column("info", width=widest + px(12) if longest else 0)
        if self.visible:
            index = selected if selected in self.visible else self.visible[0]
            self.select_row(index)
        self.update_details()
        self.after_idle(self.place_awards)

    def list_text(self, i):
        """A game's name as listed: '[System]' after it can be turned off in Settings."""
        name = self.entries[i][0]
        if not self.show_system_names():
            name = name.split("    [", 1)[0]
        return name

    def measure_text(self, text):
        """Pixel width of text in the list's font, so the sort column is only as wide as it
        needs to be and game names keep the rest."""
        if self._list_font is None:
            try:
                self._list_font = tkfont.Font(font=("Segoe UI", 11))
            except Exception:
                self._list_font = False
        if not self._list_font:
            return len(text) * px(8)
        return self._list_font.measure(text)

    def showing_awards(self):
        """Award circles appear when the list is sorted by achievements."""
        return self.award_for is not None and self.sort_id in ("progress", "achievements")

    def place_awards(self):
        """Draw award circles at the right of the visible rows' 35/35 counts.

        The list's text columns can't hold pictures, so small circles are laid over it."""
        for mark in self.award_marks:
            mark.destroy()
        self.award_marks = []
        if not self.showing_awards() or not self.visible:
            return
        size = px(14)
        selected = set(self.tree.selection())
        first = self.tree.identify_row(2)
        if not first:
            return
        rows = self.tree.get_children()
        start = rows.index(first) if first in rows else 0
        count = self.tree.winfo_height() // max(1, self.row_height) + 2
        for iid in rows[start:start + count]:
            box = self.tree.bbox(iid, "info")
            if not box:
                continue
            kind = self.award_for(self.entries[int(iid)])
            if kind not in AWARDS:
                continue
            x, y, w, h = box
            bg = (T["select_dim" if self.list_dimmed else "select_bg"] or "#0078d7") \
                if iid in selected else T["field"]
            mark = tk.Canvas(self.tree.master, width=size, height=size, highlightthickness=0, bd=0)
            draw_award(mark, kind, size, bg)
            mark.place(in_=self.tree, x=x + w - size - px(6), y=y + (h - size) // 2)
            # Clicking a circle acts like clicking its row
            mark.bind("<Button-1>", lambda e, i=int(iid): self.select_index(i))
            mark.bind("<Double-Button-1>", lambda e: self.launch_selected())
            mark.bind("<Button-3>", lambda e, i=int(iid): (
                self.select_index(i), popup_menu(self.tree, self.menu_items(i), e.x_root, e.y_root), "break")[2])
            self.award_marks.append(mark)

    def refresh_icons(self):
        """Redraw row icons (after they finish downloading) without disturbing the list."""
        if not self.icon_for:
            return
        for i in self.visible:
            image = self.icon_for(self.entries[i])
            self.tree.item(str(i), image=image or "",
                           text=("  " if image else " ") + self.list_text(i))

    def select_row(self, index):
        iid = str(index)
        self.tree.selection_set(iid)
        self.tree.focus(iid)
        self.tree.see(iid)

    def update_details(self):
        index = self.selected_index()
        if index is None:
            self.panel.show(self.empty_text if not self.entries else "", None, False)
            self.launch_btn.config(text="LAUNCH")
            self.update_launch_state()
            return
        entry = self.entries[index]
        record, ra_ready = self.details_cb(entry) if self.details_cb else (None, False)
        self.panel.show(entry[0], record, ra_ready, entry[1])
        self.launch_btn.config(text="LAUNCH")
        self.update_launch_state()

    def update_launch_state(self):
        """Gray the Launch button out whenever pressing it wouldn't start anything:
        no game selected, or a game is already running."""
        ok = self.selected_index() is not None and not self.game_running()
        if ok:
            self.launch_btn.config(state="normal", bg="#1f5fbf", fg="white", cursor="hand2")
        else:
            self.launch_btn.config(state="disabled", bg=T["surface"], disabledforeground=T["text_faint"],
                                   cursor="arrow")

    def at_top(self):
        """True when the highlighted game is the first one (or the list is empty)."""
        return not self.visible or self.selected_index() in (None, self.visible[0])

    def selected_index(self):
        sel = self.tree.selection()
        if not sel:
            return None
        try:
            index = int(sel[0])
        except ValueError:
            return None
        return index if index in self.visible else None

    def select_index(self, index):
        if index in self.visible:
            self.select_row(index)
            self.update_details()

    def launch_selected(self):
        index = self.selected_index()
        if index is not None:
            self.launch_cb(self.entries[index])

    def on_double_click(self, event):
        if self.tree.identify_row(event.y):
            self.launch_selected()

    def handle_pad(self, action, open_actions):
        panel = self.panel
        if panel.pad_focus is not None:
            if not panel.handle_pad(action, open_actions):
                self.dim_selection(False)
                self.set_status_hint("")
            return
        if action == "right" and panel.enter_focus():
            self.dim_selection(True)
            self.set_status_hint("Details  |  ←/→: Description / Achievements  ·  ↓: into the list  ·  "
                                 "A: mark  ·  LT/RT: next group  ·  B: back to games")
            return
        if action == "toggle_details":
            if panel.can_focus():
                panel.toggle_mode()
            return
        if action == "back":
            if self.back_cb:
                self.back_cb()
            return
        if not self.visible:
            return
        index = self.selected_index()
        pos = self.visible.index(index) if index is not None else 0
        page = max(1, self.tree.winfo_height() // max(1, self.row_height) - 1)
        step = {"up": -1, "down": 1, "page_up": -page, "page_down": page}.get(action)
        if step is not None:
            pos = max(0, min(len(self.visible) - 1, pos + step))
            self.select_row(self.visible[pos])
            self.update_details()
        elif action == "select":
            self.launch_selected()
        elif action == "actions":
            index = self.selected_index()
            if index is not None:
                items = self.menu_items(index)
                if self.sort_options:
                    items = items + [None, ("Sort by…",
                                            lambda: open_actions("Sort by", self.sort_menu_items()))]
                open_actions(self.entries[index][0], items)

    def dim_selection(self, dim):
        """While the controller is in the details panel, the list's selection fades a little."""
        self.list_dimmed = dim
        ttk.Style(self).map("Games.Treeview", background=[("selected", T["select_dim" if dim else "select_bg"])])
        self.place_awards()

    def set_status_hint(self, text):
        if self.status_hint:
            self.status_hint(text)

    def popup(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        index = int(iid)
        self.select_row(index)
        self.update_details()
        popup_menu(self.tree, self.menu_items(index), event.x_root, event.y_root)
        return "break"      # a right-click on a game opens its menu; it shouldn't also go back


def popup_menu(master, items, x, y):
    """Show a right-click menu. items: (label, fn), (label, [sub-items]) or None for a separator."""
    def build(parent, entries):
        menu = tk.Menu(parent, tearoff=False)
        for item in entries:
            if item is None:
                menu.add_separator()
            elif isinstance(item[1], list):
                menu.add_cascade(label=item[0], menu=build(menu, item[1]))
            else:
                menu.add_command(label=item[0], command=item[1])
        return menu
    build(master, items).tk_popup(x, y)


# ---------------------------------------------------------------- reminder carousel

class ReminderStrip(tk.Frame):
    """A sliding row of reminder cards: click and drag (or flick) sideways to scroll.

    A click without dragging marks a reminder done; the mouse wheel also scrolls.
    on_toggle(reminder)            click / A: mark done or undo
    on_menu(reminder, x, y)        right-click: the reminder's menu (x, y = screen position)"""

    GAP = 8
    DRAG_THRESHOLD = 6        # pixels of movement before a press counts as a drag
    FRICTION = 0.92           # how quickly a flick slows down (per frame)

    def __init__(self, master, on_toggle, on_menu):
        super().__init__(master)
        self.on_toggle = on_toggle
        self.on_menu = on_menu
        self.items = []            # [(reminder, describe-line, state)] in display order
        self.focus = None          # index into items while the controller is in the strip
        self.cards = []
        self.drag = None
        self.velocity = 0.0
        self.coast_job = None
        self.canvas = tk.Canvas(self, height=self.card_height() + px(4), highlightthickness=0,
                                bg=T["bg"], xscrollincrement=1)
        self.canvas.pack(fill="x")
        self.row = tk.Frame(self.canvas, bg=T["bg"])
        self.canvas.create_window((0, 0), window=self.row, anchor="nw")
        self.row.bind("<Configure>", lambda e: self.canvas.config(
            scrollregion=(0, 0, self.row.winfo_reqwidth(), self.card_height() + px(4))))
        # Dragging on empty space between cards works too
        for w in (self.canvas, self.row):
            w.bind("<ButtonPress-1>", lambda e: self.press(e, None))
            w.bind("<B1-Motion>", self.motion)
            w.bind("<ButtonRelease-1>", lambda e: self.release(e, None))

    @staticmethod
    def card_width():
        return px(230)

    @staticmethod
    def card_height():
        return px(62)

    # ----- content

    def set_items(self, items):
        self.items = items
        if self.focus is not None:
            self.focus = min(self.focus, len(items) - 1) if items else None
        self.draw()

    def draw(self):
        left = self.left()
        for card in self.cards:
            card.destroy()
        self.cards = []
        for index, (reminder, line, state) in enumerate(self.items):
            card = self.make_card(reminder, line, state, index)
            card.pack(side="left", padx=(0, self.GAP), pady=px(2))
            self.cards.append(card)
        self.update_idletasks()
        self.scroll_to(left)          # keep the strip where it was

    def make_card(self, reminder, line, state, index):
        from . import reminders as R
        done, due = state == "done", state == "due"
        bg = T["surface"]
        accent = "#9a9a9a" if done else "#e0563b" if due else (
            "#2fa39a" if reminder.get("repeat") in ("daily", "weekly") else T["accent"])
        focused = self.focus == index
        card = tk.Frame(self.row, bg=bg, width=self.card_width(), height=self.card_height(),
                        cursor="hand2", highlightthickness=px(2) if focused else 1,
                        highlightbackground=T["accent"] if focused else T["border"])
        card.pack_propagate(False)
        tk.Frame(card, bg=accent, width=px(5)).pack(side="left", fill="y")
        body = tk.Frame(card, bg=bg)
        body.pack(side="left", fill="both", expand=True, padx=(px(8), px(6)), pady=px(4))
        text_fg = T["text_faint"] if done else T["text"]
        font = ("Segoe UI", 10, "overstrike") if done else ("Segoe UI", 10, "bold")
        title = tk.Label(body, text=f"{R.icon(reminder)}  {reminder.get('text', '')}", bg=bg,
                         fg=text_fg, font=font, anchor="w", justify="left",
                         wraplength=self.card_width() - px(30))
        title.pack(fill="x")
        sub = tk.Label(body, text=line, bg=bg, anchor="w", font=("Segoe UI", 9),
                       fg="#e0563b" if due else T["text_faint"])
        sub.pack(fill="x", side="bottom")
        parts = (card, body, title, sub)
        for w in parts:
            w.bind("<ButtonPress-1>", lambda e, r=reminder: self.press(e, r))
            w.bind("<B1-Motion>", self.motion)
            w.bind("<ButtonRelease-1>", lambda e, r=reminder: self.release(e, r))
            w.bind("<Button-3>", lambda e, r=reminder: (self.on_menu(r, e.x_root, e.y_root), "break")[1])
            w.bind("<Enter>", lambda e: [x.config(bg=T["surface_hover"]) for x in parts])
            w.bind("<Leave>", lambda e: [x.config(bg=bg) for x in parts])
        return card

    # ----- scrolling

    def left(self):
        """How far the strip is scrolled, in pixels."""
        return self.canvas.canvasx(0)

    def max_left(self):
        return max(0, self.row.winfo_reqwidth() - self.canvas.winfo_width())

    def scroll_to(self, left):
        total = self.row.winfo_reqwidth()
        left = max(0, min(left, self.max_left()))
        if total > 0:
            self.canvas.xview_moveto(left / total)
        return left

    def press(self, event, reminder):
        self.stop_coasting()
        self.drag = {"x": event.x_root, "left": self.left(), "moved": False,
                     "samples": [(time.monotonic(), event.x_root)]}

    def motion(self, event):
        d = self.drag
        if d is None:
            return
        dx = event.x_root - d["x"]
        if not d["moved"] and abs(dx) < self.DRAG_THRESHOLD:
            return
        if not d["moved"]:
            d["moved"] = True
            self.canvas.config(cursor="sb_h_double_arrow")
        self.scroll_to(d["left"] - dx)
        now = time.monotonic()
        d["samples"] = [s for s in d["samples"] if now - s[0] < 0.1] + [(now, event.x_root)]

    def release(self, event, reminder):
        d, self.drag = self.drag, None
        self.canvas.config(cursor="")
        if d is None:
            return
        if not d["moved"]:
            if reminder is not None:
                self.on_toggle(reminder)          # a plain click
            return
        # Flick: keep sliding at the release speed, slowing down
        samples = d["samples"]
        if len(samples) >= 2 and samples[-1][0] > samples[0][0]:
            self.velocity = -(samples[-1][1] - samples[0][1]) / (samples[-1][0] - samples[0][0])
            if abs(self.velocity) > 200:
                self.coast()

    def coast(self):
        left = self.left()
        new_left = self.scroll_to(left + self.velocity * 0.016)
        self.velocity *= self.FRICTION
        if abs(self.velocity) < 30 or new_left in (0, self.max_left()):
            self.coast_job = None
            return
        self.coast_job = self.after(16, self.coast)

    def stop_coasting(self):
        if self.coast_job is not None:
            self.after_cancel(self.coast_job)
            self.coast_job = None

    def handle_wheel(self, event):
        """Mouse wheel over the strip scrolls it sideways. Returns True if it did."""
        if not self.winfo_ismapped():
            return False
        widget = self.winfo_containing(event.x_root, event.y_root)
        while widget is not None:
            if widget is self:
                self.stop_coasting()
                self.scroll_to(self.left() - event.delta)
                return True
            widget = widget.master
        return False

    def ensure_visible(self, index):
        if index is None or not (0 <= index < len(self.cards)):
            return
        self.update_idletasks()
        card = self.cards[index]
        x, w = card.winfo_x(), card.winfo_width() or self.card_width()
        left, view = self.left(), self.canvas.winfo_width()
        if x < left:
            self.scroll_to(x - self.GAP)
        elif x + w > left + view:
            self.scroll_to(x + w + self.GAP - view)

    # ----- controller

    def enter(self):
        """Controller moved up into the strip: start on the first card in view."""
        if not self.items:
            return False
        left = self.left()
        self.focus = next((i for i, c in enumerate(self.cards) if c.winfo_x() >= left - 1), 0)
        self.draw()
        self.ensure_visible(self.focus)
        return True

    def leave(self):
        self.focus = None
        self.draw()

    def move(self, step):
        if self.focus is None or not self.items:
            return
        self.focus = max(0, min(len(self.items) - 1, self.focus + step))
        self.draw()
        self.ensure_visible(self.focus)

    def focused(self):
        if self.focus is None or not self.items:
            return None
        return self.items[self.focus][0]
