"""Dialogs: add/edit a system, pick a series, and the controller-friendly action picker."""

import os
import tkinter as tk
from tkinter import filedialog, ttk

from . import theme
from .theme import T, px, scrollbar
from .emulators import (EMULATORS, TYPE_BY_LABEL, core_extensions, detect_config,
                        detect_type, list_cores, read_core_info)

class FolderDialog(tk.Toplevel):
    """Add or edit a system: ROM folder, emulator, core, settings file, extensions."""

    def __init__(self, parent, default_exe, entry=None):
        super().__init__(parent)
        self.title("Edit system" if entry else "Add system")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.result = None
        entry_data = entry or {}

        # Values we filled in automatically, so manual edits are never overwritten
        self.auto_exts = None
        self.auto_config = None

        # Layout: three sections (Game, Emulator, Options) on one grid, so every label, field
        # and button lines up across the whole dialog:
        #   column 0 labels (left-aligned) | column 1 fields (all the same width) | column 2 buttons
        body = tk.Frame(self, padx=px(22), pady=px(14))
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, minsize=px(150))
        body.columnconfigure(1, weight=1, minsize=px(430))
        body.columnconfigure(2, minsize=px(104))
        self.row = 0
        field_pad = {"pady": px(4)}

        def section(title, first=False):
            head = tk.Frame(body)
            head.grid(row=self.row, column=0, columnspan=3, sticky="ew",
                      pady=(0 if first else px(16), px(6)))
            tk.Label(head, text=title, font=("Segoe UI", 10, "bold"), fg=T["text_muted"]).pack(side="left")
            ttk.Separator(head).pack(side="left", fill="x", expand=True, padx=(px(10), 0), pady=(px(2), 0))
            self.row += 1

        def label(text):
            tk.Label(body, text=text, anchor="w").grid(row=self.row, column=0, sticky="w",
                                                      padx=(0, px(12)), **field_pad)

        def entry(var, **kw):
            e = tk.Entry(body, textvariable=var, font=("Segoe UI", 10), **kw)
            e.grid(row=self.row, column=1, sticky="ew", ipady=px(3), **field_pad)
            return e

        def button(text, command):
            b = tk.Button(body, text=text, command=command)
            b.grid(row=self.row, column=2, sticky="nsew", padx=(px(8), 0), **field_pad)
            return b

        def hint():
            lbl = tk.Label(body, fg=T["text_faint"], anchor="w", justify="left",
                           font=("Segoe UI", 9), wraplength=px(530))
            lbl.grid(row=self.row, column=1, columnspan=2, sticky="w", pady=(0, px(4)))
            self.row += 1
            return lbl

        # ----- Game
        section("Game", first=True)
        label("Name")
        self.name_var = tk.StringVar(value=entry_data.get("name", ""))
        entry(self.name_var)
        self.row += 1

        label("ROM folder")
        self.path_var = tk.StringVar(value=entry_data.get("path", ""))
        entry(self.path_var)
        button("Browse…", self.browse_folder)
        self.row += 1

        # ----- Emulator
        section("Emulator")
        label("Emulator .exe")
        self.exe_var = tk.StringVar(value=entry_data.get("emulator_exe", default_exe))
        exe_entry = entry(self.exe_var)
        exe_entry.bind("<FocusOut>", lambda e: self.on_emulator_changed())
        button("Browse…", self.browse_exe)
        self.row += 1

        label("Emulator type")
        start_type = entry_data.get("emulator_type") or detect_type(self.exe_var.get())
        self.type_var = tk.StringVar(value=EMULATORS[start_type]["label"])
        type_box = ttk.Combobox(body, textvariable=self.type_var, state="readonly",
                                values=[v["label"] for v in EMULATORS.values()], font=("Segoe UI", 10))
        type_box.grid(row=self.row, column=1, sticky="ew", ipady=px(2), **field_pad)
        type_box.bind("<<ComboboxSelected>>", lambda e: self.on_type_changed())
        self.row += 1

        label("Core")
        self.core_var = tk.StringVar(value=entry_data.get("core", ""))
        self.core_box = ttk.Combobox(body, textvariable=self.core_var, font=("Segoe UI", 10))
        self.core_box.grid(row=self.row, column=1, sticky="ew", ipady=px(2), **field_pad)
        self.core_box.bind("<<ComboboxSelected>>", lambda e: self.on_core_changed())
        self.core_box.bind("<FocusOut>", lambda e: self.on_core_changed())
        self.row += 1
        self.core_info_label = hint()

        label("Hardcore setting file")
        self.config_var = tk.StringVar(value=entry_data.get("config_file", ""))
        # Greyed out (not white) when the emulator doesn't use a settings file
        self.config_entry = entry(self.config_var, disabledbackground=T["bg"],
                                  disabledforeground=T["text_faint"])
        self.config_btn = button("Browse…", self.browse_config)
        self.row += 1
        self.config_hint = hint()

        # ----- Options
        section("Options")
        label("Extensions")
        self.ext_var = tk.StringVar(value=", ".join(entry_data.get("extensions", [])))
        entry(self.ext_var)
        button("Reset", lambda: self.fill_extensions(force=True))
        self.row += 1
        hint().config(text="Filled in for the emulator or core. Edit freely; blank = all game-like files.")

        label("Extra arguments")
        self.args_var = tk.StringVar(value=entry_data.get("extra_args", ""))
        entry(self.args_var)
        self.row += 1
        self.args_hint = hint()

        # ----- OK / Cancel, bottom right like the other dialogs
        ttk.Separator(self).pack(fill="x")
        footer = tk.Frame(self, padx=px(22), pady=px(12))
        footer.pack(fill="x")
        tk.Button(footer, text="Cancel", width=10, command=self.destroy).pack(side="right", padx=(px(8), 0))
        tk.Button(footer, text="OK", width=10, bg=T["accent"], fg="white", activebackground=T["accent"],
                  activeforeground="white", command=self.ok).pack(side="right")
        self.bind("<Escape>", lambda e: self.destroy())

        # Treat existing values as automatic only when creating a new system
        self.refresh_for_type(initial=True, editing=bool(entry_data))
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_reqwidth()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_reqheight()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.wait_window()

    # ----- helpers

    def emu_type(self):
        return TYPE_BY_LABEL.get(self.type_var.get(), "other")

    def refresh_for_type(self, initial=False, editing=False):
        emu = self.emu_type()
        exe = self.exe_var.get().strip()

        # Core row: RetroArch only
        if emu == "retroarch":
            cores = list_cores(exe) if exe else []
            self.core_box.config(values=cores, state="normal")
            if not cores:
                self.core_info_label.config(
                    text="No cores found next to this retroarch.exe.", fg=T["warning"])
            else:
                self.show_core_info()
        else:
            self.core_box.config(values=[], state="disabled")
            self.core_info_label.config(text="Cores apply to RetroArch only.", fg=T["text_faint"])

        # Settings file row: standalone emulators with a known hardcore key
        hardcore = EMULATORS[emu]["hardcore"]
        if hardcore:
            self.config_entry.config(state="normal")
            self.config_btn.config(state="normal")
            current = self.config_var.get().strip()
            if not current or current == self.auto_config or (initial and not editing):
                found = detect_config(emu, exe) if exe else ""
                self.auto_config = found
                self.config_var.set(found)
            section, key, _, _ = hardcore
            where = f"“{key}”" if section == "json" else f"[{section}] {key}"
            if self.config_var.get().strip():
                self.config_hint.config(
                    text=f"The launcher sets {where} here before each launch.", fg=T["text_faint"])
            else:
                self.config_hint.config(
                    text=f"Settings file not found. Run {EMULATORS[emu]['label']} once, "
                         "or browse to it.", fg=T["warning"])
        else:
            self.config_entry.config(state="disabled")
            self.config_btn.config(state="disabled")
            if emu == "retroarch":
                self.config_hint.config(text="RetroArch gets the setting on its command line.", fg=T["text_faint"])
            else:
                self.config_hint.config(
                    text="The hardcore toggle can't be applied to this emulator automatically.",
                    fg=T["warning"])

        # Default arguments the launcher always adds, for reference
        builtin = {
            "retroarch": '-L <core> --appendconfig <override> "<rom>"',
            "duckstation": '-batch -- "<rom>"',
            "pcsx2": '-batch -- "<rom>"',
            "dolphin": '-b -e "<rom>"',
            "ppsspp": '"<rom>"',
            "rapplewin": '-d1 "<rom>"   (-h1 for .hdv hard disks)',
            "other": '"<rom>"',
        }.get(emu, '"<rom>"')            # the RA standalones just take the game path
        self.args_hint.config(
            text=f"Added before: {builtin}   (e.g. -fullscreen). "
                 "Use {rom} to place the game path yourself.")

        if not (initial and editing):
            self.fill_extensions()

    def show_core_info(self):
        exe = self.exe_var.get().strip()
        info = read_core_info(exe, self.core_var.get().strip()) if exe else {}
        if info:
            text = info.get("display_name", "")
            system = info.get("systemname", "")
            if system and system not in text:
                text = f"{text}  ·  {system}" if text else system
            self.core_info_label.config(text=text, fg=T["text_faint"])
        elif self.core_var.get().strip():
            self.core_info_label.config(
                text="No .info file for this core (RetroArch: Online Updater → Update Core Info Files).",
                fg=T["warning"])
        else:
            self.core_info_label.config(text="Choose a core.", fg=T["text_faint"])
        return info

    def fill_extensions(self, force=False):
        emu = self.emu_type()
        info = {}
        if emu == "retroarch":
            info = self.show_core_info()
            exts = core_extensions(info)
        else:
            exts = EMULATORS[emu]["extensions"]
        if exts:
            current = self.ext_var.get().strip()
            if force or not current or current == self.auto_exts:
                self.auto_exts = ", ".join(exts)
                self.ext_var.set(self.auto_exts)
        if not self.name_var.get().strip() and info.get("systemname"):
            self.name_var.set(info["systemname"])

    # ----- events

    def on_emulator_changed(self):
        exe = self.exe_var.get().strip()
        if exe:
            self.type_var.set(EMULATORS[detect_type(exe)]["label"])
        self.refresh_for_type()

    def on_type_changed(self):
        self.refresh_for_type()

    def on_core_changed(self):
        if self.emu_type() == "retroarch":
            self.fill_extensions()

    def browse_folder(self):
        folder = filedialog.askdirectory(parent=self)
        if folder:
            self.path_var.set(os.path.normpath(folder))
            if not self.name_var.get():
                self.name_var.set(os.path.basename(folder))

    def browse_exe(self):
        current = self.exe_var.get().strip()
        path = filedialog.askopenfilename(
            parent=self, title="Choose the emulator",
            initialdir=os.path.dirname(current) if current else None,
            filetypes=[("Programs", "*.exe"), ("All files", "*.*")],
        )
        if path:
            self.exe_var.set(os.path.normpath(path))
            self.on_emulator_changed()

    def browse_config(self):
        current = self.config_var.get().strip()
        path = filedialog.askopenfilename(
            parent=self, title="Choose the emulator's settings file",
            initialdir=os.path.dirname(current) if current else None,
            filetypes=[("Settings", "*.ini"), ("All files", "*.*")],
        )
        if path:
            self.config_var.set(os.path.normpath(path))
            self.refresh_for_type()

    def ok(self):
        path = self.path_var.get().strip()
        exe = self.exe_var.get().strip()
        emu = self.emu_type()
        core = self.core_var.get().strip()
        if not os.path.isdir(path):
            show_error("ROM folder", "Choose a ROM folder that exists.", parent=self)
            return
        if not os.path.isfile(exe):
            show_error("Emulator", "Choose the emulator's .exe.", parent=self)
            return
        if emu == "retroarch" and not core:
            show_error("Core", "Choose a RetroArch core.", parent=self)
            return
        exts = [e.strip().lstrip(".") for e in self.ext_var.get().split(",") if e.strip()]
        self.result = {
            "name": self.name_var.get().strip() or os.path.basename(path),
            "path": path,
            "emulator_exe": exe,
            "emulator_type": emu,
            "core": core if emu == "retroarch" else "",
            "config_file": self.config_var.get().strip() if EMULATORS[emu]["hardcore"] else "",
            "extensions": exts,
            "extra_args": self.args_var.get().strip(),
        }
        self.destroy()


def list_safe(text):
    """Some Python/Tk builds on Windows can't show emoji beyond the basic range (like 🎯) in a
    list box and fail while building it. Drop just those characters there."""
    cleaned = "".join(ch for ch in text if ord(ch) <= 0xFFFF)
    return " ".join(cleaned.split()) if cleaned != text else text


class ActionPicker(tk.Toplevel):
    """A small list of actions that works with a controller, mouse or keyboard."""

    def __init__(self, parent, title, items):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.transient(parent)
        self.items = [i for i in items if i is not None]
        self.list = tk.Listbox(self, activestyle="none", exportselection=False,
                               font=("Segoe UI", 11), height=len(self.items), width=28)
        for label, _fn in self.items:
            self.list.insert("end", "  " + list_safe(label))
        self.list.pack(padx=10, pady=10)
        self.list.selection_set(0)
        self.list.bind("<Double-Button-1>", lambda e: self.run())
        self.list.bind("<Return>", lambda e: self.run())
        self.bind("<Escape>", lambda e: self.destroy())
        tk.Label(self, text="A  choose      B  close", fg=T["text_faint"]).pack(pady=(0, 8))
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.list.focus_set()
        self.grab_set()

    def move(self, step):
        sel = self.list.curselection()
        pos = max(0, min(len(self.items) - 1, (sel[0] if sel else 0) + step))
        self.list.selection_clear(0, "end")
        self.list.selection_set(pos)
        self.list.see(pos)

    def run(self):
        sel = self.list.curselection()
        if not sel:
            return
        fn = self.items[sel[0]][1]
        self.destroy()
        self.master.after(10, fn)

    def handle_pad(self, action):
        if action in ("up", "down"):
            self.move(-1 if action == "up" else 1)
        elif action == "select":
            self.run()
        elif action == "back":
            self.destroy()


class SeriesDialog(tk.Toplevel):
    """Pick an existing series or type a new name."""

    def __init__(self, parent, game_title, series_names):
        super().__init__(parent)
        self.title("Add to Group")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.result = None

        tk.Label(self, text=f"Add “{game_title}” to:", anchor="w").pack(fill="x", padx=12, pady=(12, 4))
        self.series_names = series_names
        self.name_var = tk.StringVar(value=series_names[0] if series_names else "")
        box = ttk.Combobox(self, textvariable=self.name_var, values=series_names, width=40)
        box.pack(padx=12)
        box.focus_set()
        box.select_range(0, "end")
        tk.Label(self, text="Pick a group, or type a new name to create one.\n"
                            "Controller: up/down to pick · A to add · B to cancel",
                 fg=T["text_faint"], justify="left").pack(fill="x", padx=12, pady=(4, 0))

        buttons = tk.Frame(self)
        buttons.pack(pady=10)
        tk.Button(buttons, text="Add", width=10, command=self.ok).pack(side="left", padx=5)
        tk.Button(buttons, text="Cancel", width=10, command=self.destroy).pack(side="left", padx=5)
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.wait_window()

    def ok(self):
        name = self.name_var.get().strip()
        if name:
            self.result = name
            self.destroy()

    def handle_pad(self, action):
        if action in ("up", "down") and self.series_names:
            current = self.name_var.get()
            pos = self.series_names.index(current) if current in self.series_names else -1
            pos = (pos + (-1 if action == "up" else 1)) % len(self.series_names)
            self.name_var.set(self.series_names[pos])
        elif action == "select":
            self.ok()
        elif action == "back":
            self.destroy()


# ---------------------------------------------------------------- card color picker

PRESET_COLORS = [
    ("Red", "#c62828"), ("Orange", "#ef6c00"), ("Gold", "#f9a825"), ("Lime", "#7cb342"),
    ("Green", "#2e7d32"), ("Teal", "#00897b"), ("Cyan", "#0097a7"), ("Blue", "#1e66d0"),
    ("Indigo", "#3949ab"), ("Purple", "#6a3fb5"), ("Magenta", "#ad1457"), ("Pink", "#e05a8a"),
    ("Brown", "#6d4c41"), ("Slate", "#546e7a"), ("Charcoal", "#263238"),
]


class ColorPicker(tk.Toplevel):
    """Choose a card color from a fixed set of presets. Works with mouse, keyboard or controller.

    result is the chosen hex color, "" for the default color, or None if cancelled."""

    COLUMNS = 4

    def __init__(self, parent, title, current, default_color):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.transient(parent)
        self.result = None
        # First swatch is "Default": the emulator/series color the card would normally use
        self.choices = [("Default", "", default_color)] + [(n, c, c) for n, c in PRESET_COLORS]
        values = [c for _, c, _ in self.choices]
        self.focus_index = values.index(current) if current in values else 0

        grid = tk.Frame(self, padx=12, pady=12)
        grid.pack()
        self.cells = []
        for i, (name, value, shown) in enumerate(self.choices):
            cell = tk.Frame(grid, padx=4, pady=4, highlightthickness=3,
                            highlightbackground=self.cget("bg"), cursor="hand2")
            cell.grid(row=i // self.COLUMNS, column=i % self.COLUMNS, padx=4, pady=4)
            swatch = tk.Frame(cell, bg=shown, width=px(44), height=px(44))
            swatch.pack()
            label = tk.Label(cell, text=name, font=("Segoe UI", 9))
            label.pack()
            for w in (cell, swatch, label):
                w.bind("<Button-1>", lambda e, i=i: self.choose(i))
            self.cells.append(cell)

        tk.Label(self, text="Click a color · Controller: move, A choose, B cancel",
                 fg=T["text_faint"]).pack(pady=(0, 10))
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Return>", lambda e: self.choose(self.focus_index))
        for key, step in (("<Left>", -1), ("<Right>", 1), ("<Up>", -self.COLUMNS), ("<Down>", self.COLUMNS)):
            self.bind(key, lambda e, s=step: self.move(s))
        self.paint()
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.focus_set()
        self.grab_set()
        self.wait_window()

    def paint(self):
        for i, cell in enumerate(self.cells):
            cell.config(highlightbackground=T["accent"] if i == self.focus_index else self.cget("bg"))

    def move(self, step):
        target = self.focus_index + step
        if 0 <= target < len(self.cells):
            self.focus_index = target
            self.paint()

    def choose(self, index):
        self.result = self.choices[index][1]
        self.destroy()

    def handle_pad(self, action):
        steps = {"left": -1, "right": 1, "up": -self.COLUMNS, "down": self.COLUMNS}
        if action in steps:
            self.move(steps[action])
        elif action == "select":
            self.choose(self.focus_index)
        elif action == "back":
            self.destroy()


# ---------------------------------------------------------------- pick one from a long list

class ChoiceDialog(tk.Toplevel):
    """Pick one option from a searchable list. Works with mouse, keyboard or controller.

    options: [(value, label)]. result is the chosen value, or None if cancelled."""

    def __init__(self, parent, title, prompt, options, initial=None):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.transient(parent)
        self.options = options
        self.result = None
        self.shown = []

        tk.Label(self, text=prompt, anchor="w", justify="left").pack(fill="x", padx=12, pady=(12, 4))
        self.search_var = tk.StringVar()
        search = tk.Entry(self, textvariable=self.search_var, width=44, font=("Segoe UI", 11))
        search.pack(fill="x", padx=12, ipady=2)
        frame = tk.Frame(self)
        frame.pack(fill="both", expand=True, padx=12, pady=(6, 0))
        self.list = tk.Listbox(frame, height=14, activestyle="none", exportselection=False,
                               font=("Segoe UI", 11), highlightthickness=0, selectborderwidth=0)
        scroll = scrollbar(frame, self.list.yview)
        self.list.config(yscrollcommand=scroll.set)
        self.list.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        buttons = tk.Frame(self)
        buttons.pack(pady=10)
        tk.Button(buttons, text="OK", width=10, command=self.ok).pack(side="left", padx=5)
        tk.Button(buttons, text="Cancel", width=10, command=self.destroy).pack(side="left", padx=5)
        tk.Label(self, text="Type to filter · Controller: up/down, A choose, B cancel",
                 fg=T["text_faint"]).pack(pady=(0, 10))

        self.search_var.trace_add("write", lambda *a: self.fill())
        self.list.bind("<Double-Button-1>", lambda e: self.ok())
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.destroy())
        search.bind("<Down>", lambda e: self.move(1))
        search.bind("<Up>", lambda e: self.move(-1))
        self.fill(initial)
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_width()) // 2
        y = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_height()) // 4
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        search.focus_set()
        self.grab_set()
        self.wait_window()

    def fill(self, select=None):
        term = self.search_var.get().lower().strip()
        current = self.selected_value() if select is None else select
        self.shown = [(v, l) for v, l in self.options if term in l.lower() or term in str(v).lower()]
        self.list.delete(0, "end")
        for _v, label in self.shown:
            self.list.insert("end", "  " + list_safe(label))
        values = [v for v, _ in self.shown]
        if values:
            pos = values.index(current) if current in values else 0
            self.list.selection_set(pos)
            self.list.see(pos)

    def selected_value(self):
        sel = self.list.curselection() if hasattr(self, "list") else ()
        return self.shown[sel[0]][0] if sel and sel[0] < len(self.shown) else None

    def move(self, step):
        if not self.shown:
            return "break"
        sel = self.list.curselection()
        pos = max(0, min(len(self.shown) - 1, (sel[0] if sel else 0) + step))
        self.list.selection_clear(0, "end")
        self.list.selection_set(pos)
        self.list.see(pos)
        return "break"

    def ok(self):
        sel = self.list.curselection()
        if sel and sel[0] < len(self.shown):
            self.result = self.shown[sel[0]][0]
            self.destroy()

    def handle_pad(self, action):
        steps = {"up": -1, "down": 1, "page_up": -10, "page_down": 10}
        if action in steps:
            self.move(steps[action])
        elif action == "select":
            self.ok()
        elif action == "back":
            self.destroy()


# ---------------------------------------------------------------- in-app message boxes
# Themed replacements for Windows' message boxes and text prompts. They match the launcher's
# look and work with the controller (left/right to pick a button, A to press, B to cancel).

_ICONS = {"info": ("ℹ", "accent"), "warning": ("⚠", "warning"), "error": ("✖", "error"),
          "question": ("?", "accent")}


class _AppDialog(tk.Toplevel):
    """Shared behaviour: modal, centred on its window, and gives the grab back when closed."""

    def __init__(self, parent, title):
        parent = parent or tk._default_root
        super().__init__(parent)
        self.withdraw()
        self.title(title)
        self.resizable(False, False)
        self.transient(parent.winfo_toplevel())
        self.result = None
        self._previous_grab = parent.grab_current()
        self._parent = parent.winfo_toplevel()
        self.protocol("WM_DELETE_WINDOW", self.cancel)

    def run(self, focus):
        self.update_idletasks()
        p = self._parent
        x = p.winfo_rootx() + (p.winfo_width() - self.winfo_reqwidth()) // 2
        y = p.winfo_rooty() + (p.winfo_height() - self.winfo_reqheight()) // 3
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.deiconify()
        self.lift()
        focus.focus_set()
        self.grab_set()
        self.wait_window()
        # A dialog opened from another dialog (e.g. Add system) hands its grab back
        prev = self._previous_grab
        if prev is not None and prev is not self:
            try:
                if prev.winfo_exists():
                    prev.grab_set()
            except tk.TclError:
                pass
        return self.result

    def cancel(self):
        self.destroy()


class MessageDialog(_AppDialog):
    """A message with one or more buttons. Returns the chosen button's value."""

    def __init__(self, parent, title, message, buttons=(("OK", True),), default=0,
                 cancel_value=None, kind="info"):
        super().__init__(parent, title)
        self.cancel_value = cancel_value
        self.result = cancel_value
        body = tk.Frame(self, padx=px(20), pady=px(16))
        body.pack(fill="both")
        glyph, color = _ICONS.get(kind, _ICONS["info"])
        color = {"accent": T["accent"], "warning": T["warning"], "error": "#d64545"}[color]
        tk.Label(body, text=glyph, font=("Segoe UI", 22, "bold"), fg=color).pack(side="left", anchor="n",
                                                                                 padx=(0, px(14)))
        tk.Label(body, text=message, justify="left", anchor="w", wraplength=px(420),
                 font=("Segoe UI", 10)).pack(side="left", fill="both")

        row = tk.Frame(self, padx=px(16), pady=px(12))
        row.pack(fill="x")
        self.buttons = []
        for label, value in reversed(list(buttons)):
            b = tk.Button(row, text=label, width=10, command=lambda v=value: self.choose(v))
            b.pack(side="right", padx=(px(8), 0))
            self.buttons.insert(0, (b, value))
        self.base_bg = self.buttons[0][0].cget("bg")
        self.focus_index = default
        self.paint()
        self.bind("<Return>", lambda e: self.choose(self.buttons[self.focus_index][1]))
        self.bind("<Escape>", lambda e: self.cancel())
        self.bind("<Left>", lambda e: self.move(-1))
        self.bind("<Right>", lambda e: self.move(1))
        self.bind("<Tab>", lambda e: self.move(1))
        self.run(self.buttons[self.focus_index][0])

    def paint(self):
        """The highlighted button (pressed by Enter or A) is shown in the accent color."""
        for i, (b, _v) in enumerate(self.buttons):
            if i == self.focus_index:
                b.config(bg=T["accent"], fg="white", activebackground=T["accent"],
                         activeforeground="white")
            else:
                b.config(bg=self.base_bg, fg=T["text"] if T.get("button") else "black",
                         activebackground=T["button_hover"] or self.base_bg)

    def move(self, step):
        self.focus_index = (self.focus_index + step) % len(self.buttons)
        self.paint()
        return "break"

    def choose(self, value):
        self.result = value
        self.destroy()

    def cancel(self):
        self.result = self.cancel_value
        self.destroy()

    def handle_pad(self, action):
        if action in ("left", "up"):
            self.move(-1)
        elif action in ("right", "down"):
            self.move(1)
        elif action == "select":
            self.choose(self.buttons[self.focus_index][1])
        elif action == "back":
            self.cancel()


class TextDialog(_AppDialog):
    """Ask for a line of text. Returns the text, or None if cancelled."""

    def __init__(self, parent, title, prompt, initialvalue="", secret=False):
        super().__init__(parent, title)
        body = tk.Frame(self, padx=px(20), pady=px(16))
        body.pack(fill="both")
        tk.Label(body, text=prompt, anchor="w", justify="left").pack(fill="x", pady=(0, px(6)))
        self.var = tk.StringVar(value=initialvalue)
        entry = tk.Entry(body, textvariable=self.var, width=46, font=("Segoe UI", 11),
                         show="•" if secret else "")
        entry.pack(fill="x", ipady=3)
        entry.select_range(0, "end")
        entry.icursor("end")
        row = tk.Frame(self, padx=px(16), pady=px(12))
        row.pack(fill="x")
        tk.Button(row, text="Cancel", width=10, command=self.cancel).pack(side="right", padx=(px(8), 0))
        tk.Button(row, text="OK", width=10, bg=T["accent"], fg="white", activebackground=T["accent"],
                  activeforeground="white", command=self.ok).pack(side="right")
        tk.Label(row, text="Enter: OK · Esc: cancel", fg=T["text_faint"],
                 font=("Segoe UI", 9)).pack(side="left")
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.cancel())
        self.run(entry)

    def ok(self):
        self.result = self.var.get()
        self.destroy()

    def handle_pad(self, action):
        if action == "select":
            self.ok()
        elif action == "back":
            self.cancel()


def show_info(title, message, parent=None):
    MessageDialog(parent, title, message, kind="info")


def show_warning(title, message, parent=None):
    MessageDialog(parent, title, message, kind="warning")


def show_error(title, message, parent=None):
    MessageDialog(parent, title, message, kind="error")


def ask_yes_no(title, message, parent=None, yes="Yes", no="No", default_yes=True):
    """True for yes, False for no or cancel."""
    return bool(MessageDialog(parent, title, message, buttons=((yes, True), (no, False)),
                              default=0 if default_yes else 1, cancel_value=False, kind="question").result)


def ask_string(title, prompt, initialvalue="", parent=None, secret=False):
    return TextDialog(parent, title, prompt, initialvalue, secret).result


# ---------------------------------------------------------------- add / edit a reminder

class ReminderDialog(_AppDialog):
    """Text, how often it repeats, an optional time and an optional linked game.

    result is a dict of the edited fields, or None if cancelled."""

    def __init__(self, parent, reminder=None, game=None):
        from . import reminders as R
        from . import theme
        editing = reminder is not None
        super().__init__(parent, "Edit reminder" if editing else "New reminder")
        reminder = reminder or {}
        self.game = reminder.get("game") if editing else game
        body = tk.Frame(self, padx=px(20), pady=px(14))
        body.pack(fill="both")

        tk.Label(body, text="Remind me to:", anchor="w").grid(row=0, column=0, columnspan=4, sticky="w")
        self.text_var = tk.StringVar(value=reminder.get("text", ""))
        self.entry = tk.Entry(body, textvariable=self.text_var, width=44, font=("Segoe UI", 11))
        self.entry.grid(row=1, column=0, columnspan=4, sticky="we", ipady=3, pady=(px(4), px(10)))

        tk.Label(body, text="Repeat:").grid(row=2, column=0, sticky="w")
        self.repeat_var = tk.StringVar(value=reminder.get("repeat", "once"))
        repeat_row = tk.Frame(body)
        repeat_row.grid(row=2, column=1, columnspan=3, sticky="w")
        for value, label in R.REPEATS:
            theme.radio(repeat_row, label, value, self.repeat_var, self.update_weekday).pack(
                side="left", padx=(0, px(10)))
        self.weekday_var = tk.StringVar(value=R.WEEKDAYS[reminder.get("weekday", R.today().weekday())])
        self.weekday_box = ttk.Combobox(repeat_row, textvariable=self.weekday_var, values=R.WEEKDAYS,
                                        state="readonly", width=11)
        self.weekday_box.pack(side="left")

        tk.Label(body, text="Time:").grid(row=3, column=0, sticky="w", pady=(px(10), 0))
        self.time_var = tk.StringVar(value=R.time_label(reminder.get("time", "")))
        tk.Entry(body, textvariable=self.time_var, width=12).grid(row=3, column=1, sticky="w",
                                                                   pady=(px(10), 0), ipady=2)
        tk.Label(body, text="optional, e.g. 8pm or 20:30", fg=T["text_faint"]).grid(
            row=3, column=2, columnspan=2, sticky="w", padx=(px(8), 0), pady=(px(10), 0))

        self.game_row = tk.Frame(body)
        self.game_row.grid(row=4, column=0, columnspan=4, sticky="w", pady=(px(10), 0))
        self.draw_game()

        self.error = tk.Label(body, text="", fg="#d64545", anchor="w")
        self.error.grid(row=5, column=0, columnspan=4, sticky="w", pady=(px(6), 0))

        row = tk.Frame(self, padx=px(16), pady=px(12))
        row.pack(fill="x")
        tk.Button(row, text="Cancel", width=10, command=self.cancel).pack(side="right", padx=(px(8), 0))
        tk.Button(row, text="Save", width=10, bg=T["accent"], fg="white", activebackground=T["accent"],
                  activeforeground="white", command=self.ok).pack(side="right")
        tk.Label(row, text="Enter: save · Esc: cancel", fg=T["text_faint"],
                 font=("Segoe UI", 9)).pack(side="left")
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.cancel())
        self.update_weekday()
        self.run(self.entry)

    def draw_game(self):
        for w in self.game_row.winfo_children():
            w.destroy()
        if self.game:
            tk.Label(self.game_row, text=f"🎮  For: {self.game.get('title', '')}").pack(side="left")
            tk.Button(self.game_row, text="Unlink", command=self.unlink).pack(side="left", padx=(px(10), 0))

    def unlink(self):
        self.game = None
        self.draw_game()

    def update_weekday(self):
        self.weekday_box.config(state="readonly" if self.repeat_var.get() == "weekly" else "disabled")

    def ok(self):
        from . import reminders as R
        text = self.text_var.get().strip()
        if not text:
            self.error.config(text="Type what to be reminded of.")
            return
        try:
            time = R.parse_time(self.time_var.get())
        except ValueError as err:
            self.error.config(text=str(err))
            return
        self.result = {"text": text, "repeat": self.repeat_var.get(),
                       "weekday": R.WEEKDAYS.index(self.weekday_var.get()), "time": time, "game": self.game}
        self.destroy()

    def handle_pad(self, action):
        from . import reminders as R
        if action in ("left", "right"):
            values = [v for v, _ in R.REPEATS]
            pos = values.index(self.repeat_var.get())
            self.repeat_var.set(values[(pos + (1 if action == "right" else -1)) % len(values)])
            self.update_weekday()
        elif action in ("up", "down") and self.repeat_var.get() == "weekly":
            pos = R.WEEKDAYS.index(self.weekday_var.get())
            self.weekday_var.set(R.WEEKDAYS[(pos + (1 if action == "down" else -1)) % 7])
        elif action == "select":
            self.ok()
        elif action == "back":
            self.cancel()


# ---------------------------------------------------------------- smart group rules

SMART_RULES = [
    ("started_not_beaten", "Started, not beaten", "achievements earned, no Beaten award yet"),
    ("started_not_mastered", "Started, not mastered", "achievements earned, not mastered yet"),
    ("started_not_completed", "Started, not completed", "achievements earned, some still locked"),
    ("missables", "Missables open", "games whose achievement list you've opened"),
    ("beaten", "Beaten", "Beaten award, not completed or mastered"),
    ("completed", "Completed", "every achievement earned, some only in casual"),
    ("mastered", "Mastered", "every achievement earned in hardcore"),
    ("not_started", "Not started", "has achievements, none earned yet"),
    ("needs_link", "Requires manual RA link", "scanned, but not matched to a RetroAchievements set"),
]


class SmartGroupDialog(_AppDialog):
    """Name a smart group and tick the rules a game must match (all of them) to appear in it.

    result is {"name": ..., "rules": [...], "systems": [...]} or None if cancelled.
    systems: (id, name) pairs to offer; none ticked means every system."""

    def __init__(self, parent, name="", rules=(), title="New smart group", systems=(), chosen=(),
                 match="all"):
        super().__init__(parent, title)
        body = tk.Frame(self, padx=px(22), pady=px(16))
        body.pack(fill="both")
        tk.Label(body, text="Name", anchor="w").pack(fill="x")
        self.name_var = tk.StringVar(value=name)
        self.name_entry = tk.Entry(body, textvariable=self.name_var, width=44, font=("Segoe UI", 11))
        self.name_entry.pack(fill="x", ipady=3, pady=(px(4), px(14)))
        tk.Label(body, text="Show games that are…", anchor="w",
                 font=("Segoe UI", 10, "bold"), fg=T["text_muted"]).pack(fill="x")
        self.rule_vars = {}
        self.rows = []
        # Several rules: a game needs all of them, or any one
        self.match_var = tk.StringVar(value=match)
        match_row = tk.Frame(body)
        match_row.pack(fill="x", pady=(px(2), px(4)))
        tk.Label(match_row, text="Match", fg=T["text_faint"], font=("Segoe UI", 9)).pack(side="left")
        self.match_radios = []
        for value, text in (("all", "all ticked"), ("any", "any ticked")):
            r = theme.radio(match_row, text, value, self.match_var)
            r.pack(side="left", padx=(px(10), 0))
            self.match_radios.append(r)
        for key, label, note in SMART_RULES:
            var = tk.BooleanVar(value=key in rules)
            self.rule_vars[key] = var
            row = tk.Frame(body)
            row.pack(fill="x", pady=px(1))
            box = theme.checkbox(row, label, var)
            box.pack(side="left")
            tk.Label(row, text=f"  {note}", fg=T["text_faint"], font=("Segoe UI", 9)).pack(side="left")
            self.rows.append(box)
        # Systems: none ticked = all of them
        self.system_vars = {}
        self.system_boxes = []
        if systems:
            tk.Label(body, text="On these systems  (none ticked = all)", anchor="w",
                     font=("Segoe UI", 10, "bold"), fg=T["text_muted"]).pack(fill="x", pady=(px(14), 0))
            grid = tk.Frame(body)
            grid.pack(fill="x")
            columns = 3 if len(systems) > 8 else 2
            for c in range(columns):
                grid.columnconfigure(c, weight=1, uniform="systems")
            for n, (sid, sname) in enumerate(systems):
                var = tk.BooleanVar(value=sid in chosen)
                self.system_vars[sid] = var
                box = theme.checkbox(grid, sname, var)
                box.grid(row=n // columns, column=n % columns, sticky="w", pady=px(1))
                self.system_boxes.append(box)
        tk.Label(body, text="Sort the group however you like from its list, e.g. by Retro Ratio.",
                 fg=T["text_faint"], font=("Segoe UI", 9), justify="left", anchor="w",
                 wraplength=px(440)).pack(fill="x", pady=(px(10), 0))
        footer = tk.Frame(self, padx=px(16), pady=px(12))
        footer.pack(fill="x")
        self.cancel_btn = tk.Button(footer, text="Cancel", width=10, command=self.cancel)
        self.cancel_btn.pack(side="right", padx=(px(8), 0))
        self.ok_btn = tk.Button(footer, text="OK", width=10, bg=T["accent"], fg="white",
                                activebackground=T["accent"], activeforeground="white", command=self.ok)
        self.ok_btn.pack(side="right")
        self.bind("<Return>", lambda e: self.ok())
        self.bind("<Escape>", lambda e: self.cancel())
        # Controller: up/down walk the rules and buttons, A ticks or presses
        self.items = self.match_radios + self.rows + self.system_boxes + [self.ok_btn, self.cancel_btn]
        self.focus_index = None
        self.run(self.name_entry)

    def ok(self):
        name = self.name_var.get().strip()
        rules = [k for k, v in self.rule_vars.items() if v.get()]
        systems = [k for k, v in self.system_vars.items() if v.get()]
        if not name:
            show_warning("Smart group", "Give the group a name.", parent=self)
            return
        if not rules and not systems:
            show_warning("Smart group", "Tick at least one rule or system.", parent=self)
            return
        self.result = {"name": name, "rules": rules, "systems": systems, "match": self.match_var.get()}
        self.destroy()

    def paint_focus(self):
        for i, w in enumerate(self.items):
            focused = i == self.focus_index
            w.config(highlightthickness=2 if focused else 0, highlightbackground=T["accent"],
                     highlightcolor=T["accent"])

    def handle_pad(self, action):
        if action == "back":
            self.cancel()
            return
        if action in ("up", "down"):
            step = -1 if action == "up" else 1
            i = (-1 if step > 0 else len(self.items)) if self.focus_index is None else self.focus_index
            self.focus_index = max(0, min(len(self.items) - 1, i + step))
            self.paint_focus()
        elif action == "select":
            if self.focus_index is None:
                self.ok()
                return
            self.items[self.focus_index].invoke()
