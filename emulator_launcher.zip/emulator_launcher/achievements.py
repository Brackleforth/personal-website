"""A game's achievement list: RetroAchievements' data plus your own marks.

The list itself is cached per game in metadata/achievements/<game id>.json (refreshed by every
progress request), so the main metadata file stays small. Badge images are downloaded the first
time a game's list is viewed, all at once, into metadata/badges/<game id>/, and never again.

Your marks are kept in launcher_config.json under "achievement_marks", by achievement ID:
    {"12345": {"missable": True}}     you marked it missable
    {"12345": {"missable": False}}    RetroAchievements tags it missable, you say it isn't
    {"12345": {"progression": True}}  you marked it as a story (progression) achievement
"""

import json
import os
import time

from .paths import METADATA_DIR

CACHE_DIR = os.path.join(METADATA_DIR, "achievements")
BADGE_DIR = os.path.join(METADATA_DIR, "badges")
BADGE_URL = "https://media.retroachievements.org/Badge/{}.png"
STALE_SECONDS = 10 * 60          # opening the list refreshes it if older than this
# Bumped when the saved format changes. Version 2: achievement types read from "Type", so lists
# saved before (with every type empty) count as out of date and are refetched when next opened.
CACHE_VERSION = 2


# ---------------------------------------------------------------- cache

def cache_path(game_id):
    return os.path.join(CACHE_DIR, f"{game_id}.json")


def parse(d):
    """The per-achievement part of an API_GetGameInfoAndUserProgress reply."""
    items = []
    for a in (d.get("Achievements") or {}).values():
        items.append({
            "id": str(a.get("ID", "")),
            "title": a.get("Title", "") or "",
            "description": a.get("Description", "") or "",
            "points": a.get("Points", 0) or 0,
            # progression, win_condition, missable or "". The API sends "Type"; older docs show "type".
            "type": a.get("Type") or a.get("type") or "",
            "badge": str(a.get("BadgeName", "") or ""),
            "order": a.get("DisplayOrder", 0) or 0,
            "unlocks": a.get("NumAwarded", 0) or 0,
            "earned": (a.get("DateEarned") or "")[:10],
            "earned_hardcore": (a.get("DateEarnedHardcore") or "")[:10],
        })
    items.sort(key=lambda a: (a["order"], int(a["id"]) if a["id"].isdigit() else 0))
    return {"version": CACHE_VERSION, "fetched": time.time(),
            "players": d.get("NumDistinctPlayers", 0) or 0, "achievements": items}


def save_cache(game_id, d):
    """Store the achievement list from a progress reply (called by metadata.ra_progress)."""
    data = parse(d)
    if not data["achievements"]:
        return
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = cache_path(game_id)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f)
    os.replace(tmp, path)
    _memo.pop(str(game_id), None)


_memo = {}


def load_cache(game_id):
    """The cached list, or None. Kept in memory until the file changes."""
    if not game_id:
        return None
    path = cache_path(game_id)
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return None
    hit = _memo.get(str(game_id))
    if hit and hit[0] == mtime:
        return hit[1]
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    data.setdefault("game_id", str(game_id))
    _memo[str(game_id)] = (mtime, data)
    return data


def is_stale(game_id):
    data = load_cache(game_id)
    return (data is None or data.get("version", 1) < CACHE_VERSION
            or time.time() - data.get("fetched", 0) > STALE_SECONDS)


# ---------------------------------------------------------------- badges

def badge_path(game_id, badge):
    """metadata/badges/<game id>/<badge>.png. A badge saved by an earlier version straight in
    metadata/badges/ is moved into its game's folder the first time it's looked up."""
    path = os.path.join(BADGE_DIR, str(game_id), f"{badge}.png")
    old = os.path.join(BADGE_DIR, f"{badge}.png")
    if not os.path.isfile(path) and os.path.isfile(old):
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            os.replace(old, path)
        except OSError:
            return old
    return path


def missing_badges(data):
    game_id = (data or {}).get("game_id", "")
    return [a["badge"] for a in (data or {}).get("achievements", [])
            if a["badge"] and not os.path.isfile(badge_path(game_id, a["badge"]))]


def download_badges(data, http_get, cancel=None):
    """Fetch every badge this game is missing. Returns how many were saved."""
    saved = 0
    game_id = (data or {}).get("game_id", "")
    for badge in dict.fromkeys(missing_badges(data)):
        if cancel is not None and cancel.is_set():
            break
        try:
            raw = http_get(BADGE_URL.format(badge), retries=1, timeout=20)
        except Exception:
            continue
        if not raw:
            continue
        path = badge_path(game_id, badge)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path + ".tmp", "wb") as f:
            f.write(raw)
        os.replace(path + ".tmp", path)
        saved += 1
    return saved


def badge_cache_size():
    total = 0
    for folder, _dirs, files in os.walk(BADGE_DIR):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(folder, name))
            except OSError:
                pass
    return total


# ---------------------------------------------------------------- your marks + grouping

def missable_state(a, marks):
    """'ra', 'user', 'ra_off' (tagged by RetroAchievements, unmarked by you) or ''."""
    mine = (marks.get(a["id"]) or {}).get("missable")
    if mine is True:
        return "ra" if a["type"] == "missable" else "user"
    if mine is False and a["type"] == "missable":
        return "ra_off"
    return "ra" if a["type"] == "missable" else ""


def story_state(a, marks):
    """'win', 'ra', 'user' (you marked it progression) or ''."""
    if a["type"] == "win_condition":
        return "win"
    if a["type"] == "progression":
        return "ra"
    return "user" if (marks.get(a["id"]) or {}).get("progression") else ""


def rarity(a, players):
    """('Rare', 8) style label and percentage of players who unlocked it."""
    if not players:
        return "", None
    pct = 100 * a["unlocks"] / players
    label = ("Ultra rare" if pct < 5 else "Rare" if pct < 15 else
             "Uncommon" if pct < 40 else "Common")
    return label, pct


def build(data, marks):
    """Everything the details panel shows, or None without a cached list."""
    if not data or not data.get("achievements"):
        return None
    marks = marks or {}
    groups = {"missable": [], "story": [], "remaining": [], "earned": []}
    missables_open = user_missables_open = 0
    story_left = wins = wins_earned = 0
    has_story = False
    for a in data["achievements"]:
        item = dict(a)
        item["missable"] = missable_state(a, marks)
        item["story"] = story_state(a, marks)
        item["rarity"], item["pct"] = rarity(a, data.get("players", 0))
        earned = bool(a["earned"] or a["earned_hardcore"])
        item["is_earned"] = earned
        if item["story"]:
            has_story = True
            if item["story"] == "win":
                wins += 1
                wins_earned += earned
            elif not earned:
                story_left += 1
        if earned:
            groups["earned"].append(item)
        elif item["missable"] in ("ra", "user"):
            groups["missable"].append(item)
            missables_open += 1
            user_missables_open += item["missable"] == "user"
        elif item["story"]:
            groups["story"].append(item)
        else:
            groups["remaining"].append(item)
    # Beaten = every progression achievement plus any one win condition
    to_beaten = story_left + (1 if wins and not wins_earned else 0) if has_story else None
    groups["earned"].sort(key=lambda a: a["earned_hardcore"] or a["earned"], reverse=True)
    return {"groups": groups, "missables_open": missables_open,
            "user_missables_open": user_missables_open, "to_beaten": to_beaten,
            "total": len(data["achievements"]), "players": data.get("players", 0),
            "fetched": data.get("fetched", 0)}


def missable_note(model):
    """'⚠ 3 missables open (1 marked by you)' or ''."""
    if not model or not model["missables_open"]:
        return ""
    n, mine = model["missables_open"], model["user_missables_open"]
    text = f"⚠ {n} missable{'s' if n != 1 else ''} open"
    if mine:
        text += f" ({mine} marked by you)" if mine != n else " (marked by you)"
    return text


def beaten_note(model):
    if not model or model["to_beaten"] is None:
        return ""
    if model["to_beaten"] == 0:
        return "◆ Story complete"
    n = model["to_beaten"]
    return f"◆ {n} to Beaten"
