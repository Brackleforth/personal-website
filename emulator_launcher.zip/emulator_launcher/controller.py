"""Xbox-style controller input through Windows' built-in XInput (no install needed)."""

import time

class XInputPad:
    """Reads Xbox-style controllers through Windows' built-in XInput. No install needed."""

    BUTTONS = {0x0001: "up", 0x0002: "down", 0x0004: "left", 0x0008: "right",
               0x0010: "start", 0x0020: "view", 0x0100: "lb", 0x0200: "rb",
               0x1000: "a", 0x2000: "b", 0x4000: "x", 0x8000: "y"}
    STICK_DEADZONE = 16000
    RIGHT_DEADZONE = 8000
    TRIGGER_THRESHOLD = 100

    def __init__(self):
        self.dll = None
        self.index = None          # which of the 4 controller slots is in use
        self.next_rescan = 0.0
        try:
            import ctypes
            from ctypes import wintypes
            for name in ("xinput1_4", "xinput1_3", "xinput9_1_0"):
                try:
                    self.dll = ctypes.WinDLL(name)
                    break
                except OSError:
                    continue
        except (ImportError, AttributeError):    # not Windows
            self.dll = None
        if self.dll is None:
            return

        class Gamepad(ctypes.Structure):
            _fields_ = [("wButtons", wintypes.WORD), ("bLeftTrigger", ctypes.c_ubyte),
                        ("bRightTrigger", ctypes.c_ubyte), ("sThumbLX", ctypes.c_short),
                        ("sThumbLY", ctypes.c_short), ("sThumbRX", ctypes.c_short),
                        ("sThumbRY", ctypes.c_short)]

        class State(ctypes.Structure):
            _fields_ = [("dwPacketNumber", wintypes.DWORD), ("Gamepad", Gamepad)]

        self.state = State()
        self.byref = ctypes.byref
        self.dll.XInputGetState.argtypes = [wintypes.DWORD, ctypes.POINTER(State)]
        self.dll.XInputGetState.restype = wintypes.DWORD

    @property
    def available(self):
        return self.dll is not None

    def _read(self, index):
        return self.dll.XInputGetState(index, self.byref(self.state)) == 0

    def poll(self):
        """Returns (connected, set of pressed button names, right stick vertical -1.0..1.0)."""
        if self.dll is None:
            return False, set(), 0.0
        now = time.monotonic()
        if self.index is None or not self._read(self.index):
            self.index = None
            # Checking empty slots is slow, so only look for a new controller every 2 seconds
            if now < self.next_rescan:
                return False, set(), 0.0
            self.next_rescan = now + 2.0
            for i in range(4):
                if self._read(i):
                    self.index = i
                    break
            if self.index is None:
                return False, set(), 0.0

        g = self.state.Gamepad
        pressed = {name for bit, name in self.BUTTONS.items() if g.wButtons & bit}
        if g.sThumbLY > self.STICK_DEADZONE:
            pressed.add("up")
        elif g.sThumbLY < -self.STICK_DEADZONE:
            pressed.add("down")
        if g.sThumbLX < -self.STICK_DEADZONE:
            pressed.add("left")
        elif g.sThumbLX > self.STICK_DEADZONE:
            pressed.add("right")
        if g.bLeftTrigger > self.TRIGGER_THRESHOLD:
            pressed.add("lt")
        if g.bRightTrigger > self.TRIGGER_THRESHOLD:
            pressed.add("rt")

        # Right stick: an analog value, scaled so the dead zone reads as 0
        ry = g.sThumbRY
        right_y = 0.0
        if abs(ry) > self.RIGHT_DEADZONE:
            span = 32767 - self.RIGHT_DEADZONE
            right_y = max(-1.0, min(1.0, (abs(ry) - self.RIGHT_DEADZONE) / span)) * (1 if ry > 0 else -1)
        return True, pressed, right_y
