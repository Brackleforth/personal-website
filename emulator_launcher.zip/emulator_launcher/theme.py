"""Look and feel: sharp text on high-DPI screens, the Dark and Classic themes, and checkboxes.

Dark restyles every widget flat. Classic keeps the launcher's original Windows look and only
supplies the colors the launcher draws itself (cards, details panel).

Call enable_dpi_awareness() before creating the Tk window, then apply(root, name) before
building any widgets. Widgets read colors from T (e.g. T["text"]) when they are created,
so switching theme takes effect when the window is rebuilt.
"""

import tkinter as tk
from tkinter import ttk

PALETTES = {
    "dark": {
        "bg": "#1b1c20",            # window background
        "surface": "#25262c",       # cards, lists, inputs
        "surface_hover": "#30323a",
        "border": "#3a3c45",
        "text": "#e9e9ee",
        "text_muted": "#a4a6b0",
        "text_faint": "#7c7e88",
        "accent": "#4c8dff",        # focus, current tab, checkbox marks
        "select_bg": "#2b3a55",     # selected row in lists: a muted blue, not the bright accent
        "select_fg": "#ffffff",
        "field": "#25262c",         # list and input background
        "check_box": "#25262c",
        "check_border": "#6b6e78",
        "button": "#30323a",
        "button_hover": "#3d4049",
        "warning": "#e0a040",
        "gold": "#e8c25a",
        "progress_track": "#3a3a3a",
        "progress_soft": "#c4c4c4",     # casual (softcore) unlocks: soft white
        "progress_hard": "#e5b143",     # hardcore unlocks: gold, same as the award circles
        "drop_target": "#ff9f1a",
        "drag_source": "#6b6e78",
        # how widgets are drawn
        "ttk_theme": "clam", "button_relief": "flat", "button_bd": 0,
        "field_relief": "flat", "field_bd": 0, "frame_relief": "flat",
        "check_fill": True, "check_tick": "#ffffff", "check_dot": "#4c8dff",
    },
    # Tk's own 90s look: gray panels, raised 3D buttons, sunken fields, navy selection
    "classic": {
        "bg": "#d9d9d9",            # Tk's classic gray
        "surface": "#e4e4e4",       # cards
        "surface_hover": "#efefef",
        "border": "#9a9a9a",
        "text": "#000000",
        "text_muted": "#303030",
        "text_faint": "#5a5a5a",
        "accent": "#000080",        # navy, as in Windows 95
        "select_bg": "#000080",
        "select_fg": "#ffffff",
        "field": "#ececec",         # lists and text boxes: light gray rather than white
        "check_box": "#f4f4f4",
        "check_border": "#6a6a6a",
        "button": "#d9d9d9",
        "button_hover": "#e8e8e8",
        "warning": "#9a5b00",
        "gold": "#6b4e00",
        "progress_track": "#8c8c8c",
        "progress_soft": "#ffffff",
        "progress_hard": "#d4a017",
        "drop_target": "#ff8f00",
        "drag_source": "#606060",
        "ttk_theme": "classic", "button_relief": "raised", "button_bd": 2,
        "field_relief": "sunken", "field_bd": 2, "frame_relief": "groove",
        "check_fill": False, "check_tick": "#000000", "check_dot": "#000000",
    },
}

THEMES = [("dark", "Dark"), ("classic", "Classic")]
THEME_ALIASES = {"light": "classic"}     # settings saved before Classic replaced Light

T = dict(PALETTES["dark"])   # the active palette
CURRENT = "dark"
_IMAGES = {}                 # checkbox images; Tk needs a live reference to keep showing them
SCALE = 1.0                  # screen DPI / 96, so pixel sizes grow on scaled displays


def enable_dpi_awareness():
    """Tell Windows the app draws its own sharp text, instead of letting it be stretched blurry."""
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)   # system DPI aware (Windows 8.1+)
        except (AttributeError, OSError):
            ctypes.windll.user32.SetProcessDPIAware()        # Vista / 7
    except (ImportError, AttributeError, OSError):
        pass                                                 # not Windows


def px(value):
    """Scale a size given in 96-DPI pixels to the current screen."""
    return int(round(value * SCALE))


def is_classic():
    return CURRENT == "classic"


def apply(root, name):
    """Activate a palette and style every widget type to match."""
    global SCALE, CURRENT
    name = THEME_ALIASES.get(name, name)
    CURRENT = name if name in PALETTES else "dark"
    T.clear()
    T.update(PALETTES[CURRENT])
    try:
        SCALE = max(1.0, root.winfo_fpixels("1i") / 96.0)
    except (tk.TclError, TypeError, ValueError):
        SCALE = 1.0

    c = T
    root.configure(bg=c["bg"])
    opt = root.option_add
    # Defaults for classic Tk widgets created from now on
    opt("*Background", c["bg"])
    opt("*Foreground", c["text"])
    opt("*highlightBackground", c["bg"])
    opt("*highlightColor", c["accent"])
    opt("*activeBackground", c["button_hover"])
    opt("*activeForeground", c["text"])
    opt("*disabledForeground", c["text_faint"])
    opt("*selectBackground", c["select_bg"])
    opt("*selectForeground", c["select_fg"])
    opt("*insertBackground", c["text"])
    opt("*troughColor", c["surface"])
    opt("*Font", ("Segoe UI", 10))

    opt("*Button.background", c["button"])
    opt("*Button.relief", c["button_relief"])
    opt("*Button.borderWidth", c["button_bd"])
    opt("*Button.padX", 12)
    opt("*Button.padY", 4)
    opt("*Button.cursor", "hand2")
    opt("*Button.overRelief", c["button_relief"])

    classic = CURRENT == "classic"
    for widget in ("Entry", "Listbox", "Text", "Spinbox"):
        opt(f"*{widget}.background", c["field"])
        opt(f"*{widget}.relief", c["field_relief"])
        opt(f"*{widget}.borderWidth", c["field_bd"])
        opt(f"*{widget}.highlightThickness", 1)
        # Classic fields have a sunken 3D edge instead of a thin border line
        opt(f"*{widget}.highlightBackground", c["bg"] if classic else c["border"])
    opt("*Text.highlightThickness", 0)
    opt("*Listbox.activeStyle", "none")
    opt("*Listbox.highlightThickness", 0)
    opt("*Listbox.selectBorderWidth", 0)

    opt("*Checkbutton.selectColor", c["surface"])
    opt("*Checkbutton.activeBackground", c["bg"])
    opt("*Radiobutton.selectColor", c["surface"])
    opt("*Radiobutton.activeBackground", c["bg"])
    opt("*LabelFrame.foreground", c["text_muted"])
    opt("*LabelFrame.relief", c["frame_relief"])
    opt("*LabelFrame.borderWidth", 2 if classic else 0)
    opt("*LabelFrame.highlightThickness", 0 if classic else 1)
    opt("*LabelFrame.highlightBackground", c["border"])
    opt("*LabelFrame.font", ("Segoe UI", 10, "bold"))
    opt("*Menu.background", c["surface"])
    opt("*Menu.foreground", c["text"])
    opt("*Menu.activeBackground", c["accent"])
    opt("*Menu.activeForeground", c["select_fg"])
    opt("*Menu.relief", "raised" if classic else "flat")
    opt("*Menu.borderWidth", 1)
    opt("*PanedWindow.background", c["border"])
    opt("*PanedWindow.sashRelief", "raised" if classic else "flat")
    opt("*Canvas.highlightThickness", 0)
    opt("*TCombobox*Listbox.background", c["field"])
    opt("*TCombobox*Listbox.foreground", c["text"])

    # Themed (ttk) widgets
    style = ttk.Style(root)
    style.theme_use(c["ttk_theme"])
    style.configure(".", background=c["bg"], foreground=c["text"], fieldbackground=c["field"],
                    bordercolor=c["border"], lightcolor=c["border"], darkcolor=c["border"],
                    troughcolor=c["field"], selectbackground=c["select_bg"],
                    selectforeground=c["select_fg"], font=("Segoe UI", 10))
    if classic:
        # Tk's classic 3D scrollbar: raised gray thumb and arrows in a darker trough
        style.configure("Vertical.TScrollbar", background=c["button"], troughcolor="#c3c3c3",
                        arrowcolor="#000000", arrowsize=px(15), borderwidth=2)
        style.map("Vertical.TScrollbar", background=[("active", c["button_hover"])])
    else:
        style.configure("Vertical.TScrollbar", background=c["button"], troughcolor=c["bg"],
                        bordercolor=c["bg"], lightcolor=c["button"], darkcolor=c["button"],
                        arrowcolor=c["text_muted"], gripcount=0, arrowsize=px(13))
        style.map("Vertical.TScrollbar", background=[("active", c["button_hover"])])
    # Rows tall enough for the text at any display scaling
    style.configure("Treeview", background=c["field"], fieldbackground=c["field"],
                    foreground=c["text"], rowheight=px(26), borderwidth=2 if classic else 0)
    style.map("Treeview", background=[("selected", c["select_bg"])],
              foreground=[("selected", c["select_fg"])])
    style.configure("Treeview.Heading", background=c["button"], foreground=c["text_muted"],
                    relief="raised" if classic else "flat", padding=(6, 4))
    style.map("Treeview.Heading", background=[("active", c["button_hover"])])
    style.configure("TCombobox", fieldbackground=c["field"], background=c["button"],
                    foreground=c["text"], arrowcolor=c["text_muted"], padding=3)
    style.map("TCombobox",
              fieldbackground=[("readonly", c["field"]), ("disabled", c["bg"])],
              foreground=[("disabled", c["text_faint"])],
              selectbackground=[("readonly", c["field"])],
              selectforeground=[("readonly", c["text"])])
    style.configure("Horizontal.TProgressbar", background=c["accent"], troughcolor=c["field"],
                    bordercolor=c["border"], lightcolor=c["accent"], darkcolor=c["accent"])
    style.configure("TSeparator", background=c["border"])
    for widget in ("TCheckbutton", "TRadiobutton"):
        style.configure(widget, background=c["bg"], foreground=c["text"],
                        indicatorbackground=c["surface"], indicatorforeground=c["accent"],
                        upperbordercolor=c["border"], lowerbordercolor=c["border"],
                        focuscolor=c["bg"], padding=2)
        style.map(widget, background=[("active", c["bg"])],
                  indicatorbackground=[("pressed", c["surface_hover"]), ("selected", c["surface"])],
                  foreground=[("disabled", c["text_faint"])])

    _make_check_images(root)

    # Hover highlight for every flat button (Windows doesn't do this for classic buttons)
    root.bind_class("Button", "<Enter>", _hover_on, add="+")
    root.bind_class("Button", "<Leave>", _hover_off, add="+")


def _hover_on(event):
    w = event.widget
    try:
        if str(w.cget("state")) == "disabled":
            return
        w._hover_from = w.cget("bg")
        w.config(bg=w.cget("activebackground"))
    except (tk.TclError, AttributeError):
        pass


def _hover_off(event):
    w = event.widget
    try:
        # Only undo our own change; if the button was recolored meanwhile, keep that
        if getattr(w, "_hover_from", None) and w.cget("bg") == w.cget("activebackground"):
            w.config(bg=w._hover_from)
    except (tk.TclError, AttributeError):
        pass


def scrollbar(master, command):
    """A vertical scrollbar in the current theme's style."""
    return ttk.Scrollbar(master, orient="vertical", command=command)


# ---------------------------------------------------------------- large checkboxes

CHECK_SIZE = 20     # at 96 DPI; Windows' own boxes are about 13


def _make_check_images(root):
    """Draw checkbox and radio images at a comfortable size for the current theme."""
    n = px(CHECK_SIZE)
    box, edge = T["check_box"], T["check_border"]
    fill, tick, dot = T["check_fill"], T["check_tick"], T["check_dot"]
    line = max(1, n // 12)

    def blank():
        return tk.PhotoImage(master=root, width=n, height=n)

    def square(img, checked):
        img.put(edge, to=(0, 0, n, n))
        img.put(box, to=(line, line, n - line, n - line))
        if checked:
            if fill:
                img.put(T["accent"], to=(0, 0, n, n))     # Dark: solid box, white tick
            # Tick drawn as thick dots along two strokes
            t = max(2, n // 8)
            pts = [(0.22 + i * 0.02, 0.52 + i * 0.02) for i in range(11)]       # down stroke
            pts += [(0.44 + i * 0.025, 0.74 - i * 0.04) for i in range(14)]     # up stroke
            for fx, fy in pts:
                x, y = int(fx * n), int(fy * n)
                img.put(tick, to=(max(0, x - t // 2), max(0, y - t // 2),
                                       min(n, x + t - t // 2), min(n, y + t - t // 2)))
        return img

    def circle(img, checked):
        r = n / 2.0
        for y in range(n):
            row = []
            for x in range(n):
                d = ((x + 0.5 - r) ** 2 + (y + 0.5 - r) ** 2) ** 0.5
                if d <= r - line:
                    color = box
                    if checked and d <= r * 0.48:
                        color = dot
                    row.append(color)
                elif d <= r:
                    row.append(edge)
                else:
                    row.append(None)
            for x, color in enumerate(row):
                if color:
                    img.put(color, to=(x, y, x + 1, y + 1))
        return img

    _IMAGES.clear()
    _IMAGES.update(check_off=square(blank(), False), check_on=square(blank(), True),
                   radio_off=circle(blank(), False), radio_on=circle(blank(), True))


def _toggle_options():
    bg = T["bg"]
    return dict(indicatoron=False, compound="left", bd=0, highlightthickness=0, relief="flat",
                offrelief="flat", overrelief="flat", bg=bg, activebackground=bg, selectcolor=bg,
                fg=T["text"], activeforeground=T["text"], padx=2, pady=2, anchor="w", cursor="hand2")


def checkbox(master, text, variable, command=None):
    """A checkbox with a large, easy-to-hit box."""
    return tk.Checkbutton(master, text="  " + text, variable=variable, command=command,
                          image=_IMAGES["check_off"], selectimage=_IMAGES["check_on"],
                          **_toggle_options())


def radio(master, text, value, variable, command=None):
    """A radio button with a large, easy-to-hit circle."""
    return tk.Radiobutton(master, text="  " + text, value=value, variable=variable, command=command,
                          image=_IMAGES["radio_off"], selectimage=_IMAGES["radio_on"],
                          **_toggle_options())
