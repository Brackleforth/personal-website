"""Where the launcher keeps its files: next to launcher.pyw, so existing settings carry over."""

import os

# The folder that holds launcher.pyw and this package
SCRIPT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SETTINGS_PATH = os.path.join(SCRIPT_DIR, "launcher_config.json")
OVERRIDE_CFG = os.path.join(SCRIPT_DIR, "hardcore_override.cfg")
METADATA_DIR = os.path.join(SCRIPT_DIR, "metadata")
METADATA_PATH = os.path.join(METADATA_DIR, "metadata.json")
IMAGES_DIR = os.path.join(METADATA_DIR, "images")
