"""Loading and saving launcher_config.json."""

import json
import os
import uuid

from .emulators import DEFAULT_RETROARCH, detect_type
from .paths import SETTINGS_PATH

LOAD_WARNING = ""   # set if the settings file couldn't be read; shown once the window is up


def load_settings():
    global LOAD_WARNING
    settings = {"hardcore": False, "folders": [], "series": [],
                "last_emulator": DEFAULT_RETROARCH, "minimize_on_launch": False}
    if os.path.exists(SETTINGS_PATH):
        try:
            with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
                settings.update(json.load(f))
        except (OSError, json.JSONDecodeError, ValueError):
            # Keep the unreadable file so nothing is lost when defaults are saved over it
            import shutil
            import time
            backup = SETTINGS_PATH.replace(".json", time.strftime("-unreadable-%Y%m%d-%H%M%S.json"))
            try:
                shutil.copy2(SETTINGS_PATH, backup)
                where = f" A copy was kept as {os.path.basename(backup)}."
            except OSError:
                where = ""
            LOAD_WARNING = ("launcher_config.json couldn't be read, so default settings are in use."
                            + where)

    # Upgrade folders saved by the earlier RetroArch-only version
    old_exe = settings.pop("retroarch_exe", None)
    if old_exe:
        settings["last_emulator"] = old_exe
    for folder in settings["folders"]:
        if "emulator_exe" not in folder:
            folder["emulator_exe"] = old_exe or DEFAULT_RETROARCH
            folder["emulator_type"] = "retroarch"
        folder.setdefault("emulator_type", detect_type(folder["emulator_exe"]))
        folder.setdefault("core", "")
        folder.setdefault("config_file", "")
        folder.setdefault("extra_args", "")
        folder.setdefault("extensions", [])
        folder.setdefault("id", uuid.uuid4().hex)   # stable id, so series survive renames
    settings.pop("last_system", None)
    if not settings.get("card_order_set"):
        # Cards used to be alphabetical; start custom ordering from that
        settings["folders"].sort(key=lambda f: f["name"].lower())
        settings["series"].sort(key=lambda s: s["name"].lower())
        settings["card_order_set"] = True
    return settings


def save_settings(settings):
    """Write to a temporary file first, so a crash mid-save can't leave a half-written file."""
    tmp = SETTINGS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=2)
    os.replace(tmp, SETTINGS_PATH)
