"""Reminders shown in a carousel on the Home tab.

A reminder is a dict saved in launcher_config.json under "reminders":
    id        unique id
    text      what to do ("Take medicine", "Get the last gem in Tree Tops")
    repeat    "once", "daily" or "weekly"
    weekday   0-6 (Monday = 0), for weekly reminders
    time      "HH:MM" (24-hour) or "" for any time
    game      optional {"path", "system_id", "title"} when tied to a game
    done_on   ISO date it was last marked done ("" if not)
    created   ISO date it was added

Daily reminders reset when a new day starts, because "done" only counts for the day it was
ticked. A one-time reminder stays (dimmed) for the rest of the day it was done, then is removed.

The reminder day starts at RESET_HOUR (4 AM by default), not midnight, so a late-night session
still counts as the evening before. A reminder timed for 1 AM sits at the end of its day.
"""

import re
import uuid
from datetime import date, datetime, timedelta

WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
REPEATS = [("once", "Once"), ("daily", "Every day"), ("weekly", "Weekly")]
RESET_HOUR = 4          # Settings > Reminders > "New day starts at"


def hour_label(hour):
    """4 -> '4:00 AM', 0 -> '12:00 AM (midnight)'."""
    text = time_label(f"{hour:02d}:00")
    return text + " (midnight)" if hour == 0 else text + " (noon)" if hour == 12 else text


def today(now=None):
    """The reminder day: before RESET_HOUR it is still the day before."""
    return ((now or datetime.now()) - timedelta(hours=RESET_HOUR)).date()


def _day_minutes(hhmm):
    """Minutes from the start of the reminder day, so 01:00 sorts after 23:00 with a 4 AM reset."""
    hour, minute = (int(x) for x in hhmm.split(":"))
    return (hour * 60 + minute - RESET_HOUR * 60) % (24 * 60)


def new_reminder(text, repeat="once", weekday=None, time="", game=None):
    day = today()
    return {"id": uuid.uuid4().hex, "text": text.strip(), "repeat": repeat,
            "weekday": day.weekday() if weekday is None else weekday, "time": time,
            "game": game, "done_on": "", "created": day.isoformat()}


def parse_time(text):
    """'8pm', '8:30 pm', '20:30', '2030', '8' -> 'HH:MM'. '' for blank. Raises ValueError."""
    t = (text or "").strip().lower().replace(".", "")
    if not t:
        return ""
    m = re.fullmatch(r"(\d{1,2})(?::?(\d{2}))?\s*(am|pm|a|p)?", t)
    if not m:
        raise ValueError("Times look like 8pm, 8:30 pm or 20:30.")
    hour, minute, half = int(m.group(1)), int(m.group(2) or 0), m.group(3)
    if half:
        if not 1 <= hour <= 12:
            raise ValueError("With am/pm the hour is 1 to 12.")
        hour = hour % 12 + (12 if half.startswith("p") else 0)
    if hour > 23 or minute > 59:
        raise ValueError("That isn't a time of day.")
    return f"{hour:02d}:{minute:02d}"


def time_label(hhmm):
    """'20:30' -> '8:30 PM'."""
    if not hhmm:
        return ""
    hour, minute = (int(x) for x in hhmm.split(":"))
    return f"{hour % 12 or 12}:{minute:02d} {'AM' if hour < 12 else 'PM'}"


def is_done(r, day=None):
    return r.get("done_on") == (day or today()).isoformat()


def shows_today(r, day=None):
    """Whether a reminder belongs on today's carousel."""
    day = day or today()
    if r.get("repeat") == "weekly":
        return r.get("weekday") == day.weekday()
    if r.get("repeat") == "once" and r.get("done_on") and r["done_on"] < day.isoformat():
        return False                     # finished on an earlier day
    return True


def is_due(r, now=None):
    """A timed reminder whose time has passed today and isn't done yet."""
    now = now or datetime.now()
    if not r.get("time") or is_done(r, today(now)):
        return False
    return _day_minutes(now.strftime("%H:%M")) >= _day_minutes(r["time"])


def cleanup(reminders, day=None):
    """Drop one-time reminders finished on an earlier day. Returns (kept, changed)."""
    day = day or today()
    kept = [r for r in reminders
            if not (r.get("repeat") == "once" and r.get("done_on") and r["done_on"] < day.isoformat())]
    return kept, len(kept) != len(reminders)


def todays(reminders, now=None):
    """Today's reminders in carousel order: due first, then to-do (timed ones by time), then done."""
    now = now or datetime.now()
    day = today(now)
    visible = [r for r in reminders if shows_today(r, day)]

    def order(r):
        if is_done(r, day):
            group = 2
        elif is_due(r, now):
            group = 0
        else:
            group = 1
        timed = _day_minutes(r["time"]) if r.get("time") else 24 * 60
        return (group, timed, r.get("created", ""))
    return sorted(visible, key=order)


def describe(r, now=None):
    """The small second line on a card: 'Due · 8:00 PM', 'Every day', 'Saturdays · Spyro'..."""
    now = now or datetime.now()
    parts = []
    if is_done(r, today(now)):
        parts.append("✓ Done today")
    elif is_due(r, now):
        parts.append("Due")
    elif r.get("repeat") == "daily":
        parts.append("Every day")
    elif r.get("repeat") == "weekly":
        parts.append(WEEKDAYS[r.get("weekday", 0)] + "s")
    if r.get("time") and not is_done(r, today(now)):
        parts.append(time_label(r["time"]))
    if r.get("game"):
        parts.append(r["game"].get("title", ""))
    return " · ".join(p for p in parts if p)


def icon(r):
    if r.get("game"):
        return "🎮"
    if r.get("repeat") in ("daily", "weekly"):
        return "🔁"
    return "⏰"
