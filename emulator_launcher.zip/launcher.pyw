"""Start the Emulator Launcher. Double-click this file (it runs without a console window)."""

from emulator_launcher.app import main

if __name__ == "__main__":
    main()
